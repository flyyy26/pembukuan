<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Store extends Model
{
    protected $fillable = [
        'marketplace',
        'nama_toko',
        'seller_id',
        'kode_toko', 
        'is_active',
    ];

    protected $casts = [
        'is_active' => 'boolean',
    ];

    public function imports()
    {
        return $this->hasMany(Import::class);
    }

    /**
     * Relasi ke report BRILink (dipakai untuk filter outlet brangkas).
     */
    public function brilinkReports()
    {
        return $this->hasMany(BrilinkReport::class);
    }

    public function getMarketplaceLabelAttribute(): string
    {
        return match($this->marketplace) {
            'shopee'    => 'Shopee',
            'tiktok'    => 'TikTok Shop',
            'tokopedia' => 'Tokopedia',
            'lazada'    => 'Lazada',
            'brilink'   => 'BRILink',
            default     => ucfirst($this->marketplace),
        };
    }

    public function optimizations()
    {
        return $this->hasMany(ProductOptimization::class);
    }
}