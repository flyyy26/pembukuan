

<?php $__env->startSection('title', 'Optimasi Produk Shopee'); ?>

<?php $__env->startSection('content'); ?>
<div class="w-full">

    
    <div class="flex flex-col md:flex-row md:justify-between md:items-center gap-4 mb-6">
        <div class="flex items-center gap-3 min-w-0">
            <div class="w-10 h-10 bg-amber-100 rounded-lg flex items-center justify-center shrink-0">
                <iconify-icon icon="mdi:rocket-launch-outline" class="text-amber-600 text-xl"></iconify-icon>
            </div>
            <div class="min-w-0">
                <h2 class="text-lg sm:text-xl font-bold text-gray-800 truncate">Optimasi Produk Shopee</h2>
                <p class="text-sm text-gray-500 truncate"><?php echo e($store?->nama_toko ?? 'Belum pilih toko'); ?></p>
            </div>
        </div>

        <div class="grid grid-cols-2 sm:flex sm:flex-wrap gap-2 w-full md:w-auto">
            <a href="<?php echo e(route('shopee.optimasi.create', ['store' => $storeId])); ?>"
               class="inline-flex items-center justify-center gap-2 bg-amber-600 text-white px-3 sm:px-4 py-2 rounded-lg hover:bg-amber-700 transition text-sm font-medium shadow-sm">
                <iconify-icon icon="mdi:plus" class="text-lg shrink-0"></iconify-icon>
                <span>Tambah Produk</span>
            </a>
            <a href="<?php echo e(route('shopee.optimasi.export.pdf', request()->only(['store','status','search']))); ?>"
               target="_blank"
               class="inline-flex items-center justify-center gap-2 bg-red-600 text-white px-3 sm:px-4 py-2 rounded-lg hover:bg-red-700 transition text-sm font-medium shadow-sm">
                <iconify-icon icon="mdi:file-pdf-box" class="text-lg shrink-0"></iconify-icon>
                <span>PDF</span>
            </a>
            <a href="<?php echo e(route('shopee.optimasi.export.excel', request()->only(['store','status','search']))); ?>"
               class="inline-flex items-center justify-center gap-2 bg-green-600 text-white px-3 sm:px-4 py-2 rounded-lg hover:bg-green-700 transition text-sm font-medium shadow-sm">
                <iconify-icon icon="mdi:microsoft-excel" class="text-lg shrink-0"></iconify-icon>
                <span>Excel</span>
            </a>
        </div>
    </div>

    
    <?php if(session('success')): ?>
        <div class="bg-green-50 border border-green-200 text-green-800 px-4 py-3 rounded-lg mb-6 flex items-start gap-2">
            <iconify-icon icon="mdi:check-circle" class="text-green-600 text-lg mt-0.5"></iconify-icon>
            <div><?php echo e(session('success')); ?></div>
        </div>
    <?php endif; ?>

    <?php if($stores->isEmpty()): ?>
        <div class="bg-yellow-50 border border-yellow-200 text-yellow-800 px-4 py-4 rounded-lg mb-6 flex items-start gap-2">
            <iconify-icon icon="mdi:alert" class="text-yellow-600 text-lg mt-0.5"></iconify-icon>
            <div>
                <strong>Belum ada toko Shopee.</strong>
                Silakan <a href="<?php echo e(route('stores.index', ['modal' => 'create'])); ?>" class="underline font-semibold">tambah toko</a> dulu.
            </div>
        </div>
    <?php else: ?>

        
        <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4 mb-6">
            <form method="GET" class="flex gap-3 items-end flex-wrap">
                <div class="flex-1 min-w-[180px]">
                    <label class="block text-xs font-medium text-gray-600 mb-1">Toko</label>
                    <select name="store" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500">
                        <?php $__currentLoopData = $stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($s->id); ?>" <?php echo e($storeId == $s->id ? 'selected' : ''); ?>><?php echo e($s->nama_toko); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="min-w-[160px]">
                    <label class="block text-xs font-medium text-gray-600 mb-1">Status</label>
                    <select name="status" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500">
                        <option value="">Semua</option>
                        <option value="aman"      <?php echo e($status === 'aman' ? 'selected' : ''); ?>>Aman</option>
                        <option value="evaluasi"  <?php echo e($status === 'evaluasi' ? 'selected' : ''); ?>>Perlu Evaluasi</option>
                        <option value="perhatian" <?php echo e($status === 'perhatian' ? 'selected' : ''); ?>>Perlu Perhatian</option>
                    </select>
                </div>
                <div class="flex-1 min-w-[220px]">
                    <label class="block text-xs font-medium text-gray-600 mb-1">Cari</label>
                    <input type="text" name="search" value="<?php echo e($search); ?>" placeholder="Nama produk / SKU..."
                        class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500">
                </div>
                <button type="submit"
                        class="inline-flex items-center gap-2 bg-amber-600 text-white px-4 py-2 rounded-lg hover:bg-amber-700 transition text-sm font-medium">
                    <iconify-icon icon="mdi:filter" class="text-lg"></iconify-icon>
                    Filter
                </button>
                <?php if($status || $search): ?>
                    <a href="<?php echo e(route('shopee.optimasi.index', ['store' => $storeId])); ?>"
                       class="inline-flex items-center gap-2 text-gray-500 hover:text-gray-700 px-3 py-2 text-sm">
                        <iconify-icon icon="mdi:close" class="text-lg"></iconify-icon> Reset
                    </a>
                <?php endif; ?>
            </form>
        </div>

        
        <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 mb-6">
            <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
                <div class="text-xs text-gray-500 mb-1">Total Produk</div>
                <div class="text-2xl font-bold text-gray-800"><?php echo e($summary['total']); ?></div>
            </div>
            <div class="bg-white rounded-xl shadow-sm border border-green-100 p-4">
                <div class="text-xs text-green-600 mb-1">Aman</div>
                <div class="text-2xl font-bold text-green-600"><?php echo e($summary['aman']); ?></div>
            </div>
            <div class="bg-white rounded-xl shadow-sm border border-yellow-100 p-4">
                <div class="text-xs text-yellow-600 mb-1">Perlu Evaluasi</div>
                <div class="text-2xl font-bold text-yellow-600"><?php echo e($summary['evaluasi']); ?></div>
            </div>
            <div class="bg-white rounded-xl shadow-sm border border-red-100 p-4">
                <div class="text-xs text-red-600 mb-1">Perlu Perhatian</div>
                <div class="text-2xl font-bold text-red-600"><?php echo e($summary['perhatian']); ?></div>
            </div>
        </div>

        
        <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4 mb-6">
            <div class="flex items-center gap-2 mb-3">
                <iconify-icon icon="mdi:clipboard-list-outline" class="text-gray-600 text-lg"></iconify-icon>
                <h3 class="font-semibold text-gray-800 text-sm">Masalah per Aspek</h3>
            </div>
            <div class="grid grid-cols-3 md:grid-cols-5 lg:grid-cols-9 gap-2">
                <?php $__currentLoopData = \App\Models\ProductOptimization::ASPEK_AUDIT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $meta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $p = $aspekProblem[$key]; ?>
                    <div class="border border-gray-100 rounded-lg p-2 text-center">
                        <iconify-icon icon="<?php echo e($meta['icon']); ?>" class="text-gray-400 text-base"></iconify-icon>
                        <div class="text-[10px] text-gray-500 mt-1 leading-tight"><?php echo e($meta['label']); ?></div>
                        <div class="mt-1 flex items-center justify-center gap-1">
                            <?php if($p['perhatian'] > 0): ?>
                                <span class="text-[10px] bg-red-100 text-red-700 px-1.5 py-0.5 rounded font-bold"><?php echo e($p['perhatian']); ?></span>
                            <?php endif; ?>
                            <?php if($p['evaluasi'] > 0): ?>
                                <span class="text-[10px] bg-yellow-100 text-yellow-700 px-1.5 py-0.5 rounded font-bold"><?php echo e($p['evaluasi']); ?></span>
                            <?php endif; ?>
                            <?php if($p['total'] === 0): ?>
                                <span class="text-[10px] text-gray-300">—</span>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="mt-3 text-[10px] text-gray-400 flex items-center gap-3">
                <span class="inline-flex items-center gap-1"><span class="w-2 h-2 bg-red-400 rounded-full"></span> Perlu Perhatian</span>
                <span class="inline-flex items-center gap-1"><span class="w-2 h-2 bg-yellow-400 rounded-full"></span> Perlu Evaluasi</span>
            </div>
        </div>

        
        <?php if($items->isEmpty()): ?>
            <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-12 text-center">
                <iconify-icon icon="mdi:rocket-launch-outline" class="text-4xl text-gray-300 block m-auto mb-2 w-max"></iconify-icon>
                <div class="text-gray-500 mb-3">Belum ada produk optimasi.</div>
                <a href="<?php echo e(route('shopee.optimasi.create', ['store' => $storeId])); ?>"
                   class="inline-flex items-center gap-2 bg-amber-600 text-white px-4 py-2 rounded-lg hover:bg-amber-700 transition text-sm font-medium">
                    <iconify-icon icon="mdi:plus" class="text-lg"></iconify-icon>
                    Tambah Produk Pertama
                </a>
            </div>
        <?php else: ?>
            <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $statusMeta = \App\Models\ProductOptimization::STATUS_META[$item->status_global];
                        $statusColor = $statusMeta['color'];
                        $progress = $item->progressPerbaikan();
                    ?>
                    <div class="bg-white rounded-xl shadow-sm border border-gray-100 hover:shadow-md transition overflow-hidden flex flex-col">
                        
                        <div class="px-4 py-2 bg-<?php echo e($statusColor); ?>-50 border-b border-<?php echo e($statusColor); ?>-100 flex items-center justify-between">
                            <div class="flex items-center gap-1.5 text-<?php echo e($statusColor); ?>-700">
                                <iconify-icon icon="<?php echo e($statusMeta['icon']); ?>" class="text-base"></iconify-icon>
                                <span class="text-xs font-semibold"><?php echo e($statusMeta['label']); ?></span>
                            </div>
                        </div>

                        
                        <div class="p-4 flex-1">
                            <div class="flex items-start justify-between gap-2 mb-2">
                                <div class="min-w-0 flex-1">
                                    <h4 class="font-semibold text-gray-800 text-sm truncate" title="<?php echo e($item->nama_produk); ?>">
                                        <?php echo e($item->nama_produk); ?>

                                    </h4>
                                    <?php if($item->marketplace_sku): ?>
                                        <div class="text-[10px] font-mono text-gray-400 truncate"><?php echo e($item->marketplace_sku); ?></div>
                                    <?php endif; ?>
                                </div>
                                <div class="flex gap-1 flex-shrink-0">
                                    <a href="<?php echo e(route('shopee.optimasi.edit', $item)); ?>"
                                       class="w-7 h-7 inline-flex items-center justify-center bg-gray-100 text-gray-600 rounded hover:bg-blue-100 hover:text-blue-600 transition">
                                        <iconify-icon icon="mdi:pencil" class="text-sm"></iconify-icon>
                                    </a>
                                    <button type="button" onclick="deleteOptimasi(<?php echo e($item->id); ?>, '<?php echo e(addslashes($item->nama_produk)); ?>')"
                                            class="w-7 h-7 inline-flex items-center justify-center bg-gray-100 text-gray-600 rounded hover:bg-red-100 hover:text-red-600 transition">
                                        <iconify-icon icon="mdi:trash-can-outline" class="text-sm"></iconify-icon>
                                    </button>
                                </div>
                            </div>

                            
                            <div class="grid grid-cols-2 gap-1 text-[11px] mb-3">
                                <div>
                                    <div class="text-gray-400">Harga</div>
                                    <div class="font-medium text-gray-700">Rp <?php echo e(number_format($item->harga_produk, 0, ',', '.')); ?></div>
                                </div>
                                <div>
                                    <div class="text-gray-400">Harga Final</div>
                                    <div class="font-bold text-green-600">Rp <?php echo e(number_format($item->harga_final, 0, ',', '.')); ?></div>
                                </div>
                                <div>
                                    <div class="text-gray-400">Margin</div>
                                    <div class="font-medium text-purple-600"><?php echo e($item->margin_persen); ?>%</div>
                                </div>
                                <div>
                                    <div class="text-gray-400">Terakhir Audit</div>
                                    <div class="font-medium text-gray-700"><?php echo e($item->terakhir_audit?->format('d/m/Y') ?? '-'); ?></div>
                                </div>
                            </div>

                            
                            <div class="grid grid-cols-3 gap-1">
                                <?php $__currentLoopData = \App\Models\ProductOptimization::ASPEK_AUDIT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $meta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $a = $item->getAspek($key);
                                        $aMeta = \App\Models\ProductOptimization::STATUS_META[$a['status']];
                                        $sudah = $item->{"sudah_{$key}"};
                                    ?>
                                    <div class="border border-gray-100 rounded p-1.5 flex items-center gap-1
                                                <?php echo e($a['status'] === 'perhatian' ? 'bg-red-50 border-red-100' : ($a['status'] === 'evaluasi' ? 'bg-yellow-50 border-yellow-100' : '')); ?>"
                                         title="<?php echo e($meta['label']); ?>: <?php echo e($aMeta['label']); ?><?php echo e($a['note'] ? ' — ' . $a['note'] : ''); ?>">
                                        <iconify-icon icon="<?php echo e($meta['icon']); ?>" class="text-<?php echo e($aMeta['color']); ?>-500 text-xs"></iconify-icon>
                                        <span class="text-[9px] text-gray-600 truncate flex-1"><?php echo e($meta['label']); ?></span>
                                        <?php if(in_array($a['status'], ['evaluasi','perhatian'])): ?>
                                            <iconify-icon icon="<?php echo e($sudah ? 'mdi:check-circle' : 'mdi:circle-outline'); ?>"
                                                class="text-[10px] <?php echo e($sudah ? 'text-green-500' : 'text-gray-300'); ?>"></iconify-icon>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                            
                            <?php if($progress['total'] > 0): ?>
                                <div class="mt-2 pt-2 border-t border-gray-100">
                                    <div class="flex items-center justify-between text-[10px] mb-1">
                                        <span class="text-gray-500 flex items-center gap-1">
                                            <iconify-icon icon="mdi:progress-wrench" class="text-xs"></iconify-icon>
                                            Progress Perbaikan
                                        </span>
                                        <span class="font-bold <?php echo e($progress['persen'] === 100 ? 'text-green-600' : ($progress['persen'] >= 50 ? 'text-blue-600' : 'text-amber-600')); ?>">
                                            <?php echo e($progress['selesai']); ?>/<?php echo e($progress['total']); ?> (<?php echo e($progress['persen']); ?>%)
                                        </span>
                                    </div>
                                    <div class="w-full bg-gray-100 rounded-full h-1.5 overflow-hidden">
                                        <div class="h-full rounded-full transition-all duration-300
                                                    <?php echo e($progress['persen'] === 100 ? 'bg-green-500' : ($progress['persen'] >= 50 ? 'bg-blue-500' : 'bg-amber-500')); ?>"
                                             style="width: <?php echo e($progress['persen']); ?>%"></div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            
            <div class="mt-6">
                <?php echo e($items->links()); ?>

            </div>
        <?php endif; ?>
    <?php endif; ?>
</div>

<script>
async function deleteOptimasi(id, nama) {
    if (!confirm(`Hapus produk optimasi "${nama}"?`)) return;

    try {
        const res = await fetch(`<?php echo e(url('shopee/optimasi')); ?>/${id}`, {
            method: 'DELETE',
            headers: {
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
                'Accept': 'application/json',
            },
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.message || 'Gagal menghapus.');
        window.location.reload();
    } catch (err) {
        alert(err.message);
    }
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pembukuan\resources\views\shopee\optimasi\index.blade.php ENDPATH**/ ?>