
<?php $__env->startSection('title', 'Import BRILink'); ?>

<?php $__env->startSection('content'); ?>
<div class="w-full">
    <div class="flex items-center gap-3 mb-6">
        <div class="w-10 h-10 bg-emerald-600 rounded-lg flex items-center justify-center">
            <iconify-icon icon="mdi:bank" class="text-white text-xl"></iconify-icon>
        </div>
        <div>
            <h2 class="text-xl font-bold text-gray-800">Import BRILink</h2>
            <p class="text-sm text-gray-500">Upload file Excel Buku BRILink (6 sheet)</p>
        </div>
    </div>

    
    <?php if(session('success')): ?>
        <div class="bg-green-50 border border-green-200 text-green-800 px-4 py-3 rounded-lg mb-4 flex items-start gap-2">
            <iconify-icon icon="mdi:check-circle" class="text-green-600 text-lg mt-0.5 flex-shrink-0"></iconify-icon>
            <div class="whitespace-pre-line text-sm leading-relaxed"><?php echo e(session('success')); ?></div>
        </div>
    <?php endif; ?>
    <?php if(session('warning')): ?>
        <div class="bg-yellow-50 border border-yellow-200 text-yellow-800 px-4 py-3 rounded-lg mb-4 flex items-start gap-2">
            <iconify-icon icon="mdi:alert" class="text-yellow-600 text-lg mt-0.5 flex-shrink-0"></iconify-icon>
            <div class="whitespace-pre-line text-sm leading-relaxed"><?php echo e(session('warning')); ?></div>
        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="bg-red-50 border border-red-200 text-red-800 px-4 py-3 rounded-lg mb-4 flex items-start gap-2">
            <iconify-icon icon="mdi:alert-circle" class="text-red-600 text-lg mt-0.5 flex-shrink-0"></iconify-icon>
            <div class="whitespace-pre-line text-sm leading-relaxed"><?php echo e(session('error')); ?></div>
        </div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
        <div class="bg-red-50 border border-red-200 text-red-800 px-4 py-3 rounded-lg mb-4">
            <div class="flex items-start gap-2">
                <iconify-icon icon="mdi:alert-circle" class="text-red-600 text-lg mt-0.5 flex-shrink-0"></iconify-icon>
                <ul class="list-disc list-inside text-sm leading-relaxed">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    <?php endif; ?>

    
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6 mb-6">
        <form action="<?php echo e(route('brilink.import.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">
                        Pilih Toko BRILink <span class="text-red-500">*</span>
                    </label>
                    <select name="store_id" required
                            class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-emerald-500 focus:outline-none">
                        <option value="">-- Pilih Toko --</option>
                        <?php $__currentLoopData = $stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($s->id); ?>" <?php echo e(old('store_id') == $s->id ? 'selected' : ''); ?>>
                                <?php echo e($s->nama_toko); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['store_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-xs text-red-500 mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">
                        Tanggal Laporan <span class="text-red-500">*</span>
                    </label>
                    <input type="date" name="tanggal" required
                           value="<?php echo e(old('tanggal', date('Y-m-d'))); ?>"
                           class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-emerald-500 focus:outline-none">
                    <?php $__errorArgs = ['tanggal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-xs text-red-500 mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            
            <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700 mb-1">
                    File Excel BRILink <span class="text-red-500">*</span>
                </label>
                <input type="file" name="file" accept=".xlsx,.xls" required
                       class="w-full text-sm file:mr-3 file:py-2 file:px-4 file:rounded-lg file:border-0
                              file:text-xs file:bg-emerald-600 file:text-white file:font-medium
                              hover:file:bg-emerald-700 file:cursor-pointer file:transition
                              border border-gray-300 rounded-lg">
                <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-xs text-red-500 mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <p class="text-xs text-gray-500 mt-1">
                    Format: <strong>.xlsx</strong> atau <strong>.xls</strong> · Maksimal 20 MB
                </p>
            </div>

            
            <div class="flex justify-end">
                <button type="submit"
                        class="bg-emerald-600 text-white px-6 py-2 rounded-lg hover:bg-emerald-700 transition text-sm font-medium flex items-center gap-2 shadow-sm">
                    <iconify-icon icon="mdi:cloud-upload" class="text-lg"></iconify-icon>
                    Import File
                </button>
            </div>
        </form>
    </div>

    
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div class="px-5 py-4 border-b border-gray-100 flex flex-col md:flex-row md:items-center md:justify-between gap-3">
            <div class="flex items-center gap-2">
                <iconify-icon icon="mdi:history" class="text-emerald-600 text-lg"></iconify-icon>
                <h3 class="font-semibold text-gray-800">Riwayat Import BRILink</h3>
                <span class="text-xs text-gray-500">(<?php echo e($imports->total()); ?> file)</span>
            </div>

            
            <form method="GET" action="<?php echo e(route('brilink.import')); ?>" class="flex flex-wrap items-center gap-2">
                <div>
                    <label class="block text-[10px] font-medium text-gray-500 mb-0.5">Dari</label>
                    <input type="date" name="from" value="<?php echo e($fromInput ?? now()->format('Y-m-d')); ?>"
                        class="border border-gray-300 rounded-lg px-2 py-1.5 text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-none">
                </div>
                <div>
                    <label class="block text-[10px] font-medium text-gray-500 mb-0.5">Sampai</label>
                    <input type="date" name="to" value="<?php echo e($toInput ?? now()->format('Y-m-d')); ?>"
                        class="border border-gray-300 rounded-lg px-2 py-1.5 text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-none">
                </div>
                <div class="flex gap-1 pt-3.5">
                    <button type="submit"
                        class="inline-flex items-center gap-1 bg-emerald-600 text-white px-3 py-1.5 rounded-lg hover:bg-emerald-700 transition text-xs font-medium">
                        <iconify-icon icon="mdi:filter" class="text-sm"></iconify-icon>
                        Filter
                    </button>
                    <?php if(($fromInput ?? null) || ($toInput ?? null)): ?>
                        <a href="<?php echo e(route('brilink.import')); ?>"
                            class="inline-flex items-center gap-1 px-3 py-1.5 text-xs bg-white border border-gray-300 text-gray-500 hover:text-gray-700 rounded-lg transition"
                            title="Reset ke hari ini">
                            <iconify-icon icon="mdi:refresh" class="text-sm"></iconify-icon>
                            Hari Ini
                        </a>
                    <?php endif; ?>
                </div>
            </form>
        </div>

                <table class="w-full text-sm">
            <thead class="bg-gray-50 border-b">
                <tr>
                    <th class="text-left py-3 px-4 text-xs font-semibold text-gray-500 uppercase">File</th>
                    <th class="text-left py-3 px-4 text-xs font-semibold text-gray-500 uppercase">Toko</th>
                    <th class="text-left py-3 px-4 text-xs font-semibold text-gray-500 uppercase">Tanggal</th>
                    <th class="text-center py-3 px-4 text-xs font-semibold text-gray-500 uppercase">Baris</th>
                    <th class="text-center py-3 px-4 text-xs font-semibold text-gray-500 uppercase">Status</th>
                    <th class="text-center py-3 px-4 text-xs font-semibold text-gray-500 uppercase w-24">Aksi</th> 
                </tr>
            </thead>
            <tbody class="divide-y">
                <?php $__empty_1 = true; $__currentLoopData = $imports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="hover:bg-gray-50 transition" id="import-row-<?php echo e($imp->id); ?>">
                    <td class="py-3 px-4 text-xs text-gray-700"><?php echo e($imp->file_name); ?></td>
                    <td class="py-3 px-4 text-gray-700"><?php echo e($imp->store?->nama_toko ?? '-'); ?></td>
                    <td class="py-3 px-4 text-xs">
                        <?php if($imp->periode_start): ?>
                            <?php echo e($imp->periode_start->format('d/m/Y')); ?>

                        <?php else: ?>
                            <span class="text-gray-400 italic">-</span>
                        <?php endif; ?>
                    </td>
                    <td class="py-3 px-4 text-center text-gray-700"><?php echo e($imp->total_rows); ?></td>
                    <td class="py-3 px-4 text-center">
                        <span class="inline-block px-2 py-1 rounded-full text-xs
                            <?php echo e($imp->status === 'imported' ? 'bg-green-50 text-green-700' : 'bg-gray-50 text-gray-700'); ?>">
                            <?php echo e($imp->status); ?>

                        </span>
                    </td>
                    
                    <td class="py-3 px-4 text-center">
                        <button type="button" onclick="deleteImport(<?php echo e($imp->id); ?>, '<?php echo e(addslashes($imp->file_name)); ?>')"
                            class="inline-flex items-center gap-1 text-red-600 hover:bg-red-50 px-2 py-1 rounded text-xs font-medium transition">
                            <iconify-icon icon="mdi:delete" class="text-sm"></iconify-icon> Hapus
                        </button>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6" class="py-12 text-center text-gray-400">
                        <iconify-icon icon="mdi:inbox-outline" class="text-4xl block mb-2 w-max mx-auto"></iconify-icon>
                        <div class="text-sm">Belum ada riwayat import pada rentang tanggal ini.</div>
                        <div class="text-xs mt-1 text-gray-400">
                            Coba ubah filter tanggal atau klik "Hari Ini".
                        </div>
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
        <?php if($imports->hasPages()): ?>
            <div class="px-5 py-4 border-t"><?php echo e($imports->links()); ?></div>
        <?php endif; ?>
    </div>
</div>

<script>
    const CSRF_TOKEN = document.querySelector('meta[name="csrf-token"]').content;

    async function deleteImport(id, fileName) {
        if (!confirm(`Yakin ingin menghapus data import "${fileName}"?\n\nSEMUA data transaksi (Saldo, PPOB, Setoran, Tarik Tunai, Pengeluaran) dari file ini akan ikut terhapus permanen.`)) {
            return;
        }

        try {
            const response = await fetch(`/brilink/import/${id}`, {
                method: 'DELETE',
                headers: {
                    'X-CSRF-TOKEN': CSRF_TOKEN,
                    'Accept': 'application/json',
                }
            });

            const data = await response.json();

            if (!response.ok) {
                alert(data.message || 'Gagal menghapus data.');
                return;
            }

            // Hapus baris dari tabel tanpa reload (efek smooth)
            const row = document.getElementById(`import-row-${id}`);
            if (row) {
                row.style.opacity = '0';
                setTimeout(() => row.remove(), 300);
            }

            // Opsional: bisa pakai window.location.reload() untuk update total baris
            // window.location.reload();

        } catch (err) {
            alert('Gagal menghapus: ' + err.message);
        }
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pembukuan\resources\views/brilink/import.blade.php ENDPATH**/ ?>