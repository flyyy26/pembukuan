<?php
    $small = $small ?? false;
    $sizeClass = $small ? 'text-[9px] px-1.5 py-0.5' : 'text-xs px-2 py-1';
?>

<?php if($growth === null): ?>
    <span class="inline-flex items-center gap-1 bg-gray-50 text-gray-500 <?php echo e($sizeClass); ?> rounded-full font-medium">
        <iconify-icon icon="mdi:minus" class="text-[10px]"></iconify-icon>
        N/A
    </span>
<?php elseif($growth > 0): ?>
    <span class="inline-flex items-center gap-1 bg-green-50 text-green-700 <?php echo e($sizeClass); ?> rounded-full font-medium">
        <iconify-icon icon="mdi:trending-up" class="text-[10px]"></iconify-icon>
        +<?php echo e($growth); ?>%
    </span>
<?php elseif($growth < 0): ?>
    <span class="inline-flex items-center gap-1 bg-red-50 text-red-700 <?php echo e($sizeClass); ?> rounded-full font-medium">
        <iconify-icon icon="mdi:trending-down" class="text-[10px]"></iconify-icon>
        <?php echo e($growth); ?>%
    </span>
<?php else: ?>
    <span class="inline-flex items-center gap-1 bg-gray-50 text-gray-600 <?php echo e($sizeClass); ?> rounded-full font-medium">
        <iconify-icon icon="mdi:minus" class="text-[10px]"></iconify-icon>
        0%
    </span>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\pembukuan\resources\views\shopee\partials\growth-badge.blade.php ENDPATH**/ ?>