

<?php $__env->startSection('title', 'Log Pulsa & PPOB'); ?>

<?php $__env->startSection('content'); ?>
<div class="w-full">

    
    <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
        <div class="flex items-center gap-3">
            <div class="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center flex-shrink-0">
                <iconify-icon icon="mdi:cellphone-link" class="text-white text-xl"></iconify-icon>
            </div>
            <div>
                <h2 class="text-lg sm:text-xl font-bold text-gray-800">Log Pulsa & PPOB</h2>
                <p class="text-xs sm:text-sm text-gray-500"><?php echo e($store?->nama_toko ?? 'Semua Toko'); ?></p>
            </div>
        </div>

        
        <div class="w-full sm:w-auto flex justify-end">
            <button type="button" onclick="openManualModal()" class="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition text-sm font-medium shadow-sm">
                <iconify-icon icon="mdi:plus" class="text-lg"></iconify-icon>
                Tambah Transaksi Manual
            </button>
        </div>
    </div>

    
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4 mb-6">
        <form method="GET" class="grid grid-cols-1 sm:grid-cols-2 md:flex md:flex-wrap gap-3 items-end">
            
            <div class="w-full md:w-48">
                <label class="block text-xs font-medium text-gray-600 mb-1">Toko</label>
                <select name="store" onchange="this.form.submit()" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-transparent">
                    <option value="all" <?php echo e($storeId === 'all' ? 'selected' : ''); ?>>Semua Toko</option>
                    <?php $__currentLoopData = $stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($s->id); ?>" <?php echo e($storeId == $s->id ? 'selected' : ''); ?>><?php echo e($s->nama_toko); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="w-full sm:col-span-2 md:col-span-1 md:flex-1">
                <label class="block text-xs font-medium text-gray-600 mb-1">Cari Kategori / Ket / Nominal</label>
                <div class="relative">
                    <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <iconify-icon icon="mdi:magnify" class="text-gray-400 text-lg"></iconify-icon>
                    </div>
                    <input type="text" name="search" value="<?php echo e($search); ?>" placeholder="Cari kategori, keterangan, atau nominal..." 
                        class="w-full border border-gray-300 rounded-lg pl-10 pr-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-transparent">
                </div>
            </div>

            <div class="w-full sm:w-auto">
                <label class="block text-xs font-medium text-gray-600 mb-1">Dari Tanggal</label>
                <input type="date" name="from" value="<?php echo e($from); ?>" 
                    class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-transparent">
            </div>

            <div class="w-full sm:w-auto">
                <label class="block text-xs font-medium text-gray-600 mb-1">Sampai Tanggal</label>
                <input type="date" name="to" value="<?php echo e($to); ?>" 
                    class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-transparent">
            </div>

            <div class="flex gap-2 w-full md:w-auto mt-2 md:mt-0">
                <button type="submit" class="flex-1 md:flex-none bg-blue-600 text-white px-5 py-2 rounded-lg hover:bg-blue-700 transition text-sm font-medium flex items-center justify-center gap-2">
                    <iconify-icon icon="mdi:filter" class="text-lg"></iconify-icon> Filter
                </button>
                <?php if($search || $from || $to || $storeId !== 'all'): ?>
                    <a href="<?php echo e(route('brilink.log-ppob')); ?>" class="flex-1 md:flex-none text-gray-500 hover:text-gray-700 px-4 py-2 text-sm bg-white border border-gray-300 rounded-lg text-center transition flex items-center justify-center">
                        Reset
                    </a>
                <?php endif; ?>
            </div>
        </form>
    </div>

    
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div class="px-4 sm:px-5 py-4 border-b border-gray-100 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div class="flex items-center gap-2">
                <iconify-icon icon="mdi:table" class="text-blue-600 text-lg"></iconify-icon>
                <h3 class="font-semibold text-gray-800 text-sm sm:text-base">Rincian Transaksi Kasir PPOB</h3>
            </div>
            <div class="text-[10px] sm:text-xs text-gray-500 bg-gray-50 px-2 py-1 rounded border w-max"><?php echo e($ppobData->count()); ?> Data</div>
        </div>

        <div class="overflow-x-auto p-0 sm:p-5">
            <?php if($ppobData->isEmpty()): ?>
                <div class="py-12 text-center text-gray-500">
                    <iconify-icon icon="mdi:inbox-outline" class="text-4xl text-gray-300 block m-auto mb-2 w-max"></iconify-icon>
                    Belum ada data PPOB untuk toko dan filter ini.
                </div>
            <?php else: ?>
                <?php
                    $groupedReports = $ppobData->groupBy('brilink_report_id');
                    
                    // Ambil semua kategori unik
                    $rawCategories = $ppobData->pluck('kategori')->unique()->values()->toArray();
                    
                    // Susun ulang: Sisipkan "Keterangan" setelah "Barang Titip Jual"
                    $allCategories = [];
                    foreach ($rawCategories as $cat) {
                        $allCategories[] = $cat;
                        if (strtolower(trim($cat)) === 'barang titip jual') {
                            $allCategories[] = 'Keterangan'; // Kolom virtual
                        }
                    }
                ?>

                <table class="w-full text-sm border-collapse min-w-max">
                    <thead>
                        <tr class="bg-gray-100">
                            <th class="border border-gray-200 p-2 sm:p-3 text-left text-[10px] sm:text-xs font-semibold text-gray-600 uppercase w-32 sm:w-40 whitespace-nowrap">Tanggal Report</th>
                            <?php $__currentLoopData = $allCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <th class="border border-gray-200 p-2 sm:p-3 text-center text-[10px] sm:text-xs font-semibold text-gray-600 uppercase whitespace-nowrap">
                                    <?php echo e($kategori); ?>

                                </th>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $groupedByDate = $ppobData->groupBy(function($item) {
                                return $item->report->periode_start->format('Y-m-d');
                            });
                        ?>

                        <?php $__currentLoopData = $groupedByDate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date => $itemsInDate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $firstReport = $itemsInDate->first()->report;
                                
                                $rows = [];
                                foreach ($itemsInDate as $item) {
                                    $foundEmptySlot = false;
                                    foreach ($rows as $index => $row) {
                                        if (!isset($row[$item->kategori])) {
                                            $rows[$index][$item->kategori] = [
                                                'nominal' => $item->nominal,
                                                'id' => $item->id,
                                                'keterangan' => $item->keterangan,
                                            ];
                                            $foundEmptySlot = true;
                                            break;
                                        }
                                    }
                                    if (!$foundEmptySlot) {
                                        $rows[] = [ 
                                            $item->kategori => [
                                                'nominal' => $item->nominal,
                                                'id' => $item->id,
                                                'keterangan' => $item->keterangan,
                                            ]
                                        ];
                                    }
                                }
                            ?>

                            <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="hover:bg-gray-50 transition">
                                    <td class="border border-gray-200 p-2 sm:p-3 text-gray-700 font-medium text-xs sm:text-sm whitespace-nowrap">
                                        <?php echo e($firstReport->periode_label ?? '-'); ?>

                                    </td>
                                    
                                    <?php $__currentLoopData = $allCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($kategori === 'Keterangan'): ?>
                                            
                                            <?php 
                                                $transaksiTitip = $row['Barang Titip Jual'] ?? null; 
                                            ?>
                                            <td class="border border-gray-200 p-2 sm:p-3 text-left text-gray-700 text-[10px] sm:text-xs max-w-[120px] sm:max-w-[200px] truncate" title="<?php echo e($transaksiTitip['keterangan'] ?? ''); ?>">
                                                <?php echo e($transaksiTitip['keterangan'] ?? '-'); ?>

                                            </td>
                                        <?php else: ?>
                                            
                                            <?php $transaksi = $row[$kategori] ?? null; ?>
                                            <td class="border border-gray-200 p-2 sm:p-3 text-right text-blue-600 font-semibold group/cell relative">
                                                <?php if($transaksi): ?>
                                                    <div class="flex flex-col items-end justify-center h-full gap-1">
                                                        <span class="whitespace-nowrap text-xs sm:text-sm">Rp <?php echo e(number_format($transaksi['nominal'], 0, ',', '.')); ?></span>
                                                        
                                                        
                                                        <?php if($storeId !== 'all'): ?>
                                                            <div class="flex items-center gap-1 sm:opacity-0 sm:group-hover/cell:opacity-100 transition-opacity duration-150">
                                                                <button type="button"
                                                                        onclick="openEditPpobModal(event, <?php echo e($transaksi['id']); ?>, '<?php echo e(addslashes($kategori)); ?>', <?php echo e($transaksi['nominal']); ?>, '<?php echo e(addslashes($transaksi['keterangan'] ?? '')); ?>')"
                                                                        class="p-1 text-blue-600 hover:bg-blue-100 rounded transition border border-blue-200 sm:border-0 bg-white"
                                                                        title="Edit">
                                                                    <iconify-icon icon="mdi:pencil" class="text-xs sm:text-sm"></iconify-icon>
                                                                </button>
                                                                <button type="button"
                                                                        onclick="deletePpob(<?php echo e($transaksi['id']); ?>, '<?php echo e(addslashes($kategori)); ?>', <?php echo e($transaksi['nominal']); ?>)"
                                                                        class="p-1 text-red-600 hover:bg-red-100 rounded transition border border-red-200 sm:border-0 bg-white"
                                                                        title="Hapus">
                                                                    <iconify-icon icon="mdi:delete" class="text-xs sm:text-sm"></iconify-icon>
                                                                </button>
                                                            </div>
                                                        <?php endif; ?>
                                                    </div>
                                                <?php else: ?>
                                                    <span class="text-gray-400">-</span>
                                                <?php endif; ?>
                                            </td>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        
                        <tr class="bg-blue-50 border-t-2 border-blue-300">
                            <td class="border border-gray-200 p-2 sm:p-3 font-bold text-gray-800 text-left text-xs sm:text-sm whitespace-nowrap">
                                TOTAL REKAP
                            </td>
                            <?php $__currentLoopData = $allCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($kategori === 'Keterangan'): ?>
                                    <td class="border border-gray-200 p-2 sm:p-3 text-center text-gray-400 text-[10px] sm:text-xs italic whitespace-nowrap">
                                        (Ket)
                                    </td>
                                <?php else: ?>
                                    <?php
                                        $totalPerKategori = $ppobData->filter(fn($item) => strtolower(trim($item->kategori)) === strtolower(trim($kategori)))->sum('nominal');
                                    ?>
                                    <td class="border border-gray-200 p-2 sm:p-3 text-center text-blue-800 font-bold text-xs sm:text-sm whitespace-nowrap">
                                        <?php echo e($totalPerKategori > 0 ? 'Rp ' . number_format($totalPerKategori, 0, ',', '.') : '-'); ?>

                                    </td>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                    </tbody>
                    <tfoot>
                        <tr class="bg-blue-600 text-white">
                            <td colspan="<?php echo e(count($allCategories) + 1); ?>" class="p-3 sm:p-4 text-right">
                                <span class="text-[10px] sm:text-sm font-bold uppercase tracking-wider mr-2 sm:mr-4">Total Omset Keseluruhan</span>
                                <span class="text-base sm:text-xl font-bold block sm:inline mt-1 sm:mt-0">Rp <?php echo e(number_format($totalOmset, 0, ',', '.')); ?></span>
                            </td>
                        </tr>
                    </tfoot>
                </table>
            <?php endif; ?>
        </div>
    </div>

</div>

<div id="manualModal" class="fixed inset-0 z-50 hidden items-center justify-center p-4">
    <div class="absolute inset-0 bg-black/50" onclick="closeManualModal()"></div>
    <div class="relative bg-white rounded-xl shadow-xl w-full max-w-md overflow-hidden animate-slide-up max-h-[90vh] flex flex-col">
        <div class="px-5 py-4 border-b border-gray-100 flex justify-between items-center bg-gray-50 flex-shrink-0">
            <div class="flex items-center gap-2">
                <iconify-icon id="manualModalIcon" icon="mdi:plus-circle" class="text-blue-600 text-lg"></iconify-icon>
                <h3 id="manualModalTitle" class="font-bold text-gray-800">Tambah Transaksi Manual</h3>
            </div>
            <button type="button" onclick="closeManualModal()" class="text-gray-400 hover:text-gray-600 transition">
                <iconify-icon icon="mdi:close" class="text-xl"></iconify-icon>
            </button>
        </div>

        <form id="manualForm" onsubmit="submitManualForm(event)" class="overflow-y-auto flex-1 flex flex-col">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="store_id" id="manualStoreId" value="<?php echo e($storeId); ?>">
            <input type="hidden" id="manualPpobId" value="">
            <input type="hidden" id="manualMode" value="create">

            <div class="p-5 space-y-4">
                <div class="hidden bg-red-50 text-red-600 p-3 rounded text-sm" id="modalError"></div>

                
                <div id="tokoFieldWrapper" class="hidden">
                    <label class="block text-xs font-medium text-gray-600 mb-1">Pilih Toko <span class="text-red-500">*</span></label>
                    <select id="manualStoreSelect" required
                        class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none bg-white">
                        <option value="">-- Pilih Toko --</option>
                        <?php $__currentLoopData = $stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($s->id); ?>"><?php echo e($s->nama_toko); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                
                <div id="tanggalManualWrapper">
                    <label class="block text-xs font-medium text-gray-600 mb-1">Tanggal Transaksi</label>
                    <input type="date" name="tanggal" id="manualTanggal" value="<?php echo e(date('Y-m-d')); ?>" required
                        class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none">
                </div>

                
                <div id="tanggalManualReadonlyWrapper" class="hidden">
                    <label class="block text-xs font-medium text-gray-600 mb-1">Tanggal Transaksi</label>
                    <div class="w-full bg-gray-100 border border-gray-200 rounded-lg px-3 py-2 text-sm text-gray-600">
                        <iconify-icon icon="mdi:lock" class="text-gray-400 text-sm mr-1"></iconify-icon>
                        <span id="manualTanggalReadonly">-</span>
                        <span class="text-[10px] text-gray-400 ml-2">(tidak dapat diubah)</span>
                    </div>
                </div>

                <div>
                    <label class="block text-xs font-medium text-gray-600 mb-1">Kategori</label>
                    <select name="kategori" id="manualKategori" required onchange="toggleKeteranganPpob()"
                        class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none">
                        <option value="Pulsa & Deposit">Pulsa & Deposit</option>
                        <option value="Barang Kasir Pintar">Barang Kasir Pintar</option>
                        <option value="Barang Titip Jual">Barang Titip Jual</option>
                        <option value="Fastpay">Fastpay</option>
                        <option value="Payfazz">Payfazz</option>
                        <option value="Buku Warung">Buku Warung</option>
                        <option value="Penambahan Kas">Penambahan Kas</option>
                        <option value="Lain-lain">Lain-lain</option>
                    </select>
                </div>

                <div id="keteranganWrapper" class="hidden">
                    <label class="block text-xs font-medium text-gray-600 mb-1">Keterangan Barang Titip Jual</label>
                    <input type="text" name="keterangan" id="inputKeteranganPpob" placeholder="cth: salman 2, serba 2k 7"
                        class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none">
                </div>

                <div>
                    <label class="block text-xs font-medium text-gray-600 mb-1">Nominal</label>
                    <div class="relative">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <span class="text-gray-500 text-sm font-medium">Rp</span>
                        </div>
                        <input type="text" id="inputNominalManual" name="nominal" required placeholder="0"
                            class="w-full border border-gray-300 rounded-lg pl-10 pr-3 py-2 text-sm font-bold focus:ring-2 focus:ring-blue-500 focus:outline-none">
                    </div>
                </div>
            </div>

            <div class="px-5 py-3 border-t border-gray-100 bg-gray-50 flex justify-end gap-2 flex-shrink-0">
                <button type="button" onclick="closeManualModal()" class="px-4 py-2 text-sm text-gray-600 hover:bg-gray-200 rounded-lg transition">Batal</button>
                <button type="submit" id="btnSubmitManual" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition text-sm font-medium flex items-center gap-2">
                    <iconify-icon icon="mdi:content-save" class="text-lg"></iconify-icon> <span id="btnSubmitManualText">Simpan</span>
                </button>
            </div>
        </form>
    </div>
</div>

<script>
    const CSRF_TOKEN_PPOB = document.querySelector('meta[name="csrf-token"]').content;
    const CURRENT_STORE_ID = "<?php echo e($storeId); ?>";

    function todayLocal() {
        const d = new Date();
        const yyyy = d.getFullYear();
        const mm = String(d.getMonth() + 1).padStart(2, '0');
        const dd = String(d.getDate()).padStart(2, '0');
        return `${yyyy}-${mm}-${dd}`;
    }

    document.addEventListener('DOMContentLoaded', function () {
        const inputNominal = document.getElementById('inputNominalManual');
        if (inputNominal) {
            inputNominal.addEventListener('input', function () {
                let value = this.value.replace(/[^0-9]/g, '');
                this.value = value ? new Intl.NumberFormat('id-ID').format(value) : '';
            });
        }
    });

    function toggleKeteranganPpob() {
        const kategori = document.getElementById('manualKategori').value;
        const wrapper = document.getElementById('keteranganWrapper');
        const input = document.getElementById('inputKeteranganPpob');

        if (kategori === 'Barang Titip Jual') {
            wrapper.classList.remove('hidden');
            input.required = true;
        } else {
            wrapper.classList.add('hidden');
            input.required = false;
            input.value = '';
        }
    }

    function openManualModal() {
        const modal = document.getElementById('manualModal');
        document.getElementById('manualForm').reset();
        document.getElementById('modalError').classList.add('hidden');

        document.getElementById('manualMode').value = 'create';
        document.getElementById('manualPpobId').value = '';
        document.getElementById('manualModalTitle').textContent = 'Tambah Transaksi Manual';
        document.getElementById('manualModalIcon').setAttribute('icon', 'mdi:plus-circle');
        document.getElementById('btnSubmitManualText').textContent = 'Simpan';

        document.getElementById('tanggalManualWrapper').classList.remove('hidden');
        document.getElementById('tanggalManualReadonlyWrapper').classList.add('hidden');
        document.getElementById('manualTanggal').value = todayLocal();

        document.getElementById('inputNominalManual').value = '';

        document.getElementById('keteranganWrapper').classList.add('hidden');
        document.getElementById('inputKeteranganPpob').required = false;

        const tokoWrapper = document.getElementById('tokoFieldWrapper');
        const tokoSelect = document.getElementById('manualStoreSelect');
        const storeIdHidden = document.getElementById('manualStoreId');

        if (CURRENT_STORE_ID === 'all') {
            tokoWrapper.classList.remove('hidden');
            tokoSelect.required = true;
            storeIdHidden.value = '';
        } else {
            tokoWrapper.classList.add('hidden');
            tokoSelect.required = false;
            storeIdHidden.value = CURRENT_STORE_ID;
        }

        modal.classList.remove('hidden');
        modal.classList.add('flex');
    }

    function openEditPpobModal(event, id, kategori, nominal, keterangan = '') {
        const modal = document.getElementById('manualModal');
        document.getElementById('manualForm').reset();
        document.getElementById('modalError').classList.add('hidden');

        document.getElementById('manualMode').value = 'edit';
        document.getElementById('manualPpobId').value = id;
        document.getElementById('manualModalTitle').textContent = 'Edit Transaksi PPOB';
        document.getElementById('manualModalIcon').setAttribute('icon', 'mdi:pencil');
        document.getElementById('btnSubmitManualText').textContent = 'Simpan Perubahan';

        document.getElementById('tokoFieldWrapper').classList.add('hidden');
        document.getElementById('manualStoreSelect').required = false;

        document.getElementById('tanggalManualWrapper').classList.add('hidden');
        document.getElementById('tanggalManualReadonlyWrapper').classList.remove('hidden');

        const btn = event.currentTarget;
        const td = btn.closest('td');
        const tr = td ? td.closest('tr') : null;
        const tanggalText = tr ? tr.querySelector('td').innerText.trim() : '-';
        document.getElementById('manualTanggalReadonly').textContent = tanggalText;

        document.getElementById('manualKategori').value = kategori || '';
        document.getElementById('inputKeteranganPpob').value = keterangan || '';
        
        toggleKeteranganPpob();

        if (nominal > 0) {
            document.getElementById('inputNominalManual').value = new Intl.NumberFormat('id-ID').format(nominal);
        } else {
            document.getElementById('inputNominalManual').value = '';
        }

        modal.classList.remove('hidden');
        modal.classList.add('flex');
    }

    function closeManualModal() {
        document.getElementById('manualModal').classList.add('hidden');
        document.getElementById('manualModal').classList.remove('flex');
    }

    async function submitManualForm(e) {
        e.preventDefault();

        const form = e.target;
        const btn = document.getElementById('btnSubmitManual');
        const btnText = document.getElementById('btnSubmitManualText');
        const errorDiv = document.getElementById('modalError');
        const mode = document.getElementById('manualMode').value;
        const id = document.getElementById('manualPpobId').value;

        const originalText = btnText.textContent;
        btn.disabled = true;
        btnText.textContent = 'Menyimpan...';
        errorDiv.classList.add('hidden');

        const nominalInput = document.getElementById('inputNominalManual');
        const nominalRaw = nominalInput.value.replace(/[^0-9]/g, '');

        const formData = new FormData(form);
        formData.set('nominal', nominalRaw);

        if (mode === 'create' && CURRENT_STORE_ID === 'all') {
            const selectedStore = document.getElementById('manualStoreSelect').value;
            if (!selectedStore) {
                errorDiv.textContent = 'Silakan pilih toko terlebih dahulu.';
                errorDiv.classList.remove('hidden');
                btn.disabled = false;
                btnText.textContent = originalText;
                return;
            }
            formData.set('store_id', selectedStore);
        }

        let url, method;
        if (mode === 'create') {
            url = "<?php echo e(route('brilink.log-ppob.store-ajax')); ?>";
            method = 'POST';
        } else {
            url = `/brilink/log-ppob/${id}/ajax`;
            method = 'POST';
            formData.append('_method', 'PUT');
        }

        try {
            const response = await fetch(url, {
                method: method,
                headers: {
                    'X-CSRF-TOKEN': CSRF_TOKEN_PPOB,
                    'Accept': 'application/json',
                },
                body: formData,
            });

            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.message || 'Gagal menyimpan.');
            }

            closeManualModal();
            window.location.reload();
        } catch (error) {
            errorDiv.textContent = error.message;
            errorDiv.classList.remove('hidden');
            btn.disabled = false;
            btnText.textContent = originalText;
        }
    }

    async function deletePpob(id, kategori, nominal) {
        const nominalFormatted = new Intl.NumberFormat('id-ID').format(nominal);
        if (!confirm(`Yakin hapus transaksi "${kategori}" dengan nominal Rp ${nominalFormatted}?`)) return;

        try {
            const response = await fetch(`/brilink/log-ppob/${id}/ajax`, {
                method: 'DELETE',
                headers: {
                    'X-CSRF-TOKEN': CSRF_TOKEN_PPOB,
                    'Accept': 'application/json',
                },
            });

            const data = await response.json();

            if (!response.ok) {
                alert(data.message || 'Gagal menghapus.');
                return;
            }

            window.location.reload();
        } catch (err) {
            alert('Gagal menghapus: ' + err.message);
        }
    }

    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') closeManualModal();
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pembukuan\resources\views/brilink/log-ppob.blade.php ENDPATH**/ ?>