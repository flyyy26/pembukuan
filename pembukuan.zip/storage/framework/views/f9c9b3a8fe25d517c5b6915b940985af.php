<?php if($totalItems > $perPage): ?>
    <?php
        $totalPages = max(1, (int) ceil($totalItems / $perPage));
        $startPage = max(1, $currentPage - 2);
        $endPage = min($totalPages, $currentPage + 2);
        $firstItem = ($currentPage - 1) * $perPage + 1;
        $lastItem = min($currentPage * $perPage, $totalItems);
        $pageUrl = function ($targetPage) use ($pageParameter) {
            $query = request()->query();
            $query[$pageParameter] = $targetPage;

            return route('shopee.index', $query);
        };
    ?>
    <div class="px-5 py-4 border-t border-gray-100 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div class="text-xs text-gray-500">
            Menampilkan <?php echo e($firstItem); ?>–<?php echo e($lastItem); ?> dari <?php echo e($totalItems); ?> <?php echo e($itemLabel); ?>

        </div>
        <nav class="flex flex-wrap gap-1" aria-label="Pagination">
            <?php if($currentPage > 1): ?>
                <a href="<?php echo e($pageUrl($currentPage - 1)); ?>"
                   aria-label="Halaman sebelumnya"
                   class="px-3 py-1.5 rounded-lg border border-gray-300 text-sm text-gray-600 hover:bg-gray-50 transition">
                    &laquo;
                </a>
            <?php endif; ?>

            <?php if($startPage > 1): ?>
                <a href="<?php echo e($pageUrl(1)); ?>"
                   class="px-3 py-1.5 rounded-lg border border-gray-300 text-sm text-gray-600 hover:bg-gray-50 transition">1</a>
                <?php if($startPage > 2): ?>
                    <span class="px-2 py-1.5 text-gray-400">&hellip;</span>
                <?php endif; ?>
            <?php endif; ?>

            <?php for($pageNumber = $startPage; $pageNumber <= $endPage; $pageNumber++): ?>
                <a href="<?php echo e($pageUrl($pageNumber)); ?>"
                   <?php if($pageNumber === $currentPage): ?> aria-current="page" <?php endif; ?>
                   class="px-3 py-1.5 rounded-lg text-sm transition
                          <?php echo e($pageNumber === $currentPage
                              ? 'bg-blue-600 text-white font-medium shadow-sm'
                              : 'border border-gray-300 text-gray-600 hover:bg-gray-50'); ?>">
                    <?php echo e($pageNumber); ?>

                </a>
            <?php endfor; ?>

            <?php if($endPage < $totalPages): ?>
                <?php if($endPage < $totalPages - 1): ?>
                    <span class="px-2 py-1.5 text-gray-400">&hellip;</span>
                <?php endif; ?>
                <a href="<?php echo e($pageUrl($totalPages)); ?>"
                   class="px-3 py-1.5 rounded-lg border border-gray-300 text-sm text-gray-600 hover:bg-gray-50 transition">
                    <?php echo e($totalPages); ?>

                </a>
            <?php endif; ?>

            <?php if($currentPage < $totalPages): ?>
                <a href="<?php echo e($pageUrl($currentPage + 1)); ?>"
                   aria-label="Halaman berikutnya"
                   class="px-3 py-1.5 rounded-lg border border-gray-300 text-sm text-gray-600 hover:bg-gray-50 transition">
                    &raquo;
                </a>
            <?php endif; ?>
        </nav>
    </div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\pembukuan\resources\views/shopee/partials/pagination.blade.php ENDPATH**/ ?>