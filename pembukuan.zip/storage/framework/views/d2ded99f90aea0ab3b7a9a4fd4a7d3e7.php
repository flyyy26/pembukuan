

<?php $__env->startSection('title', 'Laporan TikTok'); ?>

<?php $__env->startSection('content'); ?>
<div class="w-full">

    
    <div class="flex justify-between items-start mb-6">
        <div class="flex items-center gap-3 mb-1">
            <div class="w-10 h-10 bg-gray-900 rounded-lg flex items-center justify-center">
                <iconify-icon icon="mdi:music-note" class="text-white text-xl"></iconify-icon>
            </div>
            <div>
                <h2 class="text-xl font-bold text-gray-800">Laporan TikTok</h2>
                <p class="text-sm text-gray-500"><?php echo e($store?->nama_toko ?? 'Belum pilih toko'); ?></p>
            </div>
        </div>

        <?php if($storeId): ?>
        <div class="flex gap-2">
            
            <a href="<?php echo e(route('tiktok.export.pdf', array_filter([
                'store'  => $storeId,
                'from'   => $from,
                'to'     => $to,
                'search' => $search,
            ]))); ?>"
            target="_blank"
            class="inline-flex items-center gap-2 bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition text-sm font-medium shadow-sm">
                <iconify-icon icon="mdi:file-pdf-box" class="text-lg"></iconify-icon>
                Export PDF
            </a>

            
            <a href="<?php echo e(route('tiktok.compare', ['store' => $storeId])); ?>"
            class="inline-flex items-center gap-2 bg-pink-600 text-white px-4 py-2 rounded-lg hover:bg-pink-700 transition text-sm font-medium shadow-sm">
                <iconify-icon icon="mdi:compare-horizontal" class="text-lg"></iconify-icon>
                Perbandingan
            </a>

            
            <a href="<?php echo e(route('tiktok.mapping', $storeId)); ?>"
            class="inline-flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition text-sm font-medium shadow-sm">
                <iconify-icon icon="mdi:link-variant" class="text-lg"></iconify-icon>
                Cocokan Produk
            </a>
        </div>
        <?php endif; ?>
    </div>

    
    <?php if(session('success')): ?>
        <div class="bg-green-50 border border-green-200 text-green-800 px-4 py-3 rounded-lg mb-6 flex items-start gap-2">
            <iconify-icon icon="mdi:check-circle" class="text-green-600 text-lg mt-0.5"></iconify-icon>
            <div><?php echo e(session('success')); ?></div>
        </div>
    <?php endif; ?>

    <?php if($stores->isEmpty()): ?>
        <div class="bg-yellow-50 border border-yellow-200 text-yellow-800 px-4 py-4 rounded-lg mb-6 flex items-start gap-2">
            <iconify-icon icon="mdi:alert" class="text-yellow-600 text-lg mt-0.5"></iconify-icon>
            <div>
                <strong>Belum ada toko TikTok.</strong>
                Silakan <a href="<?php echo e(route('stores.index', ['modal' => 'create'])); ?>" class="underline font-semibold">tambah toko</a> dulu.
            </div>
        </div>
    <?php else: ?>

        
        <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4 mb-6">
            <form method="GET" class="flex gap-3 items-end flex-wrap">
                <div class="flex-1 min-w-[180px]">
                    <label class="block text-xs font-medium text-gray-600 mb-1">Toko</label>
                    <select name="store" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-gray-800 focus:border-transparent">
                        <?php $__currentLoopData = $stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($s->id); ?>" <?php echo e($storeId == $s->id ? 'selected' : ''); ?>><?php echo e($s->nama_toko); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="flex-1 min-w-[220px]">
                    <label class="block text-xs font-medium text-gray-600 mb-1">Cari SKU / Produk</label>
                    <div class="relative">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <iconify-icon icon="mdi:magnify" class="text-gray-400 text-lg"></iconify-icon>
                        </div>
                        <input type="text"
                            name="search"
                            value="<?php echo e($search ?? ''); ?>"
                            placeholder="Cari SKU TikTok / nama produk / SKU internal..."
                            class="w-full border border-gray-300 rounded-lg pl-10 pr-3 py-2 text-sm
                                    focus:outline-none focus:ring-2 focus:ring-gray-800 focus:border-transparent">
                    </div>
                </div>
                <div>
                    <label class="block text-xs font-medium text-gray-600 mb-1">Dari</label>
                    <input type="date" name="from" value="<?php echo e($from); ?>"
                        class="border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-gray-800 focus:border-transparent">
                </div>
                <div>
                    <label class="block text-xs font-medium text-gray-600 mb-1">Sampai</label>
                    <input type="date" name="to" value="<?php echo e($to); ?>"
                        class="border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-gray-800 focus:border-transparent">
                </div>
                <button type="submit"
                        class="inline-flex items-center gap-2 bg-gray-800 text-white px-4 py-2 rounded-lg hover:bg-gray-900 transition text-sm font-medium">
                    <iconify-icon icon="mdi:filter" class="text-lg"></iconify-icon>
                    Filter
                </button>
                <?php if($from || $to || !empty($search)): ?>
                    <a href="<?php echo e(route('tiktok.index', ['store' => $storeId])); ?>"
                    class="inline-flex items-center gap-2 text-gray-500 hover:text-gray-700 px-3 py-2 text-sm">
                        <iconify-icon icon="mdi:close" class="text-lg"></iconify-icon>
                        Reset
                    </a>
                <?php endif; ?>
            </form>

            <?php if(!empty($search)): ?>
                <div class="mt-3 flex items-center gap-2 text-xs text-gray-500">
                    <iconify-icon icon="mdi:information-outline" class="text-sm"></iconify-icon>
                    Menampilkan hasil untuk: <strong class="text-gray-700">"<?php echo e($search); ?>"</strong>
                    <span class="text-gray-400">·</span>
                    <span><?php echo e($summary['sku_total']); ?> SKU ditemukan</span>
                </div>
            <?php endif; ?>
        </div>

        
        <?php
            $tabs = [
                ['id' => 'ringkasan', 'label' => 'Ringkasan', 'icon' => 'mdi:view-dashboard-outline'],
                ['id' => 'bulanan',   'label' => 'Bulanan',   'icon' => 'mdi:calendar-month-outline'],
                ['id' => 'top',       'label' => 'Top Produk','icon' => 'mdi:trophy-outline'],
                ['id' => 'sku',       'label' => 'Per SKU',   'icon' => 'mdi:format-list-bulleted'],
            ];
            $hasSearch = !empty($search);
            $requestedTab = request()->input('tab');
            if ($requestedTab) {
                $activeTab = $requestedTab;
            } elseif ($hasSearch) {
                $activeTab = 'sku';
            } else {
                $activeTab = 'ringkasan';
            }
        ?>

        <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden mb-6">
            <div class="flex border-b border-gray-100 overflow-x-auto">
                <?php $__currentLoopData = $tabs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $isActive = $activeTab === $tab['id']; ?>
                    <a href="<?php echo e(request()->fullUrlWithQuery(['tab' => $tab['id'], 'page' => 1])); ?>"
                       class="flex items-center gap-2 px-5 py-3 text-sm font-medium whitespace-nowrap transition border-b-2
                              <?php echo e($isActive
                                  ? 'text-gray-900 border-gray-800 bg-gray-50/50'
                                  : 'text-gray-600 border-transparent hover:text-gray-800 hover:bg-gray-50'); ?>">
                        <iconify-icon icon="<?php echo e($tab['icon']); ?>" class="text-lg"></iconify-icon>
                        <?php echo e($tab['label']); ?>

                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        
        <?php if($activeTab === 'ringkasan'): ?>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-5">
                    <div class="flex items-center justify-between mb-3">
                        <div class="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center">
                            <iconify-icon icon="mdi:receipt-text-outline" class="text-gray-600 text-xl"></iconify-icon>
                        </div>
                    </div>
                    <div class="text-xs text-gray-500 mb-1">Total Transaksi</div>
                    <div class="text-2xl font-bold text-gray-800"><?php echo e(number_format($summary['total_rows'])); ?></div>
                </div>

                <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-5">
                    <div class="flex items-center justify-between mb-3">
                        <div class="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                            <iconify-icon icon="mdi:cash-multiple" class="text-blue-600 text-xl"></iconify-icon>
                        </div>
                    </div>
                    <div class="text-xs text-gray-500 mb-1">Net Revenue</div>
                    <div class="text-2xl font-bold text-blue-600">
                        <span class="text-sm text-gray-400 font-normal">Rp</span>
                        <?php echo e(number_format($summary['net_revenue'], 0, ',', '.')); ?>

                    </div>
                </div>

                <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-5">
                    <div class="flex items-center justify-between mb-3">
                        <div class="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
                            <iconify-icon icon="mdi:package-variant-closed" class="text-orange-600 text-xl"></iconify-icon>
                        </div>
                    </div>
                    <div class="text-xs text-gray-500 mb-1">Total HPP</div>
                    <div class="text-2xl font-bold text-orange-600">
                        <span class="text-sm text-gray-400 font-normal">Rp</span>
                        <?php echo e(number_format($summary['total_hpp'], 0, ',', '.')); ?>

                    </div>
                </div>

                <div class="bg-gradient-to-br from-green-500 to-emerald-600 rounded-xl shadow-sm p-5 text-white">
                    <div class="flex items-center justify-between mb-3">
                        <div class="w-10 h-10 bg-white/20 rounded-lg flex items-center justify-center">
                            <iconify-icon icon="mdi:chart-line" class="text-white text-xl"></iconify-icon>
                        </div>
                    </div>
                    <div class="text-xs text-white/80 mb-1">Profit</div>
                    <div class="text-2xl font-bold">
                        <span class="text-sm text-white/70 font-normal">Rp</span>
                        <?php echo e(number_format($summary['profit'], 0, ',', '.')); ?>

                    </div>
                </div>
            </div>

            <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-5 mb-6">
                <div class="flex items-center gap-2 mb-4">
                    <iconify-icon icon="mdi:calculator-variant" class="text-gray-600 text-lg"></iconify-icon>
                    <h3 class="font-semibold text-gray-800">Breakdown Biaya Platform</h3>
                </div>

                <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
                    <?php
                        $biaya = [
                            ['label' => 'Komisi',   'value' => $summary['biaya_komisi'],   'icon' => 'mdi:percent'],
                            ['label' => 'Layanan',  'value' => $summary['biaya_layanan'],  'icon' => 'mdi:cog'],
                            ['label' => 'Ongkir',   'value' => $summary['biaya_ongkir'],   'icon' => 'mdi:truck-delivery'],
                            ['label' => 'Afiliasi', 'value' => $summary['biaya_afiliasi'], 'icon' => 'mdi:account-group'],
                            ['label' => 'Pajak',    'value' => $summary['biaya_pajak'],    'icon' => 'mdi:file-document'],
                            ['label' => 'Lainnya',  'value' => $summary['biaya_lainnya'],  'icon' => 'mdi:dots-horizontal'],
                        ];
                    ?>
                    <?php $__currentLoopData = $biaya; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="border border-gray-100 rounded-lg p-3">
                        <div class="flex items-center gap-1.5 mb-1">
                            <iconify-icon icon="<?php echo e($b['icon']); ?>" class="text-gray-400 text-sm"></iconify-icon>
                            <div class="text-xs text-gray-500"><?php echo e($b['label']); ?></div>
                        </div>
                        <div class="text-sm font-semibold text-gray-800">
                            <?php echo e(number_format($b['value'], 0, ',', '.')); ?>

                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-5">
                    <div class="flex items-center justify-between mb-3">
                        <div class="flex items-center gap-2">
                            <iconify-icon icon="mdi:link-variant" class="text-purple-600 text-lg"></iconify-icon>
                            <div class="text-sm font-medium text-gray-700">SKU Dimapping</div>
                        </div>
                        <div class="text-xs text-gray-500">
                            <?php echo e($summary['sku_total'] > 0 ? round(($summary['sku_mapped'] / $summary['sku_total']) * 100, 1) : 0); ?>%
                        </div>
                    </div>
                    <div class="flex items-baseline gap-2 mb-3">
                        <span class="text-3xl font-bold text-purple-600"><?php echo e($summary['sku_mapped']); ?></span>
                        <span class="text-lg text-gray-400">/</span>
                        <span class="text-lg text-gray-600"><?php echo e($summary['sku_total']); ?></span>
                        <span class="text-xs text-gray-500">SKU</span>
                    </div>
                    <div class="w-full bg-gray-100 rounded-full h-2">
                        <?php $pct = $summary['sku_total'] > 0 ? ($summary['sku_mapped'] / $summary['sku_total']) * 100 : 0; ?>
                        <div class="bg-purple-500 h-2 rounded-full transition-all" style="width: <?php echo e($pct); ?>%"></div>
                    </div>
                </div>

                <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-5">
                    <div class="flex items-center justify-between mb-3">
                        <div class="flex items-center gap-2">
                            <iconify-icon icon="mdi:check-decagram" class="text-green-600 text-lg"></iconify-icon>
                            <div class="text-sm font-medium text-gray-700">Transaksi Matched</div>
                        </div>
                        <div class="text-xs text-gray-500">
                            <?php echo e($summary['total_transaksi'] > 0 ? round(($summary['transaksi_matched'] / $summary['total_transaksi']) * 100, 1) : 0); ?>%
                        </div>
                    </div>
                    <div class="flex items-baseline gap-2 mb-3">
                        <span class="text-3xl font-bold text-green-600"><?php echo e($summary['transaksi_matched']); ?></span>
                        <span class="text-lg text-gray-400">/</span>
                        <span class="text-lg text-gray-600"><?php echo e($summary['total_transaksi']); ?></span>
                        <span class="text-xs text-gray-500">transaksi</span>
                    </div>
                    <div class="w-full bg-gray-100 rounded-full h-2">
                        <?php $pct2 = $summary['total_transaksi'] > 0 ? ($summary['transaksi_matched'] / $summary['total_transaksi']) * 100 : 0; ?>
                        <div class="bg-green-500 h-2 rounded-full transition-all" style="width: <?php echo e($pct2); ?>%"></div>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        
        <?php if($activeTab === 'bulanan'): ?>
            <?php if(!empty($monthlyData['months'])): ?>
            <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-5 mb-6">
                <div class="flex items-center justify-between mb-4">
                    <div class="flex items-center gap-2">
                        <iconify-icon icon="mdi:chart-timeline-variant" class="text-gray-600 text-lg"></iconify-icon>
                        <h3 class="font-semibold text-gray-800">Rekap Per Bulan</h3>
                    </div>
                    <?php if($monthlyData['best_month']): ?>
                        <div class="inline-flex items-center gap-2 bg-yellow-50 border border-yellow-200 px-3 py-1.5 rounded-lg">
                            <iconify-icon icon="mdi:trophy" class="text-yellow-600 text-base"></iconify-icon>
                            <span class="text-xs text-yellow-800">
                                Bulan terbaik: <strong><?php echo e($monthlyData['best_month']['label']); ?></strong>
                                (Rp <?php echo e(number_format($monthlyData['best_month']['profit'], 0, ',', '.')); ?>)
                            </span>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="mb-6" style="height: 280px;">
                    <canvas id="monthlyChart"></canvas>
                </div>

                <div class="overflow-x-auto border border-gray-100 rounded-lg">
                    <table class="w-full text-sm">
                        <thead class="bg-gray-50 border-b border-gray-100">
                            <tr>
                                <th class="text-left py-3 px-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">Bulan</th>
                                <th class="text-center py-3 px-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">Transaksi</th>
                                <th class="text-center py-3 px-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">Qty</th>
                                <th class="text-right py-3 px-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">Net Revenue</th>
                                <th class="text-right py-3 px-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">HPP</th>
                                <th class="text-right py-3 px-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">Profit</th>
                                <th class="text-center py-3 px-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">Growth</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-100">
                            <?php $__currentLoopData = $monthlyData['months']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="hover:bg-gray-50 transition">
                                <td class="py-3 px-4">
                                    <div class="font-medium text-gray-800"><?php echo e($m['label']); ?></div>
                                    <div class="text-[10px] text-gray-400 font-mono"><?php echo e($m['year_month']); ?></div>
                                </td>
                                <td class="py-3 px-4 text-center"><?php echo e(number_format($m['transaksi'])); ?></td>
                                <td class="py-3 px-4 text-center"><?php echo e(number_format($m['qty'])); ?></td>
                                <td class="py-3 px-4 text-right"><?php echo e(number_format($m['net_revenue'], 0, ',', '.')); ?></td>
                                <td class="py-3 px-4 text-right text-orange-600"><?php echo e(number_format($m['hpp_total'], 0, ',', '.')); ?></td>
                                <td class="py-3 px-4 text-right font-bold <?php echo e($m['profit'] > 0 ? 'text-green-600' : 'text-red-600'); ?>">
                                    <?php echo e(number_format($m['profit'], 0, ',', '.')); ?>

                                </td>
                                <td class="py-3 px-4 text-center">
                                    <?php if($m['growth'] === null): ?>
                                        <span class="text-xs text-gray-400">—</span>
                                    <?php elseif($m['growth'] > 0): ?>
                                        <span class="inline-flex items-center gap-1 bg-green-50 text-green-700 px-2 py-1 rounded-full text-xs font-medium">
                                            <iconify-icon icon="mdi:trending-up" class="text-sm"></iconify-icon>
                                            +<?php echo e($m['growth']); ?>%
                                        </span>
                                    <?php elseif($m['growth'] < 0): ?>
                                        <span class="inline-flex items-center gap-1 bg-red-50 text-red-700 px-2 py-1 rounded-full text-xs font-medium">
                                            <iconify-icon icon="mdi:trending-down" class="text-sm"></iconify-icon>
                                            <?php echo e($m['growth']); ?>%
                                        </span>
                                    <?php else: ?>
                                        <span class="text-xs text-gray-400">0%</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php else: ?>
                <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-12 text-center">
                    <iconify-icon icon="mdi:chart-line" class="text-4xl text-gray-300 block m-auto mb-2 w-max"></iconify-icon>
                    <div class="text-gray-500">Belum ada data bulanan.</div>
                </div>
            <?php endif; ?>
        <?php endif; ?>

        
        <?php if($activeTab === 'top'): ?>
            <?php if(!empty($topProducts['insight']) && $topProducts['insight']['total_sku'] > 0): ?>
                <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
                        <div class="text-xs text-gray-500 mb-2">SKU Ter-mapping</div>
                        <div class="text-xl font-bold text-gray-800"><?php echo e($topProducts['insight']['total_sku']); ?></div>
                    </div>
                    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
                        <div class="text-xs text-gray-500 mb-2">SKU Profit</div>
                        <div class="text-xl font-bold text-green-600"><?php echo e($topProducts['insight']['sku_profit']); ?></div>
                    </div>
                    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
                        <div class="text-xs text-gray-500 mb-2">SKU Rugi</div>
                        <div class="text-xl font-bold text-red-600"><?php echo e($topProducts['insight']['sku_rugi']); ?></div>
                    </div>
                    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
                        <div class="text-xs text-gray-500 mb-2">Rata-rata Profit</div>
                        <div class="text-xl font-bold text-blue-600">Rp <?php echo e(number_format($topProducts['insight']['avg_profit'], 0, ',', '.')); ?></div>
                    </div>
                </div>

                <div class="grid grid-cols-1 lg:grid-cols-3 gap-4">
                    <?php $__currentLoopData = [
                        ['title' => 'Top 10 Terlaris', 'key' => 'top_qty', 'color' => 'blue', 'icon' => 'mdi:fire', 'value_key' => 'total_qty', 'suffix' => 'unit'],
                        ['title' => 'Top 10 Paling Profit', 'key' => 'top_profit', 'color' => 'green', 'icon' => 'mdi:trophy', 'value_key' => 'profit', 'suffix' => 'profit'],
                        ['title' => '10 Profit Terendah', 'key' => 'bottom_profit', 'color' => 'red', 'icon' => 'mdi:alert-octagon', 'value_key' => 'profit', 'suffix' => 'profit'],
                    ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
                        <div class="px-4 py-3 border-b border-gray-100 flex items-center gap-2 bg-gradient-to-r from-<?php echo e($section['color']); ?>-50 to-white">
                            <div class="w-8 h-8 bg-<?php echo e($section['color']); ?>-100 rounded-lg flex items-center justify-center">
                                <iconify-icon icon="<?php echo e($section['icon']); ?>" class="text-<?php echo e($section['color']); ?>-600 text-lg"></iconify-icon>
                            </div>
                            <h4 class="font-semibold text-gray-800 text-sm"><?php echo e($section['title']); ?></h4>
                        </div>
                        <div class="divide-y divide-gray-100">
                            <?php $__empty_1 = true; $__currentLoopData = $topProducts[$section['key']]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idx => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="flex items-center gap-3 px-4 py-2.5 hover:bg-gray-50 transition">
                                <div class="w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 bg-<?php echo e($idx < 3 ? $section['color'] : 'gray'); ?>-100 text-<?php echo e($idx < 3 ? $section['color'] : 'gray'); ?>-700">
                                    <?php echo e($idx + 1); ?>

                                </div>
                                <div class="min-w-0 flex-1">
                                    <div class="font-mono text-[11px] text-gray-700 truncate"><?php echo e($p['marketplace_sku']); ?></div>
                                    <div class="text-[10px] text-gray-500 truncate"><?php echo e(\Illuminate\Support\Str::limit($p['nama_produk'], 30, '…')); ?></div>
                                </div>
                                <div class="text-right flex-shrink-0">
                                    <div class="text-sm font-bold text-<?php echo e($section['color']); ?>-600">
                                        <?php echo e(number_format($p[$section['value_key']], 0, ',', '.')); ?>

                                    </div>
                                    <div class="text-[10px] text-gray-400"><?php echo e($section['suffix']); ?></div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="px-4 py-8 text-center text-xs text-gray-400">Belum ada data</div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php else: ?>
                <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-12 text-center">
                    <iconify-icon icon="mdi:trophy" class="text-4xl text-gray-300 block m-auto mb-2 w-max"></iconify-icon>
                    <div class="text-gray-500">Belum ada SKU yang dimapping. Cocokan produk dulu untuk melihat Top 10.</div>
                    <a href="<?php echo e(route('tiktok.mapping', $storeId)); ?>"
                       class="inline-flex items-center gap-2 mt-4 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition text-sm font-medium">
                        <iconify-icon icon="mdi:link-variant" class="text-lg"></iconify-icon>
                        Cocokan Produk
                    </a>
                </div>
            <?php endif; ?>
        <?php endif; ?>

        
        <?php if($activeTab === 'sku'): ?>
            <div id="skuTableContainer">
                <?php echo $__env->make('tiktok.partials.sku-table', [
                    'perProduk' => $perProduk,
                    'totalProduk' => $totalProduk,
                    'page' => $page,
                    'perPage' => $perPage,
                    'storeId' => $storeId,
                    'from' => $from,
                    'to' => $to,
                    'search' => $search,
                ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
        <?php endif; ?>

    <?php endif; ?>
</div>


<?php if(!empty($monthlyData['months']) && $activeTab === 'bulanan'): ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function () {
    const ctx = document.getElementById('monthlyChart');
    if (!ctx) return;
    const months = <?php echo json_encode(array_reverse($monthlyData['months']), 15, 512) ?>;
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: months.map(m => m.label),
            datasets: [
                { label: 'Net Revenue', data: months.map(m => m.net_revenue), backgroundColor: 'rgba(59, 130, 246, 0.7)', borderRadius: 6 },
                { label: 'Profit', data: months.map(m => m.profit), backgroundColor: 'rgba(16, 185, 129, 0.7)', borderRadius: 6 },
            ],
        },
        options: {
            responsive: true, maintainAspectRatio: false,
            plugins: {
                legend: { position: 'top', labels: { font: { size: 12, family: 'Geist' }, usePointStyle: true, padding: 16 } },
                tooltip: { callbacks: { label: (ctx) => ctx.dataset.label + ': Rp ' + (ctx.parsed.y || 0).toLocaleString('id-ID') } },
            },
            scales: {
                x: { grid: { display: false } },
                y: { beginAtZero: true, ticks: { callback: v => v >= 1000000 ? 'Rp ' + (v/1000000).toFixed(1) + 'jt' : v >= 1000 ? 'Rp ' + (v/1000).toFixed(0) + 'rb' : 'Rp ' + v } },
            },
        },
    });
});
</script>
<?php endif; ?>

<script>
async function loadSkuPage(page) {
    const container = document.getElementById('skuTableContainer');
    if (!container) return;
    container.style.opacity = '0.5';
    container.style.pointerEvents = 'none';
    try {
        const params = new URLSearchParams({
            page: page,
            store: '<?php echo e($storeId ?? ""); ?>',
            from: '<?php echo e($from ?? ""); ?>',
            to: '<?php echo e($to ?? ""); ?>',
            search: '<?php echo e($search ?? ""); ?>',
        });
        const response = await fetch(`<?php echo e(route('tiktok.sku.table')); ?>?${params}`, { headers: { 'Accept': 'text/html' } });
        const html = await response.text();
        container.innerHTML = html;
        container.style.opacity = '1';
        container.style.pointerEvents = 'auto';
        container.scrollIntoView({ behavior: 'smooth', block: 'start' });
    } catch (err) {
        container.style.opacity = '1';
        container.style.pointerEvents = 'auto';
    }
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pembukuan\resources\views/tiktok/index.blade.php ENDPATH**/ ?>