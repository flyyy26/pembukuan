

<?php $__env->startSection('title', 'Laporan Pengeluaran BRILink'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $activeTab = request()->input('tab', 'semua');
?>
<div class="w-full">

    
    <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
        <div class="flex items-center gap-3">
            <div class="w-10 h-10 bg-red-600 rounded-lg flex items-center justify-center flex-shrink-0">
                <iconify-icon icon="mdi:cash-minus" class="text-white text-xl"></iconify-icon>
            </div>
            <div>
                <h2 class="text-lg sm:text-xl font-bold text-gray-800">Laporan Pengeluaran</h2>
                <p class="text-xs sm:text-sm text-gray-500"><?php echo e($store?->nama_toko ?? 'Semua Toko'); ?></p>
            </div>
        </div>

        
        <button type="button" onclick="openPengeluaranModal()" class="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition text-sm font-medium shadow-sm">
            <iconify-icon icon="mdi:plus" class="text-lg"></iconify-icon>
            Tambah Pengeluaran
        </button>
    </div>

    
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4 mb-6">
        <form method="GET" class="grid grid-cols-1 sm:grid-cols-2 md:flex md:flex-wrap gap-3 items-end">
            <input type="hidden" name="tab" value="<?php echo e($activeTab); ?>">

            <div class="w-full md:w-48">
                <label class="block text-xs font-medium text-gray-600 mb-1">Toko</label>
                <select name="store" onchange="this.form.submit()" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-red-600 focus:border-transparent">
                    <option value="all" <?php echo e($storeId === 'all' ? 'selected' : ''); ?>>Semua Toko</option>
                    <?php $__currentLoopData = $stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($s->id); ?>" <?php echo e($storeId == $s->id ? 'selected' : ''); ?>><?php echo e($s->nama_toko); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="w-full sm:col-span-2 md:col-span-1 md:flex-1">
                <label class="block text-xs font-medium text-gray-600 mb-1">Cari Catatan / Kategori</label>
                <div class="relative">
                    <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <iconify-icon icon="mdi:magnify" class="text-gray-400 text-lg"></iconify-icon>
                    </div>
                    <input type="text" name="search" value="<?php echo e($search); ?>" placeholder="Cari keterangan pengeluaran..." 
                        class="w-full border border-gray-300 rounded-lg pl-10 pr-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-red-600 focus:border-transparent">
                </div>
            </div>

            <div class="w-full sm:w-auto">
                <label class="block text-xs font-medium text-gray-600 mb-1">Dari Tanggal</label>
                <input type="date" name="from" value="<?php echo e($from); ?>" 
                    class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-red-600 focus:border-transparent">
            </div>

            <div class="w-full sm:w-auto">
                <label class="block text-xs font-medium text-gray-600 mb-1">Sampai Tanggal</label>
                <input type="date" name="to" value="<?php echo e($to); ?>" 
                    class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-red-600 focus:border-transparent">
            </div>

            <div class="flex gap-2 w-full md:w-auto mt-2 md:mt-0">
                <button type="submit" class="flex-1 md:flex-none bg-red-600 text-white px-5 py-2 rounded-lg hover:bg-red-700 transition text-sm font-medium flex items-center justify-center gap-2">
                    <iconify-icon icon="mdi:filter" class="text-lg"></iconify-icon> Filter
                </button>
                <?php if($from || $to || $search || $storeId !== 'all'): ?>
                    <a href="<?php echo e(route('brilink.pengeluaran', ['tab' => $activeTab])); ?>" class="flex-1 md:flex-none text-gray-500 hover:text-gray-700 px-4 py-2 text-sm bg-white border border-gray-300 rounded-lg text-center transition flex items-center justify-center">
                        Reset
                    </a>
                <?php endif; ?>
            </div>
        </form>
    </div>

    
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden mb-6">
        <div class="flex border-b border-gray-100 overflow-x-auto">
            <a href="<?php echo e(request()->fullUrlWithQuery(['tab' => 'semua'])); ?>"
               class="flex items-center gap-2 px-4 sm:px-5 py-3 text-xs sm:text-sm font-medium whitespace-nowrap transition border-b-2
                      <?php echo e(strtolower($activeTab) === 'semua' ? 'text-gray-900 border-red-600 bg-gray-50/50' : 'text-gray-600 border-transparent hover:text-gray-800 hover:bg-gray-50'); ?>">
                <iconify-icon icon="mdi:view-grid-outline" class="text-base sm:text-lg"></iconify-icon>
                Semua Kategori
            </a>

            <?php $__currentLoopData = $kategoriList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $isActive = strtolower($activeTab) === strtolower($kategori); ?>
                <a href="<?php echo e(request()->fullUrlWithQuery(['tab' => strtolower($kategori)])); ?>"
                   class="flex items-center gap-2 px-4 sm:px-5 py-3 text-xs sm:text-sm font-medium whitespace-nowrap transition border-b-2
                          <?php echo e($isActive ? 'text-gray-900 border-red-600 bg-gray-50/50' : 'text-gray-600 border-transparent hover:text-gray-800 hover:bg-gray-50'); ?>">
                    <iconify-icon icon="mdi:folder-outline" class="text-base sm:text-lg"></iconify-icon>
                    <?php echo e($kategori); ?>

                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <?php
            $isPiutangTab = str_contains(strtolower(trim($activeTab)), 'piutang');
        ?>

        <div class="px-4 sm:px-5 py-4 border-b border-gray-100 flex flex-col md:flex-row md:items-center justify-between gap-3">
            <div class="flex items-center gap-2">
                <iconify-icon icon="mdi:table" class="text-red-600 text-lg"></iconify-icon>
                <h3 class="font-semibold text-gray-800 text-sm sm:text-base">Rincian: <?php echo e(ucwords($activeTab)); ?></h3>
            </div>

            <?php if($isPiutangTab): ?>
                <div class="flex flex-col sm:flex-row items-center gap-2 w-full md:w-auto">
                    <button type="button"
                            onclick="openBulkBayarModal()"
                            class="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-emerald-600 text-white px-4 py-2 rounded-lg hover:bg-emerald-700 transition text-sm font-medium shadow-sm">
                        <iconify-icon icon="mdi:cash-multiple" class="text-lg"></iconify-icon>
                        Bayar Piutang
                    </button>
                    <a href="<?php echo e(route('brilink.pengeluaran.invoice-bulk-pdf', [
                            'store'    => $storeId,
                            'from'     => $from,
                            'to'       => $to,
                            'search'   => $search,
                            'kategori' => $activeTab,
                        ])); ?>"
                    target="_blank"
                    class="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition text-sm font-medium shadow-sm">
                        <iconify-icon icon="mdi:printer" class="text-lg"></iconify-icon>
                        Print Invoice
                    </a>
                </div>
            <?php else: ?>
                <div class="text-xs text-gray-500 bg-gray-50 px-2 py-1 rounded border w-max"><?php echo e($groupedByReport->flatten()->count()); ?> Transaksi</div>
            <?php endif; ?>
        </div>

        <div class="p-0 sm:p-5">
            <?php if($groupedByReport->isEmpty()): ?>
                <div class="py-12 text-center text-gray-500">
                    <iconify-icon icon="mdi:inbox-outline" class="text-4xl text-gray-300 block m-auto mb-2 w-max"></iconify-icon>
                    Belum ada data pengeluaran untuk kategori dan filter ini.
                </div>
            <?php else: ?>
                
                
                
                <?php if(strtolower($activeTab) === 'semua'): ?>
                    
                    
                    <div class="hidden md:block overflow-x-auto">
                        <table class="w-full text-sm border-collapse min-w-max">
                            <thead>
                                <tr class="bg-gray-100">
                                    <th class="border border-gray-200 p-2 sm:p-3 text-left text-[10px] sm:text-xs font-semibold text-gray-600 uppercase w-40 whitespace-nowrap">Tanggal Report</th>
                                    <?php if($storeId === 'all'): ?>
                                        <th class="border border-gray-200 p-2 sm:p-3 text-left text-[10px] sm:text-xs font-semibold text-gray-600 uppercase w-40 whitespace-nowrap">Toko</th>
                                    <?php endif; ?>
                                    <?php $__currentLoopData = $kategoriList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <th class="border border-gray-200 p-2 sm:p-3 text-right text-[10px] sm:text-xs font-semibold text-gray-600 uppercase whitespace-nowrap">
                                            <?php echo e($kategori); ?>

                                        </th>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $groupedByReport; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reportId => $itemsInReport): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $report = $itemsInReport->first()->report;
                                        $rows = [];
                                        foreach ($itemsInReport as $item) {
                                            $foundEmptySlot = false;
                                            foreach ($rows as $index => $row) {
                                                if (!isset($row[$item->kategori])) {
                                                    $rows[$index][$item->kategori] = $item;
                                                    $foundEmptySlot = true;
                                                    break;
                                                }
                                            }
                                            if (!$foundEmptySlot) {
                                                $rows[] = [ $item->kategori => $item ];
                                            }
                                        }
                                    ?>

                                    <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="hover:bg-gray-50 transition">
                                            <td class="border border-gray-200 p-2 sm:p-3 text-gray-700 font-medium text-xs sm:text-sm whitespace-nowrap">
                                                <?php echo e($report->periode_label ?? '-'); ?>

                                            </td>
                                            
                                            <?php if($storeId === 'all'): ?>
                                                <td class="border border-gray-200 p-2 sm:p-3 text-[10px] sm:text-xs text-gray-600 whitespace-nowrap">
                                                    <iconify-icon icon="mdi:store" class="mr-1"></iconify-icon>
                                                    <?php echo e($report->store->nama_toko ?? '-'); ?>

                                                </td>
                                            <?php endif; ?>

                                            <?php $__currentLoopData = $kategoriList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php $transaksi = $row[$kategori] ?? null; ?>
                                                <td class="border border-gray-200 p-2 sm:p-3 text-right align-top">
                                                    <?php if($transaksi): ?>
                                                        <div class="flex flex-col items-end">
                                                            <div class="text-xs sm:text-sm font-semibold text-red-600 whitespace-nowrap">
                                                                Rp <?php echo e(number_format($transaksi->nominal_kas, 0, ',', '.')); ?>

                                                            </div>
                                                            <div class="text-[10px] text-gray-500 mt-1 max-w-[100px] sm:max-w-[150px] truncate" title="<?php echo e($transaksi->keterangan); ?>">
                                                                <?php echo e($transaksi->keterangan); ?>

                                                            </div>
                                                        </div>
                                                    <?php else: ?>
                                                        <span class="text-gray-400">-</span>
                                                    <?php endif; ?>
                                                </td>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                                <tr class="bg-red-50 border-t-2 border-red-300">
                                    <td colspan="<?php echo e($storeId === 'all' ? '2' : '1'); ?>" class="border border-gray-200 p-2 sm:p-3 font-bold text-gray-800 text-left text-xs sm:text-sm whitespace-nowrap">
                                        TOTAL
                                    </td>
                                    <?php $__currentLoopData = $kategoriList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $totalPerKategori = $groupedByReport->flatten()->filter(function($item) use ($kategori) {
                                                return strtolower(trim($item->kategori)) === strtolower(trim($kategori));
                                            })->sum('nominal_kas');
                                        ?>
                                        <td class="border border-gray-200 p-2 sm:p-3 text-right text-red-800 font-bold text-xs sm:text-sm whitespace-nowrap">
                                            <?php echo e($totalPerKategori > 0 ? 'Rp ' . number_format($totalPerKategori, 0, ',', '.') : '-'); ?>

                                        </td>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                            </tbody>
                            <tfoot>
                                <tr class="bg-red-600 text-white">
                                    <td colspan="<?php echo e(count($kategoriList) + ($storeId === 'all' ? 2 : 1)); ?>" class="p-3 sm:p-4 text-right">
                                        <span class="text-[10px] sm:text-sm font-bold uppercase tracking-wider mr-2 sm:mr-4">Total Pengeluaran</span>
                                        <span class="text-base sm:text-xl font-bold block sm:inline mt-1 sm:mt-0">
                                            Rp <?php echo e(number_format($groupedByReport->flatten()->sum('nominal_kas'), 0, ',', '.')); ?>

                                        </span>
                                    </td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>

                    
                    <div class="md:hidden divide-y divide-gray-100">
                        <?php $__currentLoopData = $groupedByReport; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reportId => $itemsInReport): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $report = $itemsInReport->first()->report;
                                $rows = [];
                                foreach ($itemsInReport as $item) {
                                    $foundEmptySlot = false;
                                    foreach ($rows as $index => $row) {
                                        if (!isset($row[$item->kategori])) {
                                            $rows[$index][$item->kategori] = $item;
                                            $foundEmptySlot = true;
                                            break;
                                        }
                                    }
                                    if (!$foundEmptySlot) {
                                        $rows[] = [ $item->kategori => $item ];
                                    }
                                }
                            ?>
                            
                            <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="p-4 space-y-2 text-xs">
                                    <div class="flex justify-between items-start border-b border-gray-100 pb-2 mb-2">
                                        <div class="font-bold text-gray-800 text-sm"><?php echo e($report->periode_label ?? '-'); ?></div>
                                        <?php if($storeId === 'all'): ?>
                                            <div class="text-[10px] text-gray-500 bg-gray-50 px-2 py-0.5 rounded border">
                                                <iconify-icon icon="mdi:store" class="mr-0.5"></iconify-icon>
                                                <?php echo e($report->store->nama_toko ?? '-'); ?>

                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <?php $__currentLoopData = $kategoriList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $transaksi = $row[$kategori] ?? null; ?>
                                        <?php if($transaksi): ?>
                                            <div class="flex justify-between items-start gap-2">
                                                <div class="flex-1">
                                                    <div class="text-gray-600 font-medium text-[11px]"><?php echo e($kategori); ?></div>
                                                    <div class="text-[10px] text-gray-400 mt-0.5 leading-tight"><?php echo e($transaksi->keterangan); ?></div>
                                                </div>
                                                <div class="text-right font-bold text-red-600 whitespace-nowrap">
                                                    Rp <?php echo e(number_format($transaksi->nominal_kas, 0, ',', '.')); ?>

                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        
                        <div class="p-4 bg-red-50 space-y-2 text-xs border-t-2 border-red-200">
                            <div class="font-bold text-gray-800 text-sm mb-2">TOTAL PENGELUARAN</div>
                            <?php $__currentLoopData = $kategoriList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $totalPerKategori = $groupedByReport->flatten()->filter(function($item) use ($kategori) {
                                        return strtolower(trim($item->kategori)) === strtolower(trim($kategori));
                                    })->sum('nominal_kas');
                                ?>
                                <?php if($totalPerKategori > 0): ?>
                                    <div class="flex justify-between items-center text-gray-700">
                                        <span><?php echo e($kategori); ?></span>
                                        <span class="font-semibold text-red-800">Rp <?php echo e(number_format($totalPerKategori, 0, ',', '.')); ?></span>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="flex justify-between items-center pt-2 mt-2 border-t border-red-200">
                                <span class="font-bold text-gray-800">TOTAL KESELURUHAN</span>
                                <span class="font-bold text-red-600 text-sm">Rp <?php echo e(number_format($groupedByReport->flatten()->sum('nominal_kas'), 0, ',', '.')); ?></span>
                            </div>
                        </div>
                    </div>

                
                
                
                <?php else: ?>
                    
                    
                    <div class="hidden md:block overflow-x-auto">
                        <table class="w-full text-sm border-collapse min-w-max">
                            <thead>
                                <tr class="bg-gray-100">
                                    <th class="border border-gray-200 p-2 sm:p-3 text-left text-[10px] sm:text-xs font-semibold text-gray-600 uppercase w-32 sm:w-40 whitespace-nowrap">Tanggal</th>
                                    
                                    <?php if($storeId === 'all'): ?>
                                        <th class="border border-gray-200 p-2 sm:p-3 text-left text-[10px] sm:text-xs font-semibold text-gray-600 uppercase whitespace-nowrap">Toko</th>
                                    <?php endif; ?>

                                    <th class="border border-gray-200 p-2 sm:p-3 text-left text-[10px] sm:text-xs font-semibold text-gray-600 uppercase whitespace-nowrap">Keterangan</th>
                                    <th class="border border-gray-200 p-2 sm:p-3 text-right text-[10px] sm:text-xs font-semibold text-gray-600 uppercase whitespace-nowrap">Nominal</th>
                                    <th class="border border-gray-200 p-2 sm:p-3 text-center text-[10px] sm:text-xs font-semibold text-gray-600 uppercase whitespace-nowrap">Kategori</th>
                                    
                                    <?php if($isPiutangTab): ?>
                                        <th class="border border-gray-200 p-2 sm:p-3 text-center text-[10px] sm:text-xs font-semibold text-gray-600 uppercase whitespace-nowrap">Status</th>
                                    <?php endif; ?>
                                    
                                    <th class="border border-gray-200 p-2 sm:p-3 text-center text-[10px] sm:text-xs font-semibold text-gray-600 uppercase w-32 sm:w-48 whitespace-nowrap">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $groupedByReport; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reportId => $itemsInReport): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $report = $itemsInReport->first()->report; ?>
                                    
                                    <?php $__currentLoopData = $itemsInReport; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr id="pengeluaran-row-<?php echo e($item->id); ?>" class="hover:bg-gray-50 transition">
                                            <td class="border border-gray-200 p-2 sm:p-3 text-gray-700 font-medium text-xs sm:text-sm whitespace-nowrap">
                                                <?php echo e($report->periode_label ?? '-'); ?>

                                            </td>

                                            <?php if($storeId === 'all'): ?>
                                                <td class="border border-gray-200 p-2 sm:p-3 text-[10px] sm:text-xs text-gray-600 whitespace-nowrap">
                                                    <iconify-icon icon="mdi:store" class="mr-1"></iconify-icon>
                                                    <?php echo e($item->report->store->nama_toko ?? '-'); ?>

                                                </td>
                                            <?php endif; ?>

                                            <td class="border border-gray-200 p-2 sm:p-3 text-gray-800 text-xs sm:text-sm">
                                                <?php echo e($item->keterangan ?? 'Tanpa catatan'); ?>

                                            </td>
                                            <td class="border border-gray-200 p-2 sm:p-3 text-right font-bold text-red-600 text-xs sm:text-sm whitespace-nowrap">
                                                Rp <?php echo e(number_format($item->nominal_kas, 0, ',', '.')); ?>

                                            </td>
                                            <td class="border border-gray-200 p-2 sm:p-3 text-center whitespace-nowrap">
                                                <span class="text-[10px] sm:text-xs bg-gray-100 text-gray-700 px-2 py-1 rounded">
                                                    <?php echo e($item->kategori ?: '-'); ?>

                                                </span>
                                            </td>

                                            
                                            <?php if($isPiutangTab): ?>
                                                <td class="border border-gray-200 p-2 sm:p-3 text-center whitespace-nowrap">
                                                    <?php if($item->is_paid): ?>
                                                        <span class="inline-flex items-center gap-1 text-[10px] sm:text-xs bg-green-100 text-green-700 px-2 py-1 rounded font-medium">
                                                            <iconify-icon icon="mdi:check-circle" class="text-xs sm:text-sm"></iconify-icon> Lunas
                                                        </span>
                                                    <?php elseif($item->paid_amount > 0): ?>
                                                        <span class="inline-flex items-center gap-1 text-[10px] sm:text-xs bg-orange-100 text-orange-700 px-2 py-1 rounded font-medium" 
                                                            title="Terbayar: Rp <?php echo e(number_format($item->paid_amount, 0, ',', '.')); ?>">
                                                            <iconify-icon icon="mdi:progress-clock" class="text-xs sm:text-sm"></iconify-icon> 
                                                            Sebagian
                                                        </span>
                                                    <?php else: ?>
                                                        <span class="inline-flex items-center gap-1 text-[10px] sm:text-xs bg-red-100 text-red-700 px-2 py-1 rounded font-medium">
                                                            <iconify-icon icon="mdi:clock-alert" class="text-xs sm:text-sm"></iconify-icon> Belum
                                                        </span>
                                                    <?php endif; ?>
                                                </td>
                                            <?php endif; ?>

                                            
                                            <td class="border border-gray-200 p-2 sm:p-3 text-center">
                                                <div class="flex flex-col sm:flex-row items-center justify-center gap-1">
                                                    
                                                    
                                                    <?php if($isPiutangTab && !$item->is_paid): ?>
                                                        <button type="button"
                                                                onclick="bayarPiutangSingle(<?php echo e($item->id); ?>, <?php echo e($item->nominal_kas - $item->paid_amount); ?>)"
                                                                class="w-full sm:w-auto inline-flex items-center justify-center gap-1 text-emerald-600 hover:bg-emerald-50 px-2 py-1 rounded text-xs font-medium transition border sm:border-0 border-emerald-200"
                                                                title="Tandai Lunas">
                                                            <iconify-icon icon="mdi:cash-check" class="text-sm"></iconify-icon>
                                                            Bayar
                                                        </button>
                                                    <?php endif; ?>

                                                    
                                                    <button type="button"
                                                            onclick="openEditPengeluaranModal(<?php echo e($item->id); ?>, '<?php echo e(addslashes($item->keterangan ?? '')); ?>', '<?php echo e(addslashes($item->kategori ?? '')); ?>', <?php echo e($item->nominal_kas); ?>)"
                                                            class="w-full sm:w-auto inline-flex items-center justify-center gap-1 text-blue-600 hover:bg-blue-50 px-2 py-1 rounded text-xs font-medium transition border sm:border-0 border-blue-200">
                                                        <iconify-icon icon="mdi:pencil" class="text-sm"></iconify-icon>
                                                        Edit
                                                    </button>

                                                    
                                                    <button type="button"
                                                            onclick="deletePengeluaran(<?php echo e($item->id); ?>, '<?php echo e(addslashes($item->keterangan ?? '')); ?>')"
                                                            class="w-full sm:w-auto inline-flex items-center justify-center gap-1 text-red-600 hover:bg-red-50 px-2 py-1 rounded text-xs font-medium transition border sm:border-0 border-red-200">
                                                        <iconify-icon icon="mdi:delete" class="text-sm"></iconify-icon>
                                                        Hapus
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                                <?php
                                    $totalNominal = $groupedByReport->flatten()->sum('nominal_kas');
                                    $totalTerbayar = $groupedByReport->flatten()->sum('paid_amount');
                                    $sisaPiutang = max(0, $totalNominal - $totalTerbayar);
                                ?>

                                <tr class="bg-red-50 border-t-2 border-red-300">
                                    <td colspan="<?php echo e($storeId === 'all' ? '3' : '2'); ?>" class="border border-gray-200 p-2 sm:p-3 font-bold text-gray-800 text-right align-top text-xs sm:text-sm">
                                        <div>TOTAL PENGELUARAN</div>
                                        <?php if($isPiutangTab): ?>
                                            <div class="text-[10px] sm:text-xs font-normal text-gray-500 mt-1">
                                                Terbayar: Rp <?php echo e(number_format($totalTerbayar, 0, ',', '.')); ?>

                                            </div>
                                        <?php endif; ?>
                                    </td>

                                    <td class="border border-gray-200 p-2 sm:p-3 text-right align-top whitespace-nowrap">
                                        <div class="font-bold text-red-800 text-xs sm:text-sm">
                                            Rp <?php echo e(number_format($totalNominal, 0, ',', '.')); ?>

                                        </div>
                                        <?php if($isPiutangTab): ?>
                                            <div class="mt-1 text-[10px] sm:text-xs font-bold <?php echo e($sisaPiutang > 0 ? 'text-orange-600' : 'text-green-600'); ?>">
                                                Sisa: Rp <?php echo e(number_format($sisaPiutang, 0, ',', '.')); ?>

                                            </div>
                                        <?php endif; ?>
                                    </td>
                                    <td></td>

                                    
                                    <?php if($isPiutangTab): ?>
                                        <td class="border border-gray-200 p-2 sm:p-3 text-center align-top whitespace-nowrap">
                                            <?php if($sisaPiutang == 0 && $totalNominal > 0): ?>
                                                <span class="inline-flex items-center gap-1 text-[10px] sm:text-xs bg-green-100 text-green-700 px-2 py-1 rounded font-medium">
                                                    <iconify-icon icon="mdi:check-all" class="text-xs sm:text-sm"></iconify-icon> Lunas
                                                </span>
                                            <?php elseif($sisaPiutang > 0): ?>
                                                <span class="inline-flex items-center gap-1 text-[10px] sm:text-xs bg-orange-100 text-orange-700 px-2 py-1 rounded font-medium">
                                                    <iconify-icon icon="mdi:alert-circle" class="text-xs sm:text-sm"></iconify-icon> Belum
                                                </span>
                                            <?php endif; ?>
                                        </td>
                                    <?php endif; ?>

                                    
                                    <td class="border border-gray-200 p-2 sm:p-3"></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                    
                    <div class="md:hidden divide-y divide-gray-100">
                        <?php $__currentLoopData = $groupedByReport; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reportId => $itemsInReport): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $report = $itemsInReport->first()->report; ?>
                            
                            <?php $__currentLoopData = $itemsInReport; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div id="pengeluaran-row-<?php echo e($item->id); ?>" class="p-4 space-y-2 text-xs">
                                    
                                    <div class="flex justify-between items-start">
                                        <div>
                                            <div class="font-bold text-gray-800 text-sm"><?php echo e($item->keterangan ?? 'Tanpa catatan'); ?></div>
                                            <div class="text-[10px] text-gray-500 mt-0.5"><?php echo e($report->periode_label ?? '-'); ?></div>
                                        </div>
                                        <?php if($storeId === 'all'): ?>
                                            <div class="text-[10px] text-gray-500 bg-gray-50 px-2 py-0.5 rounded border whitespace-nowrap">
                                                <iconify-icon icon="mdi:store" class="mr-0.5"></iconify-icon>
                                                <?php echo e($item->report->store->nama_toko ?? '-'); ?>

                                            </div>
                                        <?php endif; ?>
                                    </div>

                                    <div class="flex justify-between items-center pt-1">
                                        <span class="bg-gray-100 text-gray-700 px-2 py-0.5 rounded text-[10px]"><?php echo e($item->kategori ?: '-'); ?></span>
                                        <span class="font-bold text-red-600 text-sm whitespace-nowrap">Rp <?php echo e(number_format($item->nominal_kas, 0, ',', '.')); ?></span>
                                    </div>

                                    <?php if($isPiutangTab): ?>
                                        <div class="flex justify-between items-center pt-1 border-t border-gray-50">
                                            <span class="text-gray-500 text-[10px]">Status:</span>
                                            <?php if($item->is_paid): ?>
                                                <span class="inline-flex items-center gap-1 text-[10px] bg-green-100 text-green-700 px-2 py-1 rounded font-medium">
                                                    <iconify-icon icon="mdi:check-circle" class="text-xs"></iconify-icon> Lunas
                                                </span>
                                            <?php elseif($item->paid_amount > 0): ?>
                                                <span class="inline-flex items-center gap-1 text-[10px] bg-orange-100 text-orange-700 px-2 py-1 rounded font-medium">
                                                    <iconify-icon icon="mdi:progress-clock" class="text-xs"></iconify-icon> 
                                                    Terbayar (Rp <?php echo e(number_format($item->paid_amount, 0, ',', '.')); ?>)
                                                </span>
                                            <?php else: ?>
                                                <span class="inline-flex items-center gap-1 text-[10px] bg-red-100 text-red-700 px-2 py-1 rounded font-medium">
                                                    <iconify-icon icon="mdi:clock-alert" class="text-xs"></iconify-icon> Belum Bayar
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    <?php endif; ?>

                                    <div class="flex gap-2 pt-2">
                                        <?php if($isPiutangTab && !$item->is_paid): ?>
                                            <button type="button"
                                                    onclick="bayarPiutangSingle(<?php echo e($item->id); ?>, <?php echo e($item->nominal_kas - $item->paid_amount); ?>)"
                                                    class="flex-1 inline-flex justify-center items-center gap-1 bg-emerald-50 text-emerald-700 border border-emerald-200 px-2 py-1.5 rounded text-xs font-medium transition">
                                                <iconify-icon icon="mdi:cash-check" class="text-sm"></iconify-icon> Bayar
                                            </button>
                                        <?php endif; ?>
                                        
                                        <button type="button"
                                                onclick="openEditPengeluaranModal(<?php echo e($item->id); ?>, '<?php echo e(addslashes($item->keterangan ?? '')); ?>', '<?php echo e(addslashes($item->kategori ?? '')); ?>', <?php echo e($item->nominal_kas); ?>)"
                                                class="flex-1 inline-flex justify-center items-center gap-1 bg-blue-50 text-blue-700 border border-blue-200 px-2 py-1.5 rounded text-xs font-medium transition">
                                            <iconify-icon icon="mdi:pencil" class="text-sm"></iconify-icon> Edit
                                        </button>
                                        
                                        <button type="button"
                                                onclick="deletePengeluaran(<?php echo e($item->id); ?>, '<?php echo e(addslashes($item->keterangan ?? '')); ?>')"
                                                class="flex-1 inline-flex justify-center items-center gap-1 bg-red-50 text-red-700 border border-red-200 px-2 py-1.5 rounded text-xs font-medium transition">
                                            <iconify-icon icon="mdi:delete" class="text-sm"></iconify-icon> Hapus
                                        </button>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        
                        <div class="p-4 bg-red-50 space-y-2 text-xs">
                            <div class="flex justify-between items-center">
                                <span class="font-semibold text-gray-800">TOTAL PENGELUARAN</span>
                                <span class="font-bold text-red-800 text-sm">Rp <?php echo e(number_format($totalNominal, 0, ',', '.')); ?></span>
                            </div>
                            <?php if($isPiutangTab): ?>
                                <div class="flex justify-between items-center">
                                    <span class="font-semibold text-gray-800">TOTAL TERBAYAR</span>
                                    <span class="font-bold text-emerald-600">Rp <?php echo e(number_format($totalTerbayar, 0, ',', '.')); ?></span>
                                </div>
                                <div class="flex justify-between items-center">
                                    <span class="font-semibold text-gray-800">SISA PIUTANG</span>
                                    <span class="font-bold <?php echo e($sisaPiutang > 0 ? 'text-orange-600' : 'text-green-600'); ?>">Rp <?php echo e(number_format($sisaPiutang, 0, ',', '.')); ?></span>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>

                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>

</div>


<div id="pengeluaranModal" class="fixed inset-0 z-50 hidden items-center justify-center p-4">
    <div class="absolute inset-0 bg-black/50" onclick="closePengeluaranModal()"></div>
    <div class="relative bg-white rounded-xl shadow-xl w-full max-w-md overflow-hidden animate-slide-up max-h-[90vh] flex flex-col">
        <div class="px-5 py-4 border-b border-gray-100 flex justify-between items-center bg-gray-50 flex-shrink-0">
            <div class="flex items-center gap-2">
                <iconify-icon id="pengeluaranModalIcon" icon="mdi:plus-circle" class="text-red-600 text-lg"></iconify-icon>
                <h3 id="pengeluaranModalTitle" class="font-bold text-gray-800">Tambah Pengeluaran</h3>
            </div>
            <button type="button" onclick="closePengeluaranModal()" class="text-gray-400 hover:text-gray-600 transition">
                <iconify-icon icon="mdi:close" class="text-xl"></iconify-icon>
            </button>
        </div>

        <form id="pengeluaranForm" onsubmit="submitPengeluaranForm(event)" class="overflow-y-auto flex-1 flex flex-col">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="store_id" id="pengeluaranStoreId" value="<?php echo e($storeId); ?>">
            <input type="hidden" id="pengeluaranId" name="pengeluaran_id" value="">
            <input type="hidden" id="pengeluaranMode" value="create">

            <div class="p-5 space-y-4">
                <div class="hidden bg-red-50 text-red-600 p-3 rounded text-sm" id="modalErrorPengeluaran"></div>

                
                <div id="tokoFieldWrapper" class="hidden">
                    <label class="block text-xs font-medium text-gray-600 mb-1">Pilih Toko <span class="text-red-500">*</span></label>
                    <select id="pengeluaranStoreSelect" required
                        class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-red-500 focus:outline-none bg-white">
                        <option value="">-- Pilih Toko --</option>
                        <?php $__currentLoopData = $stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($s->id); ?>"><?php echo e($s->nama_toko); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                
                <div id="tanggalFieldWrapper">
                    <label class="block text-xs font-medium text-gray-600 mb-1">Tanggal Transaksi</label>
                    <input type="date" name="tanggal" id="pengeluaranTanggal" value="<?php echo e(date('Y-m-d')); ?>" required
                        class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-red-500 focus:outline-none">
                </div>

                
                <div id="tanggalReadonlyWrapper" class="hidden">
                    <label class="block text-xs font-medium text-gray-600 mb-1">Tanggal Transaksi</label>
                    <div class="w-full bg-gray-100 border border-gray-200 rounded-lg px-3 py-2 text-sm text-gray-600">
                        <iconify-icon icon="mdi:lock" class="text-gray-400 text-sm mr-1"></iconify-icon>
                        <span id="pengeluaranTanggalReadonly">-</span>
                        <span class="text-[10px] text-gray-400 ml-2">(tidak dapat diubah)</span>
                    </div>
                </div>

                <div>
                    <label class="block text-xs font-medium text-gray-600 mb-1">Kategori Akuntansi</label>
                    <select name="kategori" id="pengeluaranKategori" required
                        class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-red-500 focus:outline-none">
                        <option value="">-- Pilih Kategori --</option>
                        <?php $__currentLoopData = $kategoriList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($kat); ?>"><?php echo e($kat); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div>
                    <label class="block text-xs font-medium text-gray-600 mb-1">Keterangan / Catatan</label>
                    <input type="text" name="keterangan" id="pengeluaranKeterangan" required placeholder="cth: Beli Bensin"
                        class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-red-500 focus:outline-none">
                </div>

                <div>
                    <label class="block text-xs font-medium text-gray-600 mb-1">Nominal</label>
                    <div class="relative">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <span class="text-gray-500 text-sm font-medium">Rp</span>
                        </div>
                        <input type="text" id="inputNominalPengeluaran" name="nominal" required placeholder="0"
                            class="w-full border border-gray-300 rounded-lg pl-10 pr-3 py-2 text-sm font-bold focus:ring-2 focus:ring-red-500 focus:outline-none">
                    </div>
                </div>
            </div>

            <div class="px-5 py-3 border-t border-gray-100 bg-gray-50 flex justify-end gap-2 flex-shrink-0">
                <button type="button" onclick="closePengeluaranModal()" class="px-4 py-2 text-sm text-gray-600 hover:bg-gray-200 rounded-lg transition">Batal</button>
                <button type="submit" id="btnSubmitPengeluaran" class="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition text-sm font-medium flex items-center gap-2">
                    <iconify-icon icon="mdi:content-save" class="text-lg"></iconify-icon> <span id="btnSubmitPengeluaranText">Simpan</span>
                </button>
            </div>
        </form>
    </div>
</div>


<div id="bulkBayarModal" class="fixed inset-0 z-50 hidden items-center justify-center p-4">
    <div class="absolute inset-0 bg-black/50" onclick="closeBulkBayarModal()"></div>
    <div class="relative bg-white rounded-xl shadow-xl w-full max-w-md overflow-hidden animate-slide-up">
        <div class="px-5 py-4 border-b border-gray-100 flex justify-between items-center bg-emerald-50">
            <div class="flex items-center gap-2">
                <iconify-icon icon="mdi:cash-multiple" class="text-emerald-600 text-lg"></iconify-icon>
                <h3 class="font-bold text-gray-800">Bayar Bulk Piutang</h3>
            </div>
            <button type="button" onclick="closeBulkBayarModal()" class="text-gray-400 hover:text-gray-600 transition">
                <iconify-icon icon="mdi:close" class="text-xl"></iconify-icon>
            </button>
        </div>

        <form id="bulkBayarForm" onsubmit="submitBulkBayar(event)">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="store" value="<?php echo e($storeId); ?>">
            <input type="hidden" name="kategori" value="<?php echo e($activeTab); ?>">
            <input type="hidden" name="from" value="<?php echo e($from); ?>">
            <input type="hidden" name="to" value="<?php echo e($to); ?>">
            <input type="hidden" name="search" value="<?php echo e($search); ?>">

            <div class="p-5 space-y-4">
                <div class="hidden bg-red-50 text-red-600 p-3 rounded text-sm" id="bulkBayarError"></div>

                <div class="bg-emerald-50 rounded-lg p-3 text-xs text-emerald-800 flex items-start gap-2">
                    <iconify-icon icon="mdi:information" class="text-base mt-0.5 flex-shrink-0"></iconify-icon>
                    <div>
                        Piutang akan dilunasi otomatis <strong>dari yang paling lama</strong> (FIFO). 
                        Jika nominal tidak pas, piutang terakhir akan dibayar sebagian.
                    </div>
                </div>

                <div>
                    <label class="block text-xs font-medium text-gray-600 mb-1">Total Nominal Pembayaran</label>
                    <div class="relative">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <span class="text-gray-500 text-sm font-medium">Rp</span>
                        </div>
                        <input type="text" id="inputBulkBayar" name="nominal" required placeholder="0"
                            class="w-full border border-gray-300 rounded-lg pl-10 pr-3 py-2 text-sm font-bold focus:ring-2 focus:ring-emerald-500 focus:outline-none">
                    </div>
                </div>
            </div>

            <div class="px-5 py-3 border-t border-gray-100 bg-gray-50 flex justify-end gap-2">
                <button type="button" onclick="closeBulkBayarModal()" class="px-4 py-2 text-sm text-gray-600 hover:bg-gray-200 rounded-lg transition">Batal</button>
                <button type="submit" id="btnSubmitBulkBayar" class="bg-emerald-600 text-white px-4 py-2 rounded-lg hover:bg-emerald-700 transition text-sm font-medium flex items-center gap-2">
                    <iconify-icon icon="mdi:cash-check" class="text-lg"></iconify-icon> Bayar
                </button>
            </div>
        </form>
    </div>
</div>

<script>
    const CSRF_TOKEN_PENGELUARAN = document.querySelector('meta[name="csrf-token"]').content;
    const CURRENT_STORE_ID = "<?php echo e($storeId); ?>";

    function todayLocal() {
        const d = new Date();
        const yyyy = d.getFullYear();
        const mm = String(d.getMonth() + 1).padStart(2, '0');
        const dd = String(d.getDate()).padStart(2, '0');
        return `${yyyy}-${mm}-${dd}`;
    }

    function formatNominalInput(input) {
        let value = input.value.replace(/[^0-9]/g, '');
        if (value) {
            input.value = new Intl.NumberFormat('id-ID').format(value);
        } else {
            input.value = '';
        }
    }

    document.addEventListener('DOMContentLoaded', function () {
        const inputNominal = document.getElementById('inputNominalPengeluaran');
        if (inputNominal) {
            inputNominal.addEventListener('input', function () {
                formatNominalInput(this);
            });
        }
        
        const inputBulk = document.getElementById('inputBulkBayar');
        if (inputBulk) {
            inputBulk.addEventListener('input', function () {
                formatNominalInput(this);
            });
        }
    });

    // ===================================================
    // OPEN MODAL — CREATE
    // ===================================================
    function openPengeluaranModal() {
        const modal = document.getElementById('pengeluaranModal');
        const form = document.getElementById('pengeluaranForm');
        const errors = document.getElementById('modalErrorPengeluaran');

        form.reset();
        errors.classList.add('hidden');

        document.getElementById('pengeluaranMode').value = 'create';
        document.getElementById('pengeluaranId').value = '';
        document.getElementById('pengeluaranModalTitle').textContent = 'Tambah Pengeluaran';
        document.getElementById('pengeluaranModalIcon').setAttribute('icon', 'mdi:plus-circle');
        document.getElementById('btnSubmitPengeluaranText').textContent = 'Simpan';

        document.getElementById('tanggalFieldWrapper').classList.remove('hidden');
        document.getElementById('tanggalReadonlyWrapper').classList.add('hidden');
        document.getElementById('pengeluaranTanggal').value = todayLocal();

        document.getElementById('inputNominalPengeluaran').value = '';

        const tokoWrapper = document.getElementById('tokoFieldWrapper');
        const tokoSelect = document.getElementById('pengeluaranStoreSelect');
        const storeIdHidden = document.getElementById('pengeluaranStoreId');

        if (CURRENT_STORE_ID === 'all') {
            tokoWrapper.classList.remove('hidden');
            tokoSelect.required = true;
            storeIdHidden.value = '';
        } else {
            tokoWrapper.classList.add('hidden');
            tokoSelect.required = false;
            storeIdHidden.value = CURRENT_STORE_ID;
        }

        modal.classList.remove('hidden');
        modal.classList.add('flex');
    }

    // ===================================================
    // OPEN MODAL — EDIT
    // ===================================================
    function openEditPengeluaranModal(id, keterangan, kategori, nominal) {
        const modal = document.getElementById('pengeluaranModal');
        const form = document.getElementById('pengeluaranForm');
        const errors = document.getElementById('modalErrorPengeluaran');

        form.reset();
        errors.classList.add('hidden');

        document.getElementById('pengeluaranMode').value = 'edit';
        document.getElementById('pengeluaranId').value = id;
        document.getElementById('pengeluaranModalTitle').textContent = 'Edit Pengeluaran';
        document.getElementById('pengeluaranModalIcon').setAttribute('icon', 'mdi:pencil');
        document.getElementById('btnSubmitPengeluaranText').textContent = 'Simpan Perubahan';

        document.getElementById('tokoFieldWrapper').classList.add('hidden');
        document.getElementById('pengeluaranStoreSelect').required = false;

        document.getElementById('tanggalFieldWrapper').classList.add('hidden');
        document.getElementById('tanggalReadonlyWrapper').classList.remove('hidden');

        const row = document.getElementById('pengeluaran-row-' + id);
        // Ambil tanggal dari elemen pertama di baris (bisa div di mobile atau td di desktop)
        const tanggalText = row ? (row.querySelector('td')?.innerText.trim() || row.querySelector('.text-\\[10px\\]')?.innerText.trim() || '-') : '-';
        document.getElementById('pengeluaranTanggalReadonly').textContent = tanggalText;

        document.getElementById('pengeluaranKeterangan').value = keterangan || '';
        document.getElementById('pengeluaranKategori').value = kategori || '';

        if (nominal > 0) {
            document.getElementById('inputNominalPengeluaran').value = new Intl.NumberFormat('id-ID').format(nominal);
        } else {
            document.getElementById('inputNominalPengeluaran').value = '';
        }

        modal.classList.remove('hidden');
        modal.classList.add('flex');
    }

    function closePengeluaranModal() {
        document.getElementById('pengeluaranModal').classList.add('hidden');
        document.getElementById('pengeluaranModal').classList.remove('flex');
    }

    // ===================================================
    // SUBMIT FORM (CREATE atau EDIT)
    // ===================================================
    async function submitPengeluaranForm(e) {
        e.preventDefault();

        const form = e.target;
        const btn = document.getElementById('btnSubmitPengeluaran');
        const btnText = document.getElementById('btnSubmitPengeluaranText');
        const errorDiv = document.getElementById('modalErrorPengeluaran');
        const mode = document.getElementById('pengeluaranMode').value;
        const id = document.getElementById('pengeluaranId').value;

        const originalText = btnText.textContent;
        btn.disabled = true;
        btnText.textContent = 'Menyimpan...';
        errorDiv.classList.add('hidden');

        const nominalInput = document.getElementById('inputNominalPengeluaran');
        const nominalRaw = nominalInput.value.replace(/[^0-9]/g, '');

        const formData = new FormData(form);
        formData.set('nominal', nominalRaw);

        if (mode === 'create' && CURRENT_STORE_ID === 'all') {
            const selectedStore = document.getElementById('pengeluaranStoreSelect').value;
            if (!selectedStore) {
                errorDiv.textContent = 'Silakan pilih toko terlebih dahulu.';
                errorDiv.classList.remove('hidden');
                btn.disabled = false;
                btnText.textContent = originalText;
                return;
            }
            formData.set('store_id', selectedStore);
        }

        let url, method;
        if (mode === 'create') {
            url = "<?php echo e(route('brilink.pengeluaran.store-ajax')); ?>";
            method = 'POST';
        } else {
            url = `/brilink/pengeluaran/${id}/ajax`;
            method = 'POST';
            formData.append('_method', 'PUT');
        }

        try {
            const response = await fetch(url, {
                method: method,
                headers: {
                    'X-CSRF-TOKEN': CSRF_TOKEN_PENGELUARAN,
                    'Accept': 'application/json',
                },
                body: formData,
            });

            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.message || 'Gagal menyimpan data.');
            }

            closePengeluaranModal();
            window.location.reload();

        } catch (error) {
            errorDiv.textContent = error.message;
            errorDiv.classList.remove('hidden');
            btn.disabled = false;
            btnText.textContent = originalText;
        }
    }

    // ===================================================
    // DELETE PENGELUARAN
    // ===================================================
    async function deletePengeluaran(id, keterangan) {
        if (!confirm(`Yakin hapus pengeluaran "${keterangan}"?`)) return;

        try {
            const response = await fetch(`/brilink/pengeluaran/${id}/ajax`, {
                method: 'DELETE',
                headers: {
                    'X-CSRF-TOKEN': CSRF_TOKEN_PENGELUARAN,
                    'Accept': 'application/json',
                },
            });

            const data = await response.json();

            if (!response.ok) {
                alert(data.message || 'Gagal menghapus.');
                return;
            }

            window.location.reload();

        } catch (err) {
            alert('Gagal menghapus: ' + err.message);
        }
    }

    // ===================================================
    // BAYAR PIUTANG SINGLE
    // ===================================================
    async function bayarPiutangSingle(id, sisaNominal) {
        const nominalFormatted = new Intl.NumberFormat('id-ID').format(sisaNominal);
        if (!confirm(`Tandai piutang ini LUNAS?\nSisa tagihan: Rp ${nominalFormatted}`)) return;

        try {
            const response = await fetch(`/brilink/piutang/${id}/bayar`, {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': CSRF_TOKEN_PENGELUARAN,
                    'Accept': 'application/json',
                },
            });

            const data = await response.json();
            if (!response.ok) throw new Error(data.message || 'Gagal.');

            window.location.reload();
        } catch (err) {
            alert('Gagal: ' + err.message);
        }
    }

    // ===================================================
    // BAYAR PIUTANG BULK (FIFO)
    // ===================================================
    function openBulkBayarModal() {
        document.getElementById('bulkBayarForm').reset();
        document.getElementById('bulkBayarError').classList.add('hidden');
        document.getElementById('bulkBayarModal').classList.remove('hidden');
        document.getElementById('bulkBayarModal').classList.add('flex');
    }

    function closeBulkBayarModal() {
        document.getElementById('bulkBayarModal').classList.add('hidden');
        document.getElementById('bulkBayarModal').classList.remove('flex');
    }

    async function submitBulkBayar(e) {
        e.preventDefault();
        const form = e.target;
        const btn = document.getElementById('btnSubmitBulkBayar');
        const errorDiv = document.getElementById('bulkBayarError');
        const input = document.getElementById('inputBulkBayar');

        const nominalRaw = input.value.replace(/[^0-9]/g, '');
        if (!nominalRaw || parseInt(nominalRaw) <= 0) {
            errorDiv.textContent = 'Nominal tidak valid.';
            errorDiv.classList.remove('hidden');
            return;
        }

        btn.disabled = true;
        btn.innerHTML = 'Memproses...';
        errorDiv.classList.add('hidden');

        const formData = new FormData(form);
        formData.set('nominal', nominalRaw);

        try {
            const response = await fetch("<?php echo e(route('brilink.piutang.bayar-bulk')); ?>", {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': CSRF_TOKEN_PENGELUARAN,
                    'Accept': 'application/json',
                },
                body: formData,
            });
            const data = await response.json();
            if (!response.ok) throw new Error(data.message || 'Gagal.');

            alert(data.message);
            window.location.reload();
        } catch (err) {
            errorDiv.textContent = err.message;
            errorDiv.classList.remove('hidden');
            btn.disabled = false;
            btn.innerHTML = '<iconify-icon icon="mdi:cash-check" class="text-lg"></iconify-icon> Bayar';
        }
    }

    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') {
            closePengeluaranModal();
            closeBulkBayarModal();
        }
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pembukuan\resources\views/brilink/pengeluaran.blade.php ENDPATH**/ ?>