

<?php $__env->startSection('title', 'Hanca Selesai'); ?>

<?php $__env->startSection('content'); ?>
<div class="w-full min-w-0">
    
    <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
        <div class="flex items-center gap-3">
            <div class="w-10 h-10 bg-emerald-600 rounded-lg flex items-center justify-center flex-shrink-0">
                <iconify-icon icon="mdi:check-all" class="text-white text-xl"></iconify-icon>
            </div>
            <div>
                <h2 class="text-lg sm:text-xl font-bold text-gray-800">Hanca Selesai</h2>
                <p class="text-xs sm:text-sm text-gray-500">Daftar produk yang sudah lunas disetor</p>
            </div>
        </div>
    </div>

    
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4 mb-6">
        <form method="GET" class="grid grid-cols-1 sm:grid-cols-2 md:flex md:flex-wrap gap-3 items-end">
            <div class="w-full md:w-48">
                <label class="block text-xs font-medium text-gray-600 mb-1">Karyawan</label>
                <select name="karyawan_id" onchange="this.form.submit()" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-emerald-600 focus:outline-none">
                    <option value="all" <?php echo e($karyawanId === 'all' ? 'selected' : ''); ?>>Semua Karyawan</option>
                    <?php $__currentLoopData = $karyawanList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($k->id); ?>" <?php echo e($karyawanId == $k->id ? 'selected' : ''); ?>><?php echo e($k->nama); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="w-full md:w-40">
                <label class="block text-xs font-medium text-gray-600 mb-1">Bulan</label>
                <select name="bulan" onchange="this.form.submit()" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-emerald-600 focus:outline-none">
                    <option value="all" <?php echo e($bulanFilter === 'all' ? 'selected' : ''); ?>>Semua Bulan</option>
                    <?php $__currentLoopData = $bulanList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bln): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($bln['value']); ?>" <?php echo e($bulanFilter == $bln['value'] ? 'selected' : ''); ?>><?php echo e($bln['label']); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="w-full sm:col-span-2 md:col-span-1 md:flex-1">
                <label class="block text-xs font-medium text-gray-600 mb-1">Cari</label>
                <div class="relative">
                    <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <iconify-icon icon="mdi:magnify" class="text-gray-400 text-lg"></iconify-icon>
                    </div>
                    <input type="text" name="search" value="<?php echo e($search); ?>" placeholder="Cari nama, produk..."
                        class="w-full border border-gray-300 rounded-lg pl-10 pr-3 py-2 text-sm focus:ring-2 focus:ring-emerald-600 focus:outline-none">
                </div>
            </div>
            <div class="flex gap-2 w-full md:w-auto mt-2 md:mt-0">
                <button type="submit" class="flex-1 md:flex-none bg-emerald-600 text-white px-5 py-2 rounded-lg hover:bg-emerald-700 transition text-sm font-medium flex items-center justify-center gap-2">
                    <iconify-icon icon="mdi:filter" class="text-lg"></iconify-icon> Filter
                </button>
                <?php if($search || $karyawanId !== 'all' || $bulanFilter !== now()->format('Y-m')): ?>
                    <a href="<?php echo e(route('konveksi.hanca-selesai')); ?>" class="flex-1 md:flex-none text-gray-500 hover:text-gray-700 px-4 py-2 text-sm bg-white border border-gray-300 rounded-lg text-center transition flex items-center justify-center">
                        Reset
                    </a>
                <?php endif; ?>
            </div>
        </form>
    </div>

    
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden mb-6">
        <div class="px-4 sm:px-5 py-3 bg-gray-50 border-b border-gray-100 flex items-center justify-between">
            <h3 class="font-bold text-gray-800 text-sm sm:text-base">Status Produksi (Potong Kain & Jahit)</h3>
            <span class="text-xs text-gray-500">
                Total: <?php echo e($groupedByKategori->get('Potong Kain', collect())->sum(fn($h) => $h->details->count())); ?> Data
            </span>
        </div>

        <div class="w-full overflow-x-auto">
            <table class="w-full text-xs sm:text-sm text-left min-w-[1000px]">
                <thead class="bg-white border-b border-gray-100">
                    <tr>
                        <th class="py-2 px-3 text-[10px] font-semibold text-gray-500 uppercase text-center">Tgl Potong</th>
                        <th class="py-2 px-3 text-[10px] font-semibold text-gray-500 uppercase">Tukang Potong</th>
                        <th class="py-2 px-3 text-[10px] font-semibold text-gray-500 uppercase">Produk (Warna/Size)</th>
                        <th class="py-2 px-3 text-[10px] font-semibold text-gray-500 uppercase text-right">Qty Potong</th>
                        <th class="py-2 px-3 text-[10px] font-semibold text-gray-500 uppercase text-center">Status Jahit</th>
                        <th class="py-2 px-3 text-[10px] font-semibold text-gray-500 uppercase">Tukang Jahit</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                    <?php $__empty_1 = true; $__currentLoopData = $groupedByKategori->get('Potong Kain', collect()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hancaPotong): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php $__currentLoopData = $hancaPotong->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detailPotong): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $jahitDetail = $detailPotong->turunanJahit->first();
                                
                                // Hitung total Qty yang sudah disetor ke jahit
                                $qtyJahitDisetor = 0;
                                if ($jahitDetail) {
                                    $qtyJahitDisetor = $jahitDetail->jumlah_hanca - $jahitDetail->sisa_hanca;
                                }

                                $totalQtyPotong = $detailPotong->jumlah_hanca;
                                
                                // Tentukan status
                                if ($qtyJahitDisetor <= 0) {
                                    $statusJahit = 'Belum Dijahit';
                                    $statusClass = 'bg-orange-100 text-orange-700 border-orange-200';
                                } elseif ($qtyJahitDisetor < $totalQtyPotong) {
                                    $statusJahit = 'Sebagian';
                                    $statusClass = 'bg-yellow-100 text-yellow-700 border-yellow-200';
                                } else {
                                    $statusJahit = 'Selesai Jahit';
                                    $statusClass = 'bg-green-100 text-green-700 border-green-200';
                                }

                                // Tukang jahit muncul jika sudah ada data jahit
                                $tukangJahit = $jahitDetail ? ($jahitDetail->hanca->karyawan->nama ?? '-') : null;
                                $tglJahit = $jahitDetail ? $jahitDetail->hanca->tanggal->format('d/m/Y') : null;
                            ?>
                            <tr class="hover:bg-gray-50 transition">
                                <td class="py-2 px-3 text-xs text-gray-700 whitespace-nowrap text-center"><?php echo e($hancaPotong->tanggal->format('d/m/Y')); ?></td>
                                <td class="py-2 px-3 font-medium text-gray-800 whitespace-nowrap"><?php echo e($hancaPotong->karyawan->nama ?? '-'); ?></td>
                                <td class="py-2 px-3 text-xs text-gray-800 whitespace-nowrap">
                                    <?php echo e($detailPotong->nama_produk); ?> 
                                    <span class="text-gray-500">(<?php echo e($detailPotong->warna ?? '-'); ?> / <?php echo e($detailPotong->ukuran ?? '-'); ?>)</span>
                                </td>
                                <td class="py-2 px-3 text-right font-bold text-gray-800 whitespace-nowrap"><?php echo e($detailPotong->jumlah_hanca); ?> pcs</td>
                                
                                
                                <td class="py-2 px-3 text-center whitespace-nowrap">
                                    <span class="inline-flex items-center gap-1 text-[10px] <?php echo e($statusClass); ?> border px-2 py-1 rounded font-semibold">
                                        <?php if($statusJahit === 'Selesai Jahit'): ?>
                                            <iconify-icon icon="mdi:check-circle" class="text-xs"></iconify-icon>
                                        <?php elseif($statusJahit === 'Sebagian'): ?>
                                            <iconify-icon icon="mdi:progress-clock" class="text-xs"></iconify-icon>
                                        <?php else: ?>
                                            <iconify-icon icon="mdi:clock-outline" class="text-xs"></iconify-icon>
                                        <?php endif; ?>
                                        <?php echo e($statusJahit); ?>

                                    </span>
                                    
                                    
                                    <?php if($qtyJahitDisetor > 0): ?>
                                        <div class="text-[10px] text-gray-600 mt-1 font-medium">
                                            <?php echo e($qtyJahitDisetor); ?> / <?php echo e($totalQtyPotong); ?> pcs
                                        </div>
                                    <?php endif; ?>
                                    
                                    <?php if($tglJahit): ?>
                                        <div class="text-[10px] text-gray-400 mt-0.5"><?php echo e($tglJahit); ?></div>
                                    <?php endif; ?>
                                </td>

                                
                                <td class="py-2 px-3 font-medium whitespace-nowrap <?php echo e($tukangJahit ? 'text-indigo-600' : 'text-gray-400'); ?>">
                                    <?php echo e($tukangJahit ?? '-'); ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="py-8 text-center text-gray-500">
                                Belum ada data Potong Kain yang selesai.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    
    <?php
        $jahitTanpaPotong = collect();
        if ($groupedByKategori->has('Jahit')) {
            foreach($groupedByKategori->get('Jahit') as $h) {
                foreach($h->details as $d) {
                    if (!$d->sumber_potong_id) {
                        $jahitTanpaPotong->push(['hanca' => $h, 'detail' => $d]);
                    }
                }
            }
        }
    ?>

    <?php if($jahitTanpaPotong->count() > 0): ?>
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden mt-6">
        <div class="px-4 sm:px-5 py-3 bg-gray-50 border-b border-gray-100">
            <h3 class="font-bold text-gray-800 text-sm sm:text-base">Jahit Mandiri (Tanpa Potong Kain)</h3>
        </div>
        <table class="w-full text-xs sm:text-sm text-left">
            <thead class="bg-white border-b border-gray-100">
                <tr>
                    <th class="py-2 px-3 text-[10px] font-semibold text-gray-500 uppercase">Tanggal Jahit</th>
                    <th class="py-2 px-3 text-[10px] font-semibold text-gray-500 uppercase">Tukang Jahit</th>
                    <th class="py-2 px-3 text-[10px] font-semibold text-gray-500 uppercase">Produk</th>
                    <th class="py-2 px-3 text-[10px] font-semibold text-gray-500 uppercase text-right">Qty</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-100">
                <?php $__currentLoopData = $jahitTanpaPotong; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="hover:bg-gray-50 transition">
                        <td class="py-2 px-3 text-xs text-gray-700"><?php echo e($item['hanca']->tanggal->format('d/m/Y')); ?></td>
                        <td class="py-2 px-3 font-medium text-gray-800"><?php echo e($item['hanca']->karyawan->nama ?? '-'); ?></td>
                        <td class="py-2 px-3 text-xs text-gray-800"><?php echo e($item['detail']->nama_produk); ?> (<?php echo e($item['detail']->warna); ?> / <?php echo e($item['detail']->ukuran); ?>)</td>
                        <td class="py-2 px-3 text-right font-bold text-gray-800"><?php echo e($item['detail']->jumlah_hanca); ?> pcs</td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>

    
    <?php
        // ✅ FIX: Menggunakan filter() pada Collection, bukan except()
        $kategoriLain = $groupedByKategori->filter(function($value, $key) {
            return $key !== 'Potong Kain' && $key !== 'Jahit';
        });
    ?>

    <?php if($kategoriLain->count() > 0): ?>
        <?php $__currentLoopData = $kategoriLain; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori => $hancas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden mt-6">
                <div class="px-4 sm:px-5 py-3 bg-gray-50 border-b border-gray-100 flex items-center justify-between">
                    <h3 class="font-bold text-gray-800 text-sm sm:text-base">Hanca Selesai - <?php echo e($kategori); ?></h3>
                    <span class="text-xs text-gray-500"><?php echo e($hancas->count()); ?> Hanca</span>
                </div>
                <table class="w-full text-xs sm:text-sm text-left">
                    <thead class="bg-white border-b border-gray-100">
                        <tr>
                            <th class="py-2 px-3 text-[10px] font-semibold text-gray-500 uppercase">Tgl Selesai</th>
                            <th class="py-2 px-3 text-[10px] font-semibold text-gray-500 uppercase">Karyawan</th>
                            <th class="py-2 px-3 text-[10px] font-semibold text-gray-500 uppercase">Produk</th>
                            <th class="py-2 px-3 text-[10px] font-semibold text-gray-500 uppercase text-center">Warna / Ukuran</th>
                            <th class="py-2 px-3 text-[10px] font-semibold text-gray-500 uppercase text-right">Qty Total</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-100">
                        <?php $__currentLoopData = $hancas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hanca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $hanca->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="hover:bg-gray-50 transition">
                                    <td class="py-2 px-3 text-xs text-gray-700 whitespace-nowrap"><?php echo e($hanca->updated_at->format('d/m/Y')); ?></td>
                                    <td class="py-2 px-3 font-medium text-gray-800 whitespace-nowrap"><?php echo e($hanca->karyawan->nama ?? '-'); ?></td>
                                    <td class="py-2 px-3 text-xs text-gray-800 whitespace-nowrap"><?php echo e($detail->nama_produk); ?></td>
                                    <td class="py-2 px-3 text-center text-xs text-gray-600 whitespace-nowrap"><?php echo e($detail->warna ?? '-'); ?> / <?php echo e($detail->ukuran ?? '-'); ?></td>
                                    <td class="py-2 px-3 text-right font-semibold text-gray-800 whitespace-nowrap"><?php echo e($detail->jumlah_hanca); ?> pcs</td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pembukuan\resources\views\konveksi\hanca-selesai.blade.php ENDPATH**/ ?>