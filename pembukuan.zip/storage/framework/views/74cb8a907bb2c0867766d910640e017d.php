<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', 'Pembukuan'); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://code.iconify.design/iconify-icon/2.1.0/iconify-icon.min.js"></script>
    <link rel="shortcut icon" href="<?php echo e(asset('images/favicon.png')); ?>" type="image/x-icon">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Geist:ital,wght@0,100..900;1,100..900&display=swap');
        * {
            font-family: 'Geist', sans-serif;
        }
        iconify-icon {
            display: inline-block;
            vertical-align: middle;
        }
        /* Custom scrollbar untuk sidebar */
        nav::-webkit-scrollbar {
            width: 4px;
        }
        nav::-webkit-scrollbar-track {
            background: transparent;
        }
        nav::-webkit-scrollbar-thumb {
            background: #e5e7eb;
            border-radius: 4px;
        }
        nav::-webkit-scrollbar-thumb:hover {
            background: #d1d5db;
        }
    </style>
</head>
<body class="bg-gray-100 min-h-screen">

<?php
    $navItems = [
        [
            'section' => 'Utama',
            'items' => [
                ['route' => 'shopee.index',  'label' => 'Laporan Shopee',  'icon' => 'mdi:shopping-outline'],
                ['route' => 'tiktok.index',  'label' => 'Laporan TikTok',  'icon' => 'mdi:music-note-outline'],
            ],
        ],
        [
            'section' => 'BRILink',
            'items' => [
                [
                    'route' => 'brilink.index',
                    'label' => 'Laporan BRILink',
                    'icon' => 'mdi:bank-outline',
                    'submenu' => [
                        ['route' => 'brilink.index', 'label' => 'Ringkasan & Saldo'],
                        ['route' => 'brilink.saldo-keseluruhan', 'label' => 'Data Saldo Keseluruhan'],
                        ['route' => 'brilink.pengeluaran', 'label' => 'Laporan Pengeluaran'],
                        ['route' => 'brilink.log-ppob', 'label' => 'Log Pulsa & PPOB'],
                        ['route' => 'brilink.log-setoran', 'label' => 'Log Setoran BRILink'],
                        ['route' => 'brilink.log-tarik-tunai', 'label' => 'Log Tarik Tunai'],
                        ['route' => 'brilink.profit', 'label' => 'Laporan Profit'],
                        ['route' => 'brilink.laporan-brangkas', 'label' => 'Laporan Brangkas'],
                        ['route' => 'tabungan.index', 'label' => 'Laporan Tabungan'],
                        ['route' => 'zakat.index', 'label' => 'Laporan Zakat', 'icon' => 'mdi:hand-heart'],
                    ]
                ]
            ],
        ],
        [
            'section' => 'Gaji Karyawan',
            'items' => [
                ['route' => 'karyawan.index', 'label' => 'Data Karyawan',  'icon' => 'mdi:account-group'],
                ['route' => 'gaji.index',     'label' => 'Transaksi Gaji', 'icon' => 'mdi:cash-multiple'],
                ['route' => 'minus.index',    'label' => 'Laporan Minus',  'icon' => 'mdi:alert-circle-outline'],
            ],
        ],
        [
            'section' => 'Data Master',
            'items' => [
                ['route' => 'import.index',        'label' => 'Import Shopee',  'icon' => 'mdi:import'],
                ['route' => 'tiktok.import',       'label' => 'Import TikTok',  'icon' => 'mdi:music-note'],
                ['route' => 'brilink.import',      'label' => 'Import BRILink', 'icon' => 'mdi:bank'],
                ['route' => 'products.index',      'label' => 'Produk',         'icon' => 'mdi:package-variant-closed'],
                ['route' => 'stores.index',        'label' => 'Toko',           'icon' => 'mdi:store-outline'],
            ],
        ],
    ];
?>

<div class="flex min-h-screen relative overflow-hidden">

    
    <div id="sidebarOverlay" 
         class="fixed inset-0 bg-black/50 z-40 hidden transition-opacity lg:hidden" 
         onclick="toggleSidebar()"></div>

    
    <!-- Di desktop: w-64 tetap. Di mobile: posisi fixed, geser ke kiri (-translate-x-full) -->
    <aside id="sidebar" 
           class="w-64 bg-white border-r border-gray-200 flex flex-col fixed h-screen z-50 transition-transform duration-300 transform -translate-x-full lg:translate-x-0">

        
        <div class="h-16 flex items-center justify-between px-6 border-b border-gray-200">
            <a href="/" class="flex items-center gap-2 font-bold text-lg text-gray-800">
                <div class="w-8 h-8 bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg flex items-center justify-center shadow-sm shadow-blue-500/30">
                    <iconify-icon icon="mdi:book-open-variant" class="text-white text-lg"></iconify-icon>
                </div>
                BukuBarokah
            </a>
            
            <button class="lg:hidden text-gray-500 hover:text-gray-700" onclick="toggleSidebar()">
                <iconify-icon icon="mdi:close" class="text-2xl"></iconify-icon>
            </button>
        </div>

        
        <nav class="flex-1 overflow-y-auto py-4">
            <?php $__currentLoopData = $navItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="mb-4">
                    <div class="px-6 mb-1 text-xs font-semibold text-gray-400 uppercase tracking-wider">
                        <?php echo e($group['section']); ?>

                    </div>

                    <?php $__currentLoopData = $group['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $isActive = request()->routeIs($item['route']);
                            $hasSubmenu = isset($item['submenu']);
                            // Cek apakah ada submenu yang aktif
                            $isSubmenuActive = $hasSubmenu && collect($item['submenu'])->contains(fn($sub) => request()->routeIs($sub['route']));
                            if ($isSubmenuActive) $isActive = true;
                        ?>

                        <a href="<?php echo e(route($item['route'])); ?>"
                           class="flex items-center justify-between px-6 py-2.5 text-sm transition
                                  <?php echo e($isActive
                                      ? 'bg-blue-50 text-blue-700 font-medium border-r-2 border-blue-600'
                                      : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'); ?>">
                            <div class="flex items-center gap-3">
                                <iconify-icon icon="<?php echo e($item['icon']); ?>" class="text-lg <?php echo e($isActive ? 'text-blue-600' : 'text-gray-400'); ?>"></iconify-icon>
                                <?php echo e($item['label']); ?>

                            </div>
                            <?php if($hasSubmenu): ?>
                                <iconify-icon icon="mdi:chevron-down" class="text-sm <?php echo e($isActive ? 'text-blue-600' : 'text-gray-400'); ?>"></iconify-icon>
                            <?php endif; ?>
                        </a>

                        
                        <?php if($hasSubmenu && ($isActive || request()->routeIs('brilink.*'))): ?>
                            <div class="bg-gray-50/50 py-1 border-r-2 border-transparent">
                                <?php $__currentLoopData = $item['submenu']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $isSubActive = request()->routeIs($sub['route']); ?>
                                    <a href="<?php echo e(route($sub['route'])); ?>"
                                       class="flex items-center gap-3 pl-14 pr-6 py-2 text-xs transition
                                              <?php echo e($isSubActive
                                                  ? 'text-blue-700 font-medium'
                                                  : 'text-gray-500 hover:text-gray-800'); ?>">
                                        <div class="w-1.5 h-1.5 rounded-full <?php echo e($isSubActive ? 'bg-blue-600' : 'bg-gray-300'); ?>"></div>
                                        <?php echo e($sub['label']); ?>

                                    </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </nav>

        
        <div class="border-t border-gray-200 p-4">
            <div class="flex items-center gap-3 mb-3">
                <div class="w-9 h-9 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center flex-shrink-0 shadow-sm shadow-blue-500/30">
                    <iconify-icon icon="mdi:account" class="text-white text-lg"></iconify-icon>
                </div>
                <div class="flex-1 min-w-0">
                    <div class="text-xs font-semibold text-gray-800 truncate">
                        <?php echo e(Auth::user()->name ?? 'Admin'); ?>

                    </div>
                    <div class="text-[10px] text-gray-400 truncate">
                        <?php echo e(Auth::user()->email ?? ''); ?>

                    </div>
                </div>
            </div>

            
            <form action="<?php echo e(route('logout')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <button type="submit"
                        class="w-full flex items-center justify-center gap-2 px-3 py-2 text-xs font-medium
                               text-red-600 bg-red-50 hover:bg-red-100 hover:text-red-700
                               rounded-lg transition border border-red-100">
                    <iconify-icon icon="mdi:logout" class="text-base"></iconify-icon>
                    Logout
                </button>
            </form>

            <div class="text-[10px] text-gray-400 text-center mt-3">
                v1.0 · BukuBarokah
            </div>
        </div>
    </aside>

    
    <!-- Di desktop margin-left 64 (ml-64), di mobile margin-left 0 (ml-0) -->
    <div class="flex-1 w-full min-h-screen transition-all duration-300 ml-0 lg:ml-64 flex flex-col">

        
        <header class="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-4 sm:px-8 sticky top-0 z-30">
            
            <div class="flex items-center gap-3">
                
                <button class="lg:hidden p-2 -ml-2 text-gray-600 hover:bg-gray-100 rounded-lg transition" onclick="toggleSidebar()">
                    <iconify-icon icon="mdi:menu" class="text-2xl"></iconify-icon>
                </button>

                
                <h1 class="text-lg font-semibold text-gray-800 truncate">
                    <?php echo $__env->yieldContent('title', 'Pembukuan'); ?>
                </h1>
            </div>

            
            <div class="relative" id="userDropdownContainer">
                <button type="button"
                        onclick="toggleUserDropdown()"
                        class="flex items-center gap-3 pl-2 pr-3 py-1.5 rounded-lg hover:bg-gray-50 transition group">
                    
                    <div class="w-9 h-9 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center shadow-sm shadow-blue-500/30 flex-shrink-0">
                        <iconify-icon icon="mdi:account" class="text-white text-lg"></iconify-icon>
                    </div>

                    
                    <div class="text-left hidden sm:block">
                        <div class="text-sm font-semibold text-gray-800 leading-tight">
                            <?php echo e(Auth::user()->name ?? 'Admin'); ?>

                        </div>
                        <div class="text-[10px] text-gray-400 leading-tight truncate max-w-[140px]">
                            <?php echo e(Auth::user()->email ?? ''); ?>

                        </div>
                    </div>

                    
                    <iconify-icon icon="mdi:chevron-down"
                                  class="text-gray-400 text-base transition-transform group-hover:text-gray-600"></iconify-icon>
                </button>

                
                <div id="userDropdown"
                     class="hidden absolute right-0 mt-2 w-64 bg-white rounded-xl shadow-lg border border-gray-100 overflow-hidden z-50">
                    
                    <div class="px-4 py-3 border-b border-gray-100 bg-gradient-to-r from-blue-50 to-white">
                        <div class="flex items-center gap-3">
                            <div class="w-11 h-11 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center shadow-sm shadow-blue-500/30 flex-shrink-0">
                                <iconify-icon icon="mdi:account" class="text-white text-xl"></iconify-icon>
                            </div>
                            <div class="flex-1 min-w-0">
                                <div class="text-sm font-semibold text-gray-800 truncate">
                                    <?php echo e(Auth::user()->name ?? 'Admin'); ?>

                                </div>
                                <div class="text-xs text-gray-500 truncate">
                                    <?php echo e(Auth::user()->email ?? ''); ?>

                                </div>
                            </div>
                        </div>
                    </div>

                    
                    <div class="py-1">
                        <div class="px-4 py-2 flex items-center gap-2 text-xs text-gray-500">
                            <iconify-icon icon="mdi:calendar" class="text-sm"></iconify-icon>
                            Login sejak: <?php echo e(now()->format('d M Y')); ?>

                        </div>
                    </div>

                    
                    <div class="border-t border-gray-100 p-2">
                        <form action="<?php echo e(route('logout')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button type="submit"
                                    class="w-full flex items-center gap-2 px-3 py-2 text-sm font-medium
                                           text-red-600 hover:bg-red-50 rounded-lg transition">
                                <iconify-icon icon="mdi:logout" class="text-base"></iconify-icon>
                                Logout
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </header>

        
        <main class="p-4 sm:p-6 lg:p-8 flex-1 overflow-x-hidden">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
</div>

<script>
    // ==================== SIDEBAR RESPONSIVE ====================
    function toggleSidebar() {
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('sidebarOverlay');
        
        // Toggle class translate-x (geser sidebar)
        sidebar.classList.toggle('-translate-x-full');
        sidebar.classList.toggle('translate-x-0');

        // Toggle overlay (latar hitam transparan)
        if (overlay.classList.contains('hidden')) {
            overlay.classList.remove('hidden');
            // delay dikit biar animasi transisi opacity jalan
            setTimeout(() => overlay.classList.remove('opacity-0'), 10); 
        } else {
            overlay.classList.add('opacity-0');
            setTimeout(() => overlay.classList.add('hidden'), 300);
        }
    }

    // ==================== USER DROPDOWN ====================
    function toggleUserDropdown() {
        const dropdown = document.getElementById('userDropdown');
        dropdown.classList.toggle('hidden');
    }

    // Klik di luar = tutup dropdown
    document.addEventListener('click', function (e) {
        const container = document.getElementById('userDropdownContainer');
        const dropdown = document.getElementById('userDropdown');
        if (container && !container.contains(e.target)) {
            dropdown.classList.add('hidden');
        }
    });

    // ESC = tutup dropdown & sidebar
    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') {
            document.getElementById('userDropdown').classList.add('hidden');
            
            // Tutup sidebar jika sedang terbuka di mobile
            const sidebar = document.getElementById('sidebar');
            const overlay = document.getElementById('sidebarOverlay');
            if (sidebar.classList.contains('translate-x-0') && window.innerWidth < 1024) {
                toggleSidebar();
            }
        }
    });
</script>

</body>
</html><?php /**PATH C:\xampp\htdocs\pembukuan\resources\views/layouts/app.blade.php ENDPATH**/ ?>