

<?php $__env->startSection('title', 'Laporan Zakat'); ?>

<?php $__env->startSection('content'); ?>
<div class="w-full">

    
    <div class="flex flex-col sm:justify-end sm:flex-row gap-2 w-full sm:w-auto mb-4">
        <a href="<?php echo e(route('laporan-zakat.index')); ?>"
        class="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-emerald-600 text-white px-4 py-2 rounded-lg hover:bg-emerald-700 transition text-sm font-medium shadow-sm">
            <iconify-icon icon="mdi:cash-check" class="text-lg"></iconify-icon> Laporan Bayar Zakat
        </a>
        <button type="button" onclick="openBayarZakatModal()"
            class="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition text-sm font-medium shadow-sm">
            <iconify-icon icon="mdi:cash-register" class="text-lg"></iconify-icon> Bayar Zakat
        </button>
        <a href="<?php echo e(route('zakat.invoice-pdf', ['store' => $storeId])); ?>" target="_blank"
            class="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700 transition text-sm font-medium shadow-sm">
            <iconify-icon icon="mdi:printer" class="text-lg"></iconify-icon> Cetak PDF
        </a>
    </div>

    
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4 mb-6">
        <form method="GET" class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 items-end gap-3">
            
            
            <div class="w-full">
                <label class="block text-xs font-medium text-gray-600 mb-1">Toko (Sumber Saldo & Piutang)</label>
                <select name="store" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-emerald-600 focus:outline-none">
                    <option value="all" <?php echo e($storeId === 'all' ? 'selected' : ''); ?>>Semua Toko</option>
                    <?php $__currentLoopData = $stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($s->id); ?>" <?php echo e($storeId == $s->id ? 'selected' : ''); ?>><?php echo e($s->nama_toko); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            
            <div class="w-full">
                <label class="block text-xs font-medium text-gray-600 mb-1">Dari Tanggal</label>
                <input type="date" name="from" value="<?php echo e($from ?? ''); ?>" 
                    class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-emerald-600 focus:outline-none">
            </div>

            
            <div class="w-full">
                <label class="block text-xs font-medium text-gray-600 mb-1">Sampai Tanggal</label>
                <input type="date" name="to" value="<?php echo e($to ?? ''); ?>" 
                    class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-emerald-600 focus:outline-none">
            </div>

            
            <div class="flex gap-2 w-full">
                <button type="submit" class="flex-1 bg-emerald-600 text-white px-4 py-2 rounded-lg hover:bg-emerald-700 transition text-sm font-medium flex items-center justify-center gap-2">
                    <iconify-icon icon="mdi:filter" class="text-lg"></iconify-icon> Terapkan Filter
                </button>
                <?php if($from || $to || $storeId !== 'all'): ?>
                    <a href="<?php echo e(route('zakat.index')); ?>" 
                    class="flex-1 bg-gray-100 text-gray-700 border border-gray-200 px-4 py-2 rounded-lg hover:bg-gray-200 transition text-sm font-medium flex items-center justify-center gap-2">
                        <iconify-icon icon="mdi:close-circle" class="text-lg"></iconify-icon> Reset
                    </a>
                <?php endif; ?>
            </div>
        </form>
    </div>

    
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden mb-6">
        <div class="px-4 sm:px-5 py-4 border-b border-gray-100 flex flex-col sm:flex-row sm:items-center justify-between gap-2 bg-gradient-to-r from-blue-50 to-white">
            <div class="flex items-center gap-2">
                <iconify-icon icon="mdi:wallet" class="text-blue-600 text-lg"></iconify-icon>
                <h3 class="font-semibold text-gray-800 text-sm sm:text-base">Zakat dari Saldo</h3>
            </div>
            <span class="text-[10px] sm:text-xs text-gray-500 bg-white px-2 py-1 rounded border w-max">Snapshot terakhir</span>
        </div>
        
        <div class="p-4 sm:p-5 grid grid-cols-1 md:grid-cols-3 gap-4 border-b border-gray-100">
            <div>
                <div class="text-[10px] sm:text-xs text-gray-500 mb-1">Total Saldo Aset Likuid</div>
                <div class="text-base sm:text-xl font-bold text-gray-800">Rp <?php echo e(number_format($totalSaldo, 0, ',', '.')); ?></div>
                <div class="text-[9px] text-gray-400 mt-1">
                    Termasuk Saldo Online: Rp <?php echo e(number_format($totalSaldoOnline, 0, ',', '.')); ?>

                </div>
            </div>
            <div>
                <div class="text-[10px] sm:text-xs text-gray-500 mb-1">Rate Zakat</div>
                <div class="text-base sm:text-xl font-bold text-gray-800">2,5%</div>
            </div>
            <div>
                <div class="text-[10px] sm:text-xs text-gray-500 mb-1">Zakat Saldo</div>
                <div class="text-base sm:text-xl font-bold text-blue-700">Rp <?php echo e(number_format($zakatSaldo, 0, ',', '.')); ?></div>
            </div>
        </div>

        <?php if(!empty($breakdownSaldo)): ?>
            
            <div class="hidden md:block overflow-x-auto">
                <table class="w-full text-xs">
                    <thead class="bg-gray-50 border-b">
                        <tr>
                            <th class="text-left py-2 px-4 font-semibold text-gray-500 uppercase whitespace-nowrap">Rekening</th>
                            <th class="text-left py-2 px-4 font-semibold text-gray-500 uppercase whitespace-nowrap">Kategori</th>
                            <th class="text-right py-2 px-4 font-semibold text-gray-500 uppercase whitespace-nowrap">Saldo Saat Ini</th>
                            <th class="text-right py-2 px-4 font-semibold text-gray-500 uppercase whitespace-nowrap">Zakat (2,5%)</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-100">
                        <?php $__currentLoopData = $breakdownSaldo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="hover:bg-gray-50">
                                <td class="py-2 px-4 font-medium text-gray-800"><?php echo e($b['nama_rekening']); ?></td>
                                <td class="py-2 px-4">
                                    <?php if($b['keterangan'] && $b['keterangan'] !== '-'): ?>
                                        <span class="bg-gray-100 text-gray-700 px-2 py-0.5 rounded"><?php echo e($b['keterangan']); ?></span>
                                    <?php else: ?>
                                        <span class="text-gray-400">-</span>
                                    <?php endif; ?>
                                </td>
                                <td class="py-2 px-4 text-right text-gray-700">Rp <?php echo e(number_format($b['saldo'], 0, ',', '.')); ?></td>
                                <td class="py-2 px-4 text-right font-semibold text-blue-700">Rp <?php echo e(number_format($b['zakat'], 0, ',', '.')); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $saldoOnlineList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $so): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="hover:bg-gray-50 bg-blue-50/20">
                                <td class="py-2 px-4 font-medium text-gray-800"><?php echo e($so->marketplace); ?></td>
                                <td class="py-2 px-4">
                                    <span class="bg-blue-100 text-blue-700 px-2 py-0.5 rounded text-[10px]">Marketplace</span>
                                </td>
                                <td class="py-2 px-4 text-right text-gray-700">Rp <?php echo e(number_format($so->saldo, 0, ',', '.')); ?></td>
                                <td class="py-2 px-4 text-right font-semibold text-blue-700">Rp <?php echo e(number_format(round($so->saldo * 0.025), 0, ',', '.')); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot class="bg-blue-50 border-t-2 border-blue-200">
                        <tr>
                            <td colspan="2" class="py-2 px-4 font-bold text-gray-800">TOTAL</td>
                            <td class="py-2 px-4 text-right font-bold text-gray-800">Rp <?php echo e(number_format($totalSaldo, 0, ',', '.')); ?></td>
                            <td class="py-2 px-4 text-right font-bold text-blue-800">Rp <?php echo e(number_format($zakatSaldo, 0, ',', '.')); ?></td>
                        </tr>
                    </tfoot>
                </table>
            </div>

            
            <div class="md:hidden divide-y divide-gray-100">
                <?php $__currentLoopData = $breakdownSaldo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="p-4 space-y-1 text-xs">
                        <div class="flex justify-between items-start gap-2">
                            <span class="font-bold text-gray-800 text-sm"><?php echo e($b['nama_rekening']); ?></span>
                            <?php if($b['keterangan'] && $b['keterangan'] !== '-'): ?>
                                <span class="bg-gray-100 text-gray-700 px-2 py-0.5 rounded text-[10px]"><?php echo e($b['keterangan']); ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="flex justify-between items-center pt-1">
                            <span class="text-gray-500">Saldo:</span>
                            <span class="font-medium text-gray-700">Rp <?php echo e(number_format($b['saldo'], 0, ',', '.')); ?></span>
                        </div>
                        <div class="flex justify-between items-center">
                            <span class="text-gray-500">Zakat (2,5%):</span>
                            <span class="font-bold text-blue-700">Rp <?php echo e(number_format($b['zakat'], 0, ',', '.')); ?></span>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $saldoOnlineList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $so): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="p-4 space-y-1 text-xs bg-blue-50/20">
                        <div class="flex justify-between items-start gap-2">
                            <span class="font-bold text-gray-800 text-sm"><?php echo e($so->marketplace); ?></span>
                            <span class="bg-blue-100 text-blue-700 px-2 py-0.5 rounded text-[10px]">Marketplace</span>
                        </div>
                        <div class="flex justify-between items-center pt-1">
                            <span class="text-gray-500">Saldo:</span>
                            <span class="font-medium text-gray-700">Rp <?php echo e(number_format($so->saldo, 0, ',', '.')); ?></span>
                        </div>
                        <div class="flex justify-between items-center">
                            <span class="text-gray-500">Zakat (2,5%):</span>
                            <span class="font-bold text-blue-700">Rp <?php echo e(number_format(round($so->saldo * 0.025), 0, ',', '.')); ?></span>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="p-4 bg-blue-50 flex justify-between items-center font-bold text-xs">
                    <span class="text-gray-800">TOTAL ZAKAT SALDO</span>
                    <span class="text-blue-800 text-sm">Rp <?php echo e(number_format($zakatSaldo, 0, ',', '.')); ?></span>
                </div>
            </div>
        <?php endif; ?>

        
        <div class="p-4 sm:p-5 bg-gray-50/50 border-t border-gray-100">
            <h4 class="text-xs font-bold text-gray-600 uppercase tracking-wider mb-3">Tambah Saldo Online</h4>
            <form onsubmit="submitSaldoOnline(event)" class="flex flex-col sm:flex-row gap-2">
                <div class="w-full sm:w-1/3">
                    <input type="text" id="inputMarketplace" required placeholder="Marketplace (cth: Shopee)"
                        class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none">
                </div>
                <div class="w-full sm:flex-1 relative">
                    <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <span class="text-gray-500 text-sm font-medium">Rp</span>
                    </div>
                    <input type="text" id="inputSaldoOnline" required placeholder="0"
                        class="w-full border border-gray-300 rounded-lg pl-10 pr-3 py-2 text-sm font-bold focus:ring-2 focus:ring-blue-500 focus:outline-none">
                </div>
                <button type="submit" id="btnSubmitSaldoOnline" class="w-full sm:w-auto bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition text-sm font-medium flex items-center justify-center gap-2">
                    <iconify-icon icon="mdi:plus" class="text-lg"></iconify-icon> Tambah
                </button>
            </form>
            
            
            <?php if($saldoOnlineList->isNotEmpty()): ?>
                <div class="mt-3 flex flex-wrap gap-2">
                    <?php $__currentLoopData = $saldoOnlineList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $so): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="inline-flex items-center gap-1 bg-white border border-gray-200 px-2 py-1 rounded text-xs text-gray-600">
                            <span><?php echo e($so->marketplace); ?>: <strong>Rp <?php echo e(number_format($so->saldo, 0, ',', '.')); ?></strong></span>
                            <button type="button" onclick="deleteSaldoOnline(<?php echo e($so->id); ?>, '<?php echo e(addslashes($so->marketplace)); ?>')" class="text-red-500 hover:text-red-700 ml-1">
                                <iconify-icon icon="mdi:close-circle" class="text-sm"></iconify-icon>
                            </button>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        </div>
    </div>

    
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden mb-6">
        <div class="px-4 sm:px-5 py-4 border-b border-gray-100 flex flex-col sm:flex-row sm:items-center justify-between gap-2 bg-gradient-to-r from-amber-50 to-white">
            <div class="flex items-center gap-2">
                <iconify-icon icon="mdi:account-cash" class="text-amber-600 text-lg"></iconify-icon>
                <h3 class="font-semibold text-gray-800 text-sm sm:text-base">Zakat dari Piutang</h3>
            </div>
            <span class="text-[10px] sm:text-xs text-gray-500 bg-white px-2 py-1 rounded border w-max">Belum lunas</span>
        </div>
        
        <div class="p-4 sm:p-5 grid grid-cols-1 md:grid-cols-3 gap-4 border-b border-gray-100">
            <div>
                <div class="text-[10px] sm:text-xs text-gray-500 mb-1">Total Sisa Piutang</div>
                <div class="text-base sm:text-xl font-bold text-gray-800">Rp <?php echo e(number_format($totalPiutang, 0, ',', '.')); ?></div>
            </div>
            <div>
                <div class="text-[10px] sm:text-xs text-gray-500 mb-1">Rate Zakat</div>
                <div class="text-base sm:text-xl font-bold text-gray-800">2,5%</div>
            </div>
            <div>
                <div class="text-[10px] sm:text-xs text-gray-500 mb-1">Zakat Piutang</div>
                <div class="text-base sm:text-xl font-bold text-amber-700">Rp <?php echo e(number_format($zakatPiutang, 0, ',', '.')); ?></div>
            </div>
        </div>

        <?php if(!empty($piutangList)): ?>
            
            <div class="hidden md:block overflow-x-auto">
                <table class="w-full text-xs">
                    <thead class="bg-gray-50 border-b">
                        <tr>
                            <th class="text-left py-2 px-4 font-semibold text-gray-500 uppercase whitespace-nowrap">Keterangan</th>
                            <th class="text-right py-2 px-4 font-semibold text-gray-500 uppercase whitespace-nowrap">Piutang</th>
                            <th class="text-right py-2 px-4 font-semibold text-gray-500 uppercase whitespace-nowrap">Terbayar</th>
                            <th class="text-right py-2 px-4 font-semibold text-gray-500 uppercase whitespace-nowrap">Sisa</th>
                            <th class="text-right py-2 px-4 font-semibold text-gray-500 uppercase whitespace-nowrap">Zakat (2,5%)</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-100">
                        <?php $__currentLoopData = $piutangList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="hover:bg-gray-50">
                                <td class="py-2 px-4 text-gray-800"><?php echo e($p['keterangan']); ?></td>
                                <td class="py-2 px-4 text-right text-gray-700">Rp <?php echo e(number_format($p['nominal'], 0, ',', '.')); ?></td>
                                <td class="py-2 px-4 text-right text-emerald-600">Rp <?php echo e(number_format($p['terbayar'], 0, ',', '.')); ?></td>
                                <td class="py-2 px-4 text-right font-semibold text-gray-800">Rp <?php echo e(number_format($p['sisa'], 0, ',', '.')); ?></td>
                                <td class="py-2 px-4 text-right font-semibold text-amber-700">Rp <?php echo e(number_format($p['zakat'], 0, ',', '.')); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot class="bg-amber-50 border-t-2 border-amber-200">
                        <tr>
                            <td colspan="3" class="py-2 px-4 font-bold text-gray-800">TOTAL</td>
                            <td class="py-2 px-4 text-right font-bold text-gray-800">Rp <?php echo e(number_format($totalPiutang, 0, ',', '.')); ?></td>
                            <td class="py-2 px-4 text-right font-bold text-amber-800">Rp <?php echo e(number_format($zakatPiutang, 0, ',', '.')); ?></td>
                        </tr>
                    </tfoot>
                </table>
            </div>

            
            <div class="md:hidden divide-y divide-gray-100">
                <?php $__currentLoopData = $piutangList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="p-4 space-y-1 text-xs">
                        <div class="font-bold text-gray-800 text-sm mb-2"><?php echo e($p['keterangan']); ?></div>
                        <div class="flex justify-between items-center">
                            <span class="text-gray-500">Piutang:</span>
                            <span class="text-gray-700">Rp <?php echo e(number_format($p['nominal'], 0, ',', '.')); ?></span>
                        </div>
                        <div class="flex justify-between items-center">
                            <span class="text-gray-500">Terbayar:</span>
                            <span class="text-emerald-600">Rp <?php echo e(number_format($p['terbayar'], 0, ',', '.')); ?></span>
                        </div>
                        <div class="flex justify-between items-center">
                            <span class="text-gray-500">Sisa Tagihan:</span>
                            <span class="font-bold text-gray-800">Rp <?php echo e(number_format($p['sisa'], 0, ',', '.')); ?></span>
                        </div>
                        <div class="flex justify-between items-center pt-1 border-t border-gray-50 mt-1">
                            <span class="text-gray-500">Zakat (2,5%):</span>
                            <span class="font-bold text-amber-700">Rp <?php echo e(number_format($p['zakat'], 0, ',', '.')); ?></span>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="p-4 bg-amber-50 flex justify-between items-center font-bold text-xs">
                    <span class="text-gray-800">TOTAL ZAKAT PIUTANG</span>
                    <span class="text-amber-800 text-sm">Rp <?php echo e(number_format($zakatPiutang, 0, ',', '.')); ?></span>
                </div>
            </div>
        <?php else: ?>
            <div class="py-8 text-center text-gray-500 text-sm">
                <iconify-icon icon="mdi:check-circle-outline" class="text-3xl text-gray-300 block m-auto mb-1 w-max"></iconify-icon>
                Tidak ada piutang belum lunas.
            </div>
        <?php endif; ?>
    </div>

    
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden mb-6">
        <div class="px-4 sm:px-5 py-4 border-b border-gray-100 flex flex-col sm:flex-row sm:items-center justify-between gap-2 bg-gradient-to-r from-purple-50 to-white">
            <div class="flex items-center gap-2">
                <iconify-icon icon="mdi:package-variant-closed" class="text-purple-600 text-lg"></iconify-icon>
                <h3 class="font-semibold text-gray-800 text-sm sm:text-base">Zakat dari Barang Online</h3>
                <span class="text-[10px] bg-purple-100 text-purple-700 px-2 py-0.5 rounded font-medium">dari Kategori Produk</span>
            </div>
            <a href="<?php echo e(route('products.index')); ?>"
               class="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-white border border-purple-300 text-purple-700 px-3 py-1.5 rounded-lg hover:bg-purple-50 transition text-xs font-medium shadow-sm">
                <iconify-icon icon="mdi:pencil" class="text-sm"></iconify-icon>
                Kelola Kategori & Stok
            </a>
        </div>

        <?php if($barangList->isEmpty()): ?>
            <div class="py-10 text-center text-gray-500">
                <iconify-icon icon="mdi:package-variant" class="text-4xl text-gray-300 block m-auto mb-2 w-max"></iconify-icon>
                <div class="mb-3 text-sm">Belum ada kategori dengan stok &gt; 0.</div>
                <a href="<?php echo e(route('products.index')); ?>"
                   class="inline-flex items-center gap-1 bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition text-sm font-medium">
                    <iconify-icon icon="mdi:plus" class="text-sm"></iconify-icon>
                    Atur Stok di Kategori Produk
                </a>
            </div>
        <?php else: ?>
            
            <div class="hidden md:block overflow-x-auto">
                <table class="w-full text-sm">
                    <thead class="bg-gray-50 border-b">
                        <tr>
                            <th class="text-left py-3 px-4 text-xs font-semibold text-gray-500 uppercase">Nama Kategori</th>
                            <th class="text-left py-3 px-4 text-xs font-semibold text-gray-500 uppercase w-28">Prefix</th>
                            <th class="text-center py-3 px-4 text-xs font-semibold text-gray-500 uppercase w-20">Stok</th>
                            <th class="text-right py-3 px-4 text-xs font-semibold text-gray-500 uppercase">HPP</th>
                            <th class="text-right py-3 px-4 text-xs font-semibold text-gray-500 uppercase">Total</th>
                            <th class="text-right py-3 px-4 text-xs font-semibold text-gray-500 uppercase">Zakat (2,5%)</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-100">
                        <?php $__currentLoopData = $barangList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="hover:bg-gray-50">
                                <td class="py-3 px-4 font-medium text-gray-800">
                                    <?php echo e($b['nama_barang']); ?>

                                </td>
                                <td class="py-3 px-4">
                                    <span class="inline-block font-mono text-[10px] font-semibold bg-indigo-50 text-indigo-700 border border-indigo-200 px-2 py-0.5 rounded">
                                        <?php echo e($b['sku_prefix']); ?>

                                    </span>
                                </td>
                                <td class="py-3 px-4 text-center font-semibold text-gray-800"><?php echo e(number_format($b['qty'], 0, ',', '.')); ?></td>
                                <td class="py-3 px-4 text-right text-gray-700">Rp <?php echo e(number_format($b['harga_satuan'], 0, ',', '.')); ?></td>
                                <td class="py-3 px-4 text-right font-bold text-gray-800">Rp <?php echo e(number_format($b['total'], 0, ',', '.')); ?></td>
                                <td class="py-3 px-4 text-right font-semibold text-purple-700">
                                    Rp <?php echo e(number_format($b['zakat'], 0, ',', '.')); ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot class="bg-purple-50 border-t-2 border-purple-200">
                        <tr>
                            <td colspan="4" class="py-3 px-4 font-bold text-gray-800 text-right">TOTAL NILAI BARANG</td>
                            <td class="py-3 px-4 text-right font-bold text-gray-800">Rp <?php echo e(number_format($totalBarang, 0, ',', '.')); ?></td>
                            <td></td>
                        </tr>
                        <tr class="bg-purple-100">
                            <td colspan="5" class="py-3 px-4 font-bold text-purple-900 text-right">ZAKAT BARANG (2,5%)</td>
                            <td class="py-3 px-4 text-right font-bold text-purple-900 text-base">Rp <?php echo e(number_format($zakatBarang, 0, ',', '.')); ?></td>
                        </tr>
                    </tfoot>
                </table>
            </div>

            
            <div class="md:hidden divide-y divide-gray-100">
                <?php $__currentLoopData = $barangList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="p-4 space-y-1 text-xs">
                        <div class="flex items-center justify-between gap-2 mb-1">
                            <span class="font-bold text-gray-800 text-sm"><?php echo e($b['nama_barang']); ?></span>
                            <span class="font-mono text-[10px] font-semibold bg-indigo-50 text-indigo-700 border border-indigo-200 px-1.5 py-0.5 rounded"><?php echo e($b['sku_prefix']); ?></span>
                        </div>
                        <div class="flex justify-between items-center">
                            <span class="text-gray-500">Stok:</span>
                            <span class="font-semibold text-gray-800"><?php echo e(number_format($b['qty'], 0, ',', '.')); ?></span>
                        </div>
                        <div class="flex justify-between items-center">
                            <span class="text-gray-500">HPP:</span>
                            <span class="text-gray-700">Rp <?php echo e(number_format($b['harga_satuan'], 0, ',', '.')); ?></span>
                        </div>
                        <div class="flex justify-between items-center">
                            <span class="text-gray-500">Total:</span>
                            <span class="font-bold text-gray-800">Rp <?php echo e(number_format($b['total'], 0, ',', '.')); ?></span>
                        </div>
                        <div class="flex justify-between items-center pt-1 border-t border-gray-50 mt-1">
                            <span class="text-gray-500">Zakat (2,5%):</span>
                            <span class="font-bold text-purple-700">Rp <?php echo e(number_format($b['zakat'], 0, ',', '.')); ?></span>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="p-4 bg-purple-50 space-y-1 text-xs">
                    <div class="flex justify-between items-center">
                        <span class="font-semibold text-gray-800">TOTAL NILAI BARANG</span>
                        <span class="font-bold text-gray-800 text-sm">Rp <?php echo e(number_format($totalBarang, 0, ',', '.')); ?></span>
                    </div>
                    <div class="flex justify-between items-center">
                        <span class="font-bold text-purple-900">ZAKAT BARANG (2,5%)</span>
                        <span class="font-bold text-purple-900 text-base">Rp <?php echo e(number_format($zakatBarang, 0, ',', '.')); ?></span>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>

    
    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        
        <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
            <div class="px-4 py-3 border-b border-gray-100 flex items-center justify-between bg-gradient-to-r from-red-50 to-white">
                <div class="flex items-center gap-2">
                    <iconify-icon icon="mdi:file-document-outline" class="text-red-600 text-lg"></iconify-icon>
                    <h3 class="font-semibold text-gray-800 text-sm sm:text-base">Kewajiban: Hutang</h3>
                </div>
                <span class="text-xs font-bold text-red-600">- Rp <?php echo e(number_format($totalHutang, 0, ',', '.')); ?></span>
            </div>
            <div class="overflow-x-auto max-h-64">
                <table class="w-full text-xs">
                    <thead class="bg-gray-50 border-b sticky top-0">
                        <tr>
                            <th class="text-left py-2 px-4 font-semibold text-gray-500 uppercase">Pemberi Hutang</th>
                            <th class="text-right py-2 px-4 font-semibold text-gray-500 uppercase">Nominal</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-100">
                        <?php $__empty_1 = true; $__currentLoopData = $hutangList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="hover:bg-gray-50">
                                <td class="py-2 px-4 text-gray-800">
                                    <?php echo e($h->nama_pemberi_hutang); ?>

                                    <div class="text-[10px] text-gray-400"><?php echo e($h->tanggal->format('d/m/Y')); ?></div>
                                </td>
                                <td class="py-2 px-4 text-right text-red-600 font-semibold">Rp <?php echo e(number_format($h->nominal, 0, ',', '.')); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="2" class="py-4 text-center text-gray-500">Tidak ada hutang.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        
        <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
            <div class="px-4 py-3 border-b border-gray-100 flex items-center justify-between bg-gradient-to-r from-orange-50 to-white">
                <div class="flex items-center gap-2">
                    <iconify-icon icon="mdi:piggy-bank" class="text-orange-600 text-lg"></iconify-icon>
                    <h3 class="font-semibold text-gray-800 text-sm sm:text-base">Kewajiban: Tabungan</h3>
                </div>
                <span class="text-xs font-bold text-orange-600">- Rp <?php echo e(number_format($totalTabungan, 0, ',', '.')); ?></span>
            </div>
            <div class="overflow-x-auto max-h-64">
                <table class="w-full text-xs">
                    <thead class="bg-gray-50 border-b sticky top-0">
                        <tr>
                            <th class="text-left py-2 px-4 font-semibold text-gray-500 uppercase">Nama Akun</th>
                            <th class="text-right py-2 px-4 font-semibold text-gray-500 uppercase">Saldo</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-100">
                        <?php $__empty_1 = true; $__currentLoopData = $tabunganList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="hover:bg-gray-50">
                                <td class="py-2 px-4 text-gray-800 font-medium"><?php echo e($t['nama']); ?></td>
                                <td class="py-2 px-4 text-right text-orange-600 font-semibold">Rp <?php echo e(number_format($t['saldo'], 0, ',', '.')); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="2" class="py-4 text-center text-gray-500">Tidak ada saldo tabungan.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    
    <div class="bg-gradient-to-r from-emerald-500 to-teal-600 rounded-xl shadow-md overflow-hidden mb-6">
        <div class="flex flex-col md:flex-row">
            
            
            <div class="p-6 md:w-1/3 flex flex-col justify-center items-center md:items-start border-b md:border-b-0 md:border-r border-white/20 text-white">
                <div class="w-14 h-14 bg-white/20 rounded-full flex items-center justify-center mb-3">
                    <iconify-icon icon="mdi:hand-heart" class="text-3xl text-white"></iconify-icon>
                </div>
                <div class="text-emerald-100 text-sm font-medium text-center md:text-left">Total Zakat (2,5%)</div>
                <div class="text-3xl sm:text-4xl font-bold mt-1">Rp <?php echo e(number_format($totalZakat, 0, ',', '.')); ?></div>
                <div class="text-xs text-emerald-100 mt-2 text-center md:text-left">
                    *Dihitung dari Harta Bersih
                </div>
            </div>

            
            <div class="p-4 sm:p-6 md:w-2/3 bg-white/5 text-white">
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-8">
                    
                    
                    <div class="space-y-2">
                        <h4 class="text-xs font-bold text-emerald-200 uppercase tracking-wider mb-2 border-b border-white/20 pb-1">Nilai Harta (Aset)</h4>
                        
                        <div class="flex justify-between items-center text-sm">
                            <span class="text-emerald-50">1. Saldo & Online</span>
                            <span class="font-semibold">Rp <?php echo e(number_format($totalSaldo, 0, ',', '.')); ?></span>
                        </div>
                        <div class="flex justify-between items-center text-sm">
                            <span class="text-emerald-50">2. Piutang</span>
                            <span class="font-semibold">Rp <?php echo e(number_format($totalPiutang, 0, ',', '.')); ?></span>
                        </div>
                        <div class="flex justify-between items-center text-sm">
                            <span class="text-emerald-50">3. Barang Online</span>
                            <span class="font-semibold">Rp <?php echo e(number_format($totalBarang, 0, ',', '.')); ?></span>
                        </div>
                        
                        <div class="flex justify-between items-center pt-2 mt-2 border-t border-white/20 text-sm font-bold text-white">
                            <span>Total Harta</span>
                            <span>Rp <?php echo e(number_format($totalHarta, 0, ',', '.')); ?></span>
                        </div>

                        <div class="flex justify-between items-center text-sm text-red-200 mt-1">
                            <span>(-) Hutang</span>
                            <span>Rp <?php echo e(number_format($totalHutang, 0, ',', '.')); ?></span>
                        </div>
                        <div class="flex justify-between items-center text-sm text-red-200">
                            <span>(-) Tabungan</span>
                            <span>Rp <?php echo e(number_format($totalTabungan, 0, ',', '.')); ?></span>
                        </div>

                        <div class="flex justify-between items-center pt-2 mt-2 border-t border-white/20 text-sm font-bold text-yellow-300">
                            <span>Harta Bersih (Dasar Zakat)</span>
                            <span>Rp <?php echo e(number_format($hartaBersih, 0, ',', '.')); ?></span>
                        </div>
                    </div>

                    
                    <div class="space-y-2">
                        <h4 class="text-xs font-bold text-emerald-200 uppercase tracking-wider mb-2 border-b border-white/20 pb-1">Nilai Zakat (2,5%)</h4>
                        
                        <div class="flex justify-between items-center text-sm">
                            <span class="text-emerald-50">Zakat Saldo</span>
                            <span class="font-semibold text-white">Rp <?php echo e(number_format($zakatSaldo, 0, ',', '.')); ?></span>
                        </div>
                        <div class="flex justify-between items-center text-sm">
                            <span class="text-emerald-50">Zakat Piutang</span>
                            <span class="font-semibold text-white">Rp <?php echo e(number_format($zakatPiutang, 0, ',', '.')); ?></span>
                        </div>
                        <div class="flex justify-between items-center text-sm">
                            <span class="text-emerald-50">Zakat Barang</span>
                            <span class="font-semibold text-white">Rp <?php echo e(number_format($zakatBarang, 0, ',', '.')); ?></span>
                        </div>

                        <div class="flex justify-between items-center pt-2 mt-2 border-t border-white/20 text-sm font-bold text-white">
                            <span>Subtotal Zakat Aset</span>
                            <span>Rp <?php echo e(number_format($zakatSaldo + $zakatPiutang + $zakatBarang, 0, ',', '.')); ?></span>
                        </div>

                        <div class="flex justify-between items-center text-sm text-red-200 mt-1">
                            <span>(-) Zakat Hutang</span>
                            <span>Rp <?php echo e(number_format($zakatHutang, 0, ',', '.')); ?></span>
                        </div>
                        <div class="flex justify-between items-center text-sm text-red-200">
                            <span>(-) Zakat Tabungan</span>
                            <span>Rp <?php echo e(number_format($zakatTabungan, 0, ',', '.')); ?></span>
                        </div>

                        <div class="flex justify-between items-center pt-2 mt-2 border-t border-white/20 text-sm font-bold text-yellow-300">
                            <span>Total Zakat Akhir</span>
                            <span>Rp <?php echo e(number_format($totalZakat, 0, ',', '.')); ?></span>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>

</div>


<div id="bayarZakatModal" class="fixed inset-0 z-50 hidden items-center justify-center p-4">
    <div class="absolute inset-0 bg-black/50" onclick="closeBayarZakatModal()"></div>
    <div class="relative bg-white rounded-xl shadow-xl w-full max-w-md overflow-hidden max-h-[90vh] flex flex-col">
        <div class="px-5 py-4 border-b border-gray-100 flex justify-between items-center bg-emerald-50 flex-shrink-0">
            <div class="flex items-center gap-2">
                <iconify-icon icon="mdi:cash-register" class="text-emerald-600 text-lg"></iconify-icon>
                <h3 class="font-bold text-gray-800">Konfirmasi Bayar Zakat</h3>
            </div>
            <button type="button" onclick="closeBayarZakatModal()" class="text-gray-400 hover:text-gray-600">
                <iconify-icon icon="mdi:close" class="text-xl"></iconify-icon>
            </button>
        </div>

        <form id="bayarZakatForm" onsubmit="submitBayarZakat(event)" class="overflow-y-auto flex-1 flex flex-col">
            <?php echo csrf_field(); ?>

            <input type="hidden" id="inputDetailBreakdown" name="detail_breakdown">
            <div class="p-5 space-y-4">
                <div class="hidden bg-red-50 text-red-600 p-3 rounded text-sm" id="modalErrorBayarZakat"></div>

                <div class="bg-emerald-50 border border-emerald-200 rounded-lg p-4 text-center">
                    <div class="text-sm text-emerald-800 mb-1">Total Zakat yang Harus Dibayar</div>
                    <div class="text-3xl font-bold text-emerald-700">Rp <?php echo e(number_format($totalZakat, 0, ',', '.')); ?></div>
                </div>

                <input type="hidden" name="total_zakat" value="<?php echo e($totalZakat); ?>">
                <input type="hidden" name="total_saldo" value="<?php echo e($totalSaldo); ?>">
                <input type="hidden" name="total_piutang" value="<?php echo e($totalPiutang); ?>">
                <input type="hidden" name="total_barang" value="<?php echo e($totalBarang); ?>">
                <input type="hidden" name="total_hutang" value="<?php echo e($totalHutang); ?>">
                <input type="hidden" name="total_tabungan" value="<?php echo e($totalTabungan); ?>">

                <div>
                    <label class="block text-xs font-medium text-gray-600 mb-1">Tanggal Pembayaran <span class="text-red-500">*</span></label>
                    <input type="date" name="tanggal" value="<?php echo e(date('Y-m-d')); ?>" required
                        class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-emerald-500 focus:outline-none">
                </div>

                <div>
                    <label class="block text-xs font-medium text-gray-600 mb-1">Keterangan (Opsional)</label>
                    <input type="text" name="keterangan" placeholder="cth: Dibayar via transfer BRI"
                        class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-emerald-500 focus:outline-none">
                </div>
            </div>

            <div class="px-5 py-3 border-t border-gray-100 bg-gray-50 flex justify-end gap-2 flex-shrink-0">
                <button type="button" onclick="closeBayarZakatModal()" class="px-4 py-2 text-sm text-gray-600 hover:bg-gray-200 rounded-lg">Batal</button>
                <button type="submit" id="btnSubmitBayarZakat" class="bg-emerald-600 text-white px-4 py-2 rounded-lg hover:bg-emerald-700 text-sm font-medium flex items-center gap-2">
                    <iconify-icon icon="mdi:check-circle" class="text-lg"></iconify-icon> Konfirmasi Bayar
                </button>
            </div>
        </form>
    </div>
</div>

<script>
    const CSRF_ZAKAT = document.querySelector('meta[name="csrf-token"]').content;

</script>

<script>
    // Format input Rupiah
    document.getElementById('inputSaldoOnline')?.addEventListener('input', function() {
        let value = this.value.replace(/[^0-9]/g, '');
        this.value = value ? new Intl.NumberFormat('id-ID').format(value) : '';
    });

    async function submitSaldoOnline(e) {
        e.preventDefault();
        const btn = document.getElementById('btnSubmitSaldoOnline');
        const marketplace = document.getElementById('inputMarketplace').value;
        const saldo = document.getElementById('inputSaldoOnline').value;

        btn.disabled = true;
        btn.innerHTML = 'Menyimpan...';

        const formData = new FormData();
        formData.append('_token', '<?php echo e(csrf_token()); ?>');
        formData.append('marketplace', marketplace);
        formData.append('saldo', saldo.replace(/[^0-9]/g, ''));

        try {
            const res = await fetch("<?php echo e(route('zakat.saldo-online.store-ajax')); ?>", {
                method: 'POST',
                headers: { 'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>', 'Accept': 'application/json' },
                body: formData
            });
            const data = await res.json();
            if (!res.ok) throw new Error(data.message || 'Gagal.');
            window.location.reload();
        } catch (err) {
            alert('Gagal: ' + err.message);
            btn.disabled = false;
            btn.innerHTML = '<iconify-icon icon="mdi:plus" class="text-lg"></iconify-icon> Tambah';
        }
    }

    async function deleteSaldoOnline(id, marketplace) {
        if (!confirm(`Yakin hapus saldo online "${marketplace}"?`)) return;
        try {
            const res = await fetch(`/zakat/saldo-online/${id}/ajax`, {
                method: 'DELETE',
                headers: { 'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>', 'Accept': 'application/json' }
            });
            const data = await res.json();
            if (!res.ok) throw new Error(data.message || 'Gagal.');
            window.location.reload();
        } catch (err) {
            alert('Gagal: ' + err.message);
        }
    }

    function openBayarZakatModal() {
        document.getElementById('bayarZakatForm').reset();
        document.getElementById('modalErrorBayarZakat').classList.add('hidden');
        
        // Simpan SEMUA data yang tampil di halaman Index ke JSON
        const breakdownData = {
            saldo:         <?php echo json_encode($breakdownSaldo, 15, 512) ?>,
            saldo_online:  <?php echo json_encode($saldoOnlineList, 15, 512) ?>,      // ✅ TAMBAH
            piutang:       <?php echo json_encode($piutangList, 15, 512) ?>,
            barang:        <?php echo json_encode($barangList, 15, 512) ?>,
            tabungan:      <?php echo json_encode($tabunganList, 15, 512) ?>,
            hutang:        <?php echo json_encode($hutangList, 15, 512) ?>,

            zakat_saldo:        <?php echo e($zakatSaldo); ?>,
            zakat_saldo_online: <?php echo e($zakatSaldoOnline); ?>, // ✅ TAMBAH
            zakat_piutang:      <?php echo e($zakatPiutang); ?>,
            zakat_barang:       <?php echo e($zakatBarang); ?>,
            zakat_hutang:       <?php echo e($zakatHutang); ?>,
            zakat_tabungan:     <?php echo e($zakatTabungan); ?>,

            total_saldo:    <?php echo e($totalSaldo); ?>,           // ✅ TAMBAH (nilai final sudah termasuk online)
            total_piutang:  <?php echo e($totalPiutang); ?>,         // ✅ TAMBAH
            total_barang:   <?php echo e($totalBarang); ?>,          // ✅ TAMBAH
            total_hutang:   <?php echo e($totalHutang); ?>,          // ✅ TAMBAH
            total_tabungan: <?php echo e($totalTabungan); ?>,        // ✅ TAMBAH

            total_harta:    <?php echo e($totalHarta); ?>,
            harta_bersih:   <?php echo e($hartaBersih); ?>,
            total_zakat:    <?php echo e($totalZakat); ?>,           // ✅ TAMBAH
        };

        document.getElementById('inputDetailBreakdown').value = JSON.stringify(breakdownData);

        document.getElementById('bayarZakatModal').classList.remove('hidden');
        document.getElementById('bayarZakatModal').classList.add('flex');
    }

    function closeBayarZakatModal() {
        document.getElementById('bayarZakatModal').classList.add('hidden');
        document.getElementById('bayarZakatModal').classList.remove('flex');
    }

    async function submitBayarZakat(e) {
        e.preventDefault();
        const btn = document.getElementById('btnSubmitBayarZakat');
        const errDiv = document.getElementById('modalErrorBayarZakat');
        btn.disabled = true; btn.innerHTML = 'Menyimpan...';
        errDiv.classList.add('hidden');

        const formData = new FormData(e.target);

        try {
            const res = await fetch("<?php echo e(route('zakat.bayar')); ?>", {
                method: 'POST',
                headers: { 'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>', 'Accept': 'application/json' },
                body: formData
            });
            const data = await res.json();
            if (!res.ok) throw new Error(data.message || 'Gagal.');
            
            alert(data.message);
            window.location.reload();
        } catch (err) {
            errDiv.textContent = err.message;
            errDiv.classList.remove('hidden');
            btn.disabled = false; btn.innerHTML = '<iconify-icon icon="mdi:check-circle" class="text-lg"></iconify-icon> Konfirmasi Bayar';
        }
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pembukuan\resources\views\zakat\index.blade.php ENDPATH**/ ?>