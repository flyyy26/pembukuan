<div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
    <div class="px-5 py-4 border-b border-gray-100 flex items-center justify-between">
        <div class="flex items-center gap-2">
            <iconify-icon icon="mdi:chart-bar" class="text-gray-600 text-lg"></iconify-icon>
            <h3 class="font-semibold text-gray-800">Profit per SKU Varian</h3>
        </div>
        <div class="text-xs text-gray-500"><?php echo e($totalProduk); ?> SKU</div>
    </div>

    <div class="overflow-x-auto">
        <table class="w-full text-sm table-fixed">
            <colgroup>
                <col style="width: 50px;">   
                <col style="width: 160px;">  
                <col style="width: 200px;">  
                <col style="width: 60px;">   
                <col style="width: 110px;">  
                <col style="width: 100px;">  
                <col style="width: 110px;">  
                <col style="width: 100px;">  
            </colgroup>
            <thead class="bg-gray-50 border-b border-gray-100">
                <tr>
                    <th class="text-center py-3 px-3 w-12 text-xs font-semibold text-gray-500 uppercase tracking-wider">No</th>
                    <th class="text-left py-3 px-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">SKU Varian</th>
                    <th class="text-left py-3 px-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Produk Internal</th>
                    <th class="text-center py-3 px-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Qty</th>
                    <th class="text-right py-3 px-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Net Revenue</th>
                    <th class="text-right py-3 px-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">HPP</th>
                    <th class="text-right py-3 px-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Profit</th>
                    <th class="text-center py-3 px-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Status</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-100">
                <?php $__empty_1 = true; $__currentLoopData = $perProduk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="hover:bg-gray-50 transition">
                    <td class="py-3 px-3 text-center text-gray-400 text-xs"><?php echo e(($page - 1) * $perPage + $loop->iteration); ?></td>
                    <td class="py-3 px-3">
                        <button type="button" 
                                onclick="showSkuDetail('<?php echo e($p['marketplace_sku']); ?>')"
                                class="font-mono text-xs bg-gray-100 hover:bg-blue-100 hover:text-blue-700 px-2 py-1 rounded text-gray-700 transition flex items-center gap-1">
                            <?php echo e($p['marketplace_sku']); ?>

                            <iconify-icon icon="mdi:eye-outline" class="text-xs"></iconify-icon>
                        </button>
                    </td>
                    <td class="py-3 px-3 text-gray-700 text-xs leading-snug break-words">
                        <?php echo e($p['nama_produk']); ?>

                    </td>
                    <td class="py-3 px-3 text-center font-medium text-gray-700"><?php echo e($p['total_qty']); ?></td>
                    <td class="py-3 px-3 text-right text-gray-700"><?php echo e(number_format($p['net_revenue'], 0, ',', '.')); ?></td>
                    <td class="py-3 px-3 text-right text-orange-600"><?php echo e(number_format($p['hpp_total'], 0, ',', '.')); ?></td>
                    <td class="py-3 px-3 text-right font-bold <?php echo e($p['profit'] > 0 ? 'text-green-600' : 'text-red-600'); ?>"><?php echo e(number_format($p['profit'], 0, ',', '.')); ?></td>
                    <td class="py-3 px-3 text-center">
                        <?php if($p['mapped']): ?>
                            <span class="inline-flex items-center gap-1 bg-green-50 text-green-700 px-2 py-1 rounded-full text-xs font-medium">
                                <iconify-icon icon="mdi:check-circle" class="text-xs"></iconify-icon>Mapped
                            </span>
                        <?php else: ?>
                            <span class="inline-flex items-center gap-1 bg-red-50 text-red-700 px-2 py-1 rounded-full text-xs font-medium">
                                <iconify-icon icon="mdi:alert-circle" class="text-xs"></iconify-icon>Belum
                            </span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="8" class="py-12 text-center text-gray-500">Belum ada data.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php if($totalProduk > $perPage): ?>
        <?php
            $totalPages = ceil($totalProduk / $perPage);
            $startPage = max(1, $page - 2);
            $endPage = min($totalPages, $page + 2);
        ?>
        <div class="px-5 py-4 border-t border-gray-100 flex items-center justify-between">
            <div class="text-xs text-gray-500">
                Menampilkan <?php echo e(($page - 1) * $perPage + 1); ?>–<?php echo e(min($page * $perPage, $totalProduk)); ?> dari <?php echo e($totalProduk); ?> SKU
            </div>
            <div class="flex gap-1">
                <?php if($page > 1): ?>
                    <button type="button" onclick="loadSkuPage(<?php echo e($page - 1); ?>)"
                            class="px-3 py-1.5 rounded-lg border border-gray-300 text-sm text-gray-600 hover:bg-gray-50 transition">
                        <iconify-icon icon="mdi:chevron-left" class="text-sm"></iconify-icon>
                    </button>
                <?php endif; ?>
                <?php for($i = $startPage; $i <= $endPage; $i++): ?>
                    <button type="button" onclick="loadSkuPage(<?php echo e($i); ?>)"
                            class="px-3 py-1.5 rounded-lg text-sm transition <?php echo e($i == $page ? 'bg-gray-800 text-white font-medium' : 'border border-gray-300 text-gray-600 hover:bg-gray-50'); ?>">
                        <?php echo e($i); ?>

                    </button>
                <?php endfor; ?>
                <?php if($page < $totalPages): ?>
                    <button type="button" onclick="loadSkuPage(<?php echo e($page + 1); ?>)"
                            class="px-3 py-1.5 rounded-lg border border-gray-300 text-sm text-gray-600 hover:bg-gray-50 transition">
                        <iconify-icon icon="mdi:chevron-right" class="text-sm"></iconify-icon>
                    </button>
                <?php endif; ?>
            </div>
        </div>
    <?php endif; ?>
</div>


<div id="skuDetailModal" class="fixed inset-0 z-50 hidden items-center justify-center p-4">
    <div class="absolute inset-0 bg-black/50" onclick="closeSkuDetail()"></div>
    <div class="relative bg-white rounded-xl shadow-xl w-full max-w-5xl max-h-[90vh] flex flex-col">
        <div class="px-6 py-4 border-b border-gray-100 flex justify-between items-center">
            <h3 class="font-bold text-gray-800">Rincian Biaya & Net Revenue: <span id="detailSkuLabel" class="text-blue-600 font-mono"></span></h3>
            <button onclick="closeSkuDetail()" class="text-gray-400 hover:text-gray-700">
                <iconify-icon icon="mdi:close" class="text-xl"></iconify-icon>
            </button>
        </div>
        <div id="skuDetailContent" class="p-4 overflow-y-auto flex-1">
            
        </div>
    </div>
</div>

<script>
    function showSkuDetail(sku) {
        const modal = document.getElementById('skuDetailModal');
        const content = document.getElementById('skuDetailContent');
        document.getElementById('detailSkuLabel').textContent = sku;
        
        modal.classList.remove('hidden');
        modal.classList.add('flex');
        content.innerHTML = '<div class="text-center py-8 text-gray-500"><iconify-icon icon="mdi:loading" class="animate-spin text-2xl"></iconify-icon><br>Memuat data...</div>';

        // Ambil data via AJAX
        const params = new URLSearchParams({
            store: '<?php echo e($storeId ?? ""); ?>',
            sku: sku,
            from: '<?php echo e($from ?? ""); ?>',
            to: '<?php echo e($to ?? ""); ?>'
        });

        fetch(`<?php echo e(route('tiktok.sku.detail')); ?>?${params}`)
            .then(res => res.text())
            .then(html => {
                content.innerHTML = html;
            })
            .catch(err => {
                content.innerHTML = `<div class="text-red-500 text-center py-4">Gagal memuat data: ${err.message}</div>`;
            });
    }

    function closeSkuDetail() {
        const modal = document.getElementById('skuDetailModal');
        modal.classList.add('hidden');
        modal.classList.remove('flex');
    }
</script><?php /**PATH C:\xampp\htdocs\pembukuan\resources\views/tiktok/partials/sku-table.blade.php ENDPATH**/ ?>