

<?php $__env->startSection('title', 'Detail Report BRILink'); ?>

<?php $__env->startSection('content'); ?>
<div class="w-full">

    
    <div class="flex justify-between items-start mb-6">
        <div class="flex items-center gap-3">
            <a href="<?php echo e(route('brilink.index', ['store' => $report->store_id])); ?>"
               class="w-10 h-10 bg-gray-100 hover:bg-gray-200 rounded-lg flex items-center justify-center transition">
                <iconify-icon icon="mdi:arrow-left" class="text-gray-600 text-xl"></iconify-icon>
            </a>
            <div>
                <h2 class="text-xl font-bold text-gray-800">Detail Report BRILink</h2>
                <p class="text-sm text-gray-500">
                    <?php echo e($report->file_name); ?> · <?php echo e($report->periode_label); ?>

                </p>
            </div>
        </div>
    </div>

    
    <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
            <div class="text-xs text-gray-500 mb-1">Omset PPOB</div>
            <div class="text-lg font-bold text-gray-800">Rp <?php echo e(number_format($report->total_omset_ppob, 0, ',', '.')); ?></div>
        </div>
        <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
            <div class="text-xs text-gray-500 mb-1">Setoran</div>
            <div class="text-lg font-bold text-indigo-600">Rp <?php echo e(number_format($report->total_setoran_brilink, 0, ',', '.')); ?></div>
        </div>
        <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
            <div class="text-xs text-gray-500 mb-1">Pendapatan Admin</div>
            <div class="text-lg font-bold text-emerald-600">Rp <?php echo e(number_format($report->total_pendapatan_admin, 0, ',', '.')); ?></div>
        </div>
        <div class="bg-gradient-to-br from-emerald-500 to-teal-600 rounded-xl shadow-sm p-4 text-white">
            <div class="text-xs text-white/80 mb-1">Profit Bersih</div>
            <div class="text-lg font-bold">Rp <?php echo e(number_format($report->profit, 0, ',', '.')); ?></div>
        </div>
    </div>

    
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden mb-6">
        <div class="px-5 py-4 border-b border-gray-100">
            <h3 class="font-semibold text-gray-800">Rekening & Saldo</h3>
        </div>
        <table class="w-full text-sm">
            <thead class="bg-gray-50 border-b">
                <tr>
                    <th class="text-left py-2 px-4 text-xs text-gray-500 uppercase">Nama</th>
                    <th class="text-left py-2 px-4 text-xs text-gray-500 uppercase">Kategori</th>
                    <th class="text-right py-2 px-4 text-xs text-gray-500 uppercase">Saldo Awal</th>
                    <th class="text-right py-2 px-4 text-xs text-gray-500 uppercase">Saldo Akhir</th>
                    <th class="text-right py-2 px-4 text-xs text-gray-500 uppercase">Selisih</th>
                </tr>
            </thead>
            <tbody class="divide-y">
                <?php $__currentLoopData = $report->accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="hover:bg-gray-50">
                    <td class="py-2 px-4 font-medium text-gray-800"><?php echo e($a->nama_rekening); ?></td>
                    <td class="py-2 px-4 text-xs"><?php echo e($a->keterangan ?? '-'); ?></td>
                    <td class="py-2 px-4 text-right"><?php echo e(number_format($a->saldo_awal, 0, ',', '.')); ?></td>
                    <td class="py-2 px-4 text-right font-semibold"><?php echo e(number_format($a->saldo_akhir, 0, ',', '.')); ?></td>
                    <td class="py-2 px-4 text-right text-xs <?php echo e($a->selisih > 0 ? 'text-green-600' : ($a->selisih < 0 ? 'text-red-600' : 'text-gray-400')); ?>">
                        <?php echo e($a->selisih > 0 ? '+' : ''); ?><?php echo e(number_format($a->selisih, 0, ',', '.')); ?>

                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    
    <?php if($report->ppobItems->isNotEmpty()): ?>
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden mb-6">
        <div class="px-5 py-4 border-b border-gray-100">
            <h3 class="font-semibold text-gray-800">Omset PPOB per Kategori</h3>
        </div>
        <table class="w-full text-sm">
            <tbody class="divide-y">
                <?php $__currentLoopData = $report->ppobItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="py-2 px-4"><?php echo e($p->kategori); ?></td>
                    <td class="py-2 px-4 text-right font-semibold">Rp <?php echo e(number_format($p->nominal, 0, ',', '.')); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>

    
    <?php if($report->pengeluaranItems->isNotEmpty()): ?>
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div class="px-5 py-4 border-b border-gray-100 flex justify-between items-center">
            <h3 class="font-semibold text-gray-800">Pengeluaran</h3>
            <span class="text-xs text-gray-500"><?php echo e($report->pengeluaranItems->count()); ?> transaksi</span>
        </div>
        <table class="w-full text-sm">
            <thead class="bg-gray-50 border-b">
                <tr>
                    <th class="text-left py-2 px-4 text-xs text-gray-500 uppercase">Keterangan</th>
                    <th class="text-left py-2 px-4 text-xs text-gray-500 uppercase">Kategori</th>
                    <th class="text-right py-2 px-4 text-xs text-gray-500 uppercase">Nominal</th>
                </tr>
            </thead>
            <tbody class="divide-y">
                <?php $__currentLoopData = $report->pengeluaranItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="hover:bg-gray-50">
                    <td class="py-2 px-4"><?php echo e($p->keterangan); ?></td>
                    <td class="py-2 px-4 text-xs">
                        <?php if($p->kategori === 'Pindah Saldo Internal'): ?>
                            <span class="bg-orange-50 text-orange-700 px-2 py-0.5 rounded text-[10px]"><?php echo e($p->kategori); ?></span>
                        <?php else: ?>
                            <?php echo e($p->kategori ?? '-'); ?>

                        <?php endif; ?>
                    </td>
                    <td class="py-2 px-4 text-right font-medium">Rp <?php echo e(number_format($p->nominal_kas, 0, ',', '.')); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pembukuan\resources\views\brilink\show.blade.php ENDPATH**/ ?>